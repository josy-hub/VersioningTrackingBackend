-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 03 déc. 2020 à 07:29
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `tracking-servicev0`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_client` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vente_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clients_vente_id_foreign` (`vente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id`, `nom_client`, `email`, `contact`, `vente_id`, `created_at`, `updated_at`) VALUES
(1, 'Ntsama', 'sabinejosy@yahoo.fr', '676378658', 16, '2020-10-13 07:49:18', '2020-10-13 07:49:18'),
(2, 'Ntsama', 'sabinejosy@yahoo.fr', '676378658', 16, '2020-10-13 07:50:28', '2020-10-13 07:50:28'),
(3, 'ntsama', 'sabinejosy@yahoo.fr', '676378658', 16, '2020-10-13 07:57:40', '2020-10-13 07:57:40'),
(4, 'Ntsama', 'ntsamajosy@gmail.com', '678567890', 18, '2020-10-13 12:06:41', '2020-10-13 12:06:41'),
(5, 'Babila', 'babila@gmail.com', '655851222', 29, '2020-10-16 08:56:39', '2020-10-16 08:56:39'),
(6, 'Mvele', 'wilfier@dd.com', '565666988', 30, '2020-10-16 13:55:42', '2020-10-16 13:55:42'),
(7, 'Abdala', 'abdal@gmail.com', '655851222', 35, '2020-10-28 10:31:27', '2020-10-28 10:31:27'),
(8, 'client lamda', 'client@client.com', '000000000', 36, '2020-10-28 10:49:42', '2020-10-28 10:49:42'),
(9, 'client lamda', 'client@client.com', '000000000', 37, '2020-10-28 14:16:10', '2020-10-28 14:16:10');

-- --------------------------------------------------------

--
-- Structure de la table `departements`
--

DROP TABLE IF EXISTS `departements`;
CREATE TABLE IF NOT EXISTS `departements` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `departement` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom_responsable` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fonction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `division_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `departements_email_unique` (`email`),
  UNIQUE KEY `departements_contact_unique` (`contact`),
  KEY `departements_division_id_foreign` (`division_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `departements`
--

INSERT INTO `departements` (`id`, `departement`, `nom_responsable`, `fonction`, `email`, `contact`, `division_id`, `created_at`, `updated_at`) VALUES
(1, 'KmerFood Departement', 'Yves Ouambo', 'DG', 'kmerfooddepartement@peexit.com', '695296411', 1, '2020-09-25 14:57:26', '2020-09-25 14:57:26'),
(2, 'Socec Departement', 'Yves Ouambo', 'DG', 'socecdep@peexit.com', '695296410', 2, '2020-10-06 16:39:54', '2020-10-06 16:39:54'),
(3, 'Peex Departement', 'Yves Ouambo', 'DG', 'peexdep@peexit.com', '695276410', 3, '2020-10-06 16:41:23', '2020-10-06 16:41:23'),
(4, 'Connect Departement', 'Yves Ouambo', 'DG', 'connectdep@peexit.com', '685276410', 4, '2020-10-06 16:42:02', '2020-10-06 16:42:02'),
(5, 'BFF SCI Departement', 'Yves Ouambo', 'DG', 'bffdep@peexit.com', '685276419', 5, '2020-10-06 16:43:19', '2020-10-06 16:43:19'),
(6, 'Wecare SCI Departement', 'Yves Ouambo', 'DG', 'wecarescidep@peexit.com', '685076410', 6, '2020-10-06 16:44:05', '2020-10-06 16:44:05'),
(7, 'Tropical Departement', 'Yves Ouambo', 'DG', 'tropicaldep@peexit.com', '685077410', 7, '2020-10-06 16:45:35', '2020-10-06 16:45:35'),
(8, 'Wecare Bois Departement', 'Yves Ouambo', 'DG', 'wecareboisdep@peexit.com', '685077419', 8, '2020-10-06 16:46:29', '2020-10-06 16:46:29'),
(9, 'Home Pro Departement', 'Yves Ouambo', 'DG', 'homeprodep@peexit.com', '685077416', 9, '2020-10-06 16:47:55', '2020-10-06 16:47:55'),
(10, 'Wecare Alu Departement', 'Yves Ouambo', 'DG', 'wecarealudep@peexit.com', '685077476', 10, '2020-10-06 16:48:42', '2020-10-06 16:48:42'),
(11, 'Wecare Construct Departement', 'Yves Ouambo', 'DG', 'wecareconstructdep@peexit.com', '685077472', 17, '2020-10-06 16:50:42', '2020-10-06 16:50:42'),
(12, 'Agripeel Departement', 'Yves Ouambo', 'DG', 'agripeeldep@peexit.com', '685077482', 11, '2020-10-06 16:51:32', '2020-10-06 16:51:32'),
(13, 'Afrogaal Departement', 'Yves Ouambo', 'DG', 'afrogaaldep@peexit.com', '685077484', 12, '2020-10-06 16:53:26', '2020-10-06 16:53:26'),
(14, 'WecareFood Departement', 'Yves Ouambo', 'DG', 'wecarefooddep@peexit.com', '685077488', 13, '2020-10-06 16:55:17', '2020-10-06 16:55:17'),
(15, 'Peex Trade Departement', 'Yves Ouambo', 'DG', 'peextradedep@peexit.com', '685077452', 16, '2020-10-06 16:58:02', '2020-10-06 16:58:02'),
(16, 'Wecare Logistic Departement', 'Yves Ouambo', 'DG', 'wecarelogisticdep@peexit.com', '685077458', 14, '2020-10-06 17:08:41', '2020-10-06 17:08:41'),
(17, 'Wecare Technology Departement', 'Yves Ouambo', 'DG', 'wecaretechdep@peexit.com', '685077451', 15, '2020-10-06 17:10:27', '2020-10-06 17:10:27');

-- --------------------------------------------------------

--
-- Structure de la table `directions`
--

DROP TABLE IF EXISTS `directions`;
CREATE TABLE IF NOT EXISTS `directions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `direction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom_responsable` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fonction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entreprise_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `directions_email_unique` (`email`),
  UNIQUE KEY `directions_contact_unique` (`contact`),
  KEY `directions_entreprise_id_foreign` (`entreprise_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `directions`
--

INSERT INTO `directions` (`id`, `direction`, `nom_responsable`, `fonction`, `email`, `contact`, `entreprise_id`, `created_at`, `updated_at`) VALUES
(1, 'KmerFood Direction', 'Yves Ouambo', 'DG', 'kamerfooddir@peexit.com', '695296411', 4, '2020-09-25 14:48:35', '2020-09-25 14:48:35'),
(2, 'Socec epme Direction', 'Yves Ouambo', 'DG', 'socecepmedir@peexit.com', '695296410', 7, '2020-10-06 14:37:59', '2020-10-06 14:37:59'),
(3, 'Peex Direction', 'Yves Ouambo', 'DG', 'peexdir@peexit.com', '695297410', 8, '2020-10-06 14:42:06', '2020-10-06 14:42:06'),
(4, 'Connect Direction', 'Yves Ouambo', 'DG', 'connectdir@peexit.com', '697297410', 10, '2020-10-06 14:43:15', '2020-10-06 14:43:15'),
(5, 'BFF SCI Direction', 'Yves Ouambo', 'DG', 'bffdir@peexit.com', '697297210', 11, '2020-10-06 14:46:57', '2020-10-06 14:46:57'),
(6, 'Wecare SCI Direction', 'Yves Ouambo', 'DG', 'wecaredir@peexit.com', '667297210', 12, '2020-10-06 14:48:12', '2020-10-06 14:48:12'),
(7, 'Tropical Direction', 'Yves Ouambo', 'DG', 'tropicaldir@peexit.com', '687297210', 14, '2020-10-06 14:51:33', '2020-10-06 14:51:33'),
(8, 'Wecare Bois Direction', 'Yves Ouambo', 'DG', 'wecareboisdir@peexit.com', '687295210', 15, '2020-10-06 14:53:47', '2020-10-06 14:53:47'),
(9, 'Home Pro Direction', 'Yves Ouambo', 'DG', 'homeprodir@peexit.com', '687095210', 16, '2020-10-06 14:58:41', '2020-10-06 14:58:41'),
(10, 'Wecare Alu Direction', 'Yves Ouambo', 'DG', 'wecarealudir@peexit.com', '687085210', 17, '2020-10-06 14:59:21', '2020-10-06 14:59:21'),
(11, 'Wecare Construction Direction', 'Yves Ouambo', 'DG', 'wecareconstructiondir@peexit.com', '697085210', 18, '2020-10-06 15:01:32', '2020-10-06 15:01:32'),
(12, 'Agripeel Direction', 'Yves Ouambo', 'DG', 'agripeeladir@peexit.com', '697045210', 19, '2020-10-06 15:02:40', '2020-10-06 15:02:40'),
(13, 'Afrogaal Direction', 'Yves Ouambo', 'DG', 'afrogaaldir@peexit.com', '697035210', 21, '2020-10-06 15:11:01', '2020-10-06 15:11:01'),
(15, 'WecareFood Direction', 'Yves Ouambo', 'DG', 'wecarefooddir@peexit.com', '697234210', 22, '2020-10-06 15:14:37', '2020-10-06 15:14:37'),
(16, 'WecareLogistic Direction', 'Yves Ouambo', 'DG', 'wecarelogisticdir@peexit.com', '697237210', 24, '2020-10-06 15:26:33', '2020-10-06 15:26:33'),
(17, 'Peex Trade Direction', 'Yves Ouambo', 'DG', 'peextradedir@peexit.com', '693237210', 25, '2020-10-06 15:29:04', '2020-10-06 15:29:04'),
(18, 'Wecare Technology Direction', 'Yves Ouambo', 'DG', 'wecaretechdir@peexit.com', '693237510', 26, '2020-10-06 15:29:52', '2020-10-06 15:29:52');

-- --------------------------------------------------------

--
-- Structure de la table `divisions`
--

DROP TABLE IF EXISTS `divisions`;
CREATE TABLE IF NOT EXISTS `divisions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `division` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom_responsable` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fonction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `divisions_email_unique` (`email`),
  UNIQUE KEY `divisions_contact_unique` (`contact`),
  KEY `divisions_direction_id_foreign` (`direction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `divisions`
--

INSERT INTO `divisions` (`id`, `division`, `nom_responsable`, `fonction`, `email`, `contact`, `direction_id`, `created_at`, `updated_at`) VALUES
(1, 'KmerFood Division', 'Yves Ouambo', 'DG', 'kmerdiv@peexit.com', '695296411', 1, '2020-09-25 14:53:24', '2020-09-25 14:53:24'),
(2, 'Socec Division', 'Yves Ouambo', 'DG', 'socecdiv@peexit.com', '675296411', 2, '2020-10-06 15:47:51', '2020-10-06 15:47:51'),
(3, 'Peex Division', 'Yves Ouambo', 'DG', 'peexdiv@peexit.com', '675396411', 3, '2020-10-06 15:48:58', '2020-10-06 15:48:58'),
(4, 'Connect Division', 'Yves Ouambo', 'DG', 'connectdiv@peexit.com', '685396411', 4, '2020-10-06 15:49:40', '2020-10-06 15:49:40'),
(5, 'BFF SCI Division', 'Yves Ouambo', 'DG', 'bffdiv@peexit.com', '685396410', 5, '2020-10-06 15:50:47', '2020-10-06 15:50:47'),
(6, 'Wecare SCI Division', 'Yves Ouambo', 'DG', 'wecarediv@peexit.com', '681396410', 6, '2020-10-06 15:51:24', '2020-10-06 15:51:24'),
(7, 'Tropical Division', 'Yves Ouambo', 'DG', 'tropicaldiv@peexit.com', '681386410', 7, '2020-10-06 15:52:50', '2020-10-06 15:52:50'),
(8, 'Wecare Bois Division', 'Yves Ouambo', 'DG', 'wecareboisdiv@peexit.com', '681356410', 8, '2020-10-06 15:53:38', '2020-10-06 15:53:38'),
(9, 'Home Pro Division', 'Yves Ouambo', 'DG', 'homeprodiv@peexit.com', '681356411', 9, '2020-10-06 15:55:13', '2020-10-06 15:55:13'),
(10, 'Wecare Alu Division', 'Yves Ouambo', 'DG', 'wecarealudiv@peexit.com', '688356411', 10, '2020-10-06 15:56:47', '2020-10-06 15:56:47'),
(11, 'Agripeel Division', 'Yves Ouambo', 'DG', 'agripeeldiv@peexit.com', '689306411', 12, '2020-10-06 15:59:06', '2020-10-06 15:59:06'),
(12, 'Afrogaal Division', 'Yves Ouambo', 'DG', 'afrogaaldiv@peexit.com', '689306415', 13, '2020-10-06 15:59:59', '2020-10-06 15:59:59'),
(13, 'Wecare Food Division', 'Yves Ouambo', 'DG', 'wecarefooddiv@peexit.com', '689306416', 15, '2020-10-06 16:01:26', '2020-10-06 16:01:26'),
(14, 'Wecare Logistic Division', 'Yves Ouambo', 'DG', 'wecarelogisticdiv@peexit.com', '687306415', 16, '2020-10-06 16:02:22', '2020-10-06 16:02:22'),
(15, 'Wecare Technology  Division', 'Yves Ouambo', 'DG', 'wecaretechdiv@peexit.com', '647306915', 17, '2020-10-06 16:05:08', '2020-10-06 16:05:08'),
(16, 'Peex Trade Division', 'Yves Ouambo', 'DG', 'peextradediv@peexit.com', '687306915', 16, '2020-10-06 16:32:54', '2020-10-06 16:32:54'),
(17, 'Wecare Construction Division', 'Yves Ouambo', 'DG', 'wecareaconstructiondiv@peexit.com', '689356411', 11, '2020-10-06 16:35:31', '2020-10-06 16:35:31');

-- --------------------------------------------------------

--
-- Structure de la table `entreprises`
--

DROP TABLE IF EXISTS `entreprises`;
CREATE TABLE IF NOT EXISTS `entreprises` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `groupe_id` int(10) UNSIGNED NOT NULL,
  `raison_social` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CA` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom_responsable` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fonction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `siege_social` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entreprises_raison_social_unique` (`raison_social`),
  UNIQUE KEY `entreprises_email_unique` (`email`),
  UNIQUE KEY `entreprises_contact_unique` (`contact`),
  UNIQUE KEY `entreprises_logo_unique` (`logo`),
  KEY `entreprises_groupe_id_foreign` (`groupe_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `entreprises`
--

INSERT INTO `entreprises` (`id`, `groupe_id`, `raison_social`, `CA`, `nom_responsable`, `fonction`, `siege_social`, `email`, `contact`, `logo`, `created_at`, `updated_at`) VALUES
(4, 15, 'KmerFood', '100.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'youambo@peexit.com', '695296411', 'RAS', '2020-09-25 14:29:08', '2020-09-25 14:29:08'),
(7, 13, 'SOCEC EPME', '100.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'ywafo@peexit.com', '655851222', 'Aucun', '2020-10-06 12:30:41', '2020-10-06 12:30:41'),
(8, 13, 'PEEX', '100.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'ntsamajosy@gmail.com', '676378658', 'pas de logo', '2020-10-06 12:32:39', '2020-10-06 12:32:39'),
(10, 13, 'CONNECT', '100.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'sabinejosy@yahoo.fr', '690521441', 'Pas du tout de logo', '2020-10-06 12:36:53', '2020-10-06 12:36:53'),
(11, 14, 'BFF SCI', '150.000.000FCFA', 'Yves Ouambo', 'DG', 'Logpom', 'bff@info.com', '690521041', 'aucun pour le moment', '2020-10-06 12:39:44', '2020-10-06 12:39:44'),
(12, 14, 'Wecare SCI', '140.000.000FCFA', 'Yves Ouambo', 'DG', 'Logpom', 'ecaresci@info.com', '640521041', 'aucun logo', '2020-10-06 12:41:02', '2020-10-06 12:41:02'),
(14, 14, 'Tropical', '200.000.000FCFA', 'Yves Ouambo', 'DG', 'Logpom', 'tropical@info.com', '670521041', 'logo tropical', '2020-10-06 12:43:12', '2020-10-06 12:43:12'),
(15, 14, 'Wecare Bois', '200.000.000FCFA', 'Yves Ouambo', 'DG', 'Logpom', 'wecarebois@info.com', '680521041', 'logo wecare bois', '2020-10-06 12:44:21', '2020-10-06 12:44:21'),
(16, 14, 'Home Pro', '300.000.000FCFA', 'Yves Ouambo', 'DG', 'Logpom', 'homepro@info.com', '680531041', 'logo home pro', '2020-10-06 12:45:19', '2020-10-06 12:45:19'),
(17, 14, 'Wecare Alu', '250.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi', 'wecarealu@info.com', '660531041', 'logo wecare alu', '2020-10-06 12:46:40', '2020-10-06 12:46:40'),
(18, 14, 'Wecare Construction', '150.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'wecareconstruction@info.com', '620531041', 'logo wecare construction', '2020-10-06 12:47:49', '2020-10-06 12:47:49'),
(19, 15, 'Agripeel', '400.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'agripeel@info.com', '627531041', 'logo agripeel', '2020-10-06 12:49:12', '2020-10-06 12:49:12'),
(21, 15, 'Afrogaal', '700.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'afrogaal@info.com', '626531041', 'logo afrogaal', '2020-10-06 12:50:52', '2020-10-06 12:50:52'),
(22, 15, 'WecareFood', '95.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'wecarefood@info.com', '696531041', 'wecarefoods logo', '2020-10-06 12:52:58', '2020-10-06 12:52:58'),
(24, 16, 'Wecare Logistic', '350.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'wecarelogistic@info.com', '696531045', 'wecarelogistic logo', '2020-10-06 12:55:48', '2020-10-06 12:55:48'),
(25, 16, 'Peex  Trade et Services', '250.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'peextradeservice@info.com', '696531040', 'Peex Trade logo', '2020-10-06 12:58:09', '2020-10-06 12:58:09'),
(26, 16, 'Wecare Technology', '100.000.000FCFA', 'Yves Ouambo', 'DG', 'Bonamoussadi2', 'wecaretech@info.com', '696431048', 'Wecare tech logo', '2020-10-06 13:00:12', '2020-10-06 13:00:12');

-- --------------------------------------------------------

--
-- Structure de la table `equipes`
--

DROP TABLE IF EXISTS `equipes`;
CREATE TABLE IF NOT EXISTS `equipes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `equipe` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom_responsable` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fonction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `equipes_email_unique` (`email`),
  UNIQUE KEY `equipes_contact_unique` (`contact`),
  KEY `equipes_service_id_foreign` (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `equipes`
--

INSERT INTO `equipes` (`id`, `equipe`, `nom_responsable`, `fonction`, `email`, `contact`, `service_id`, `created_at`, `updated_at`) VALUES
(1, 'KmerFood Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'bmakang@peexit.com', '644456234', 1, '2020-09-25 15:06:10', '2020-09-25 15:06:10'),
(2, 'Socec Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'socecequipe@peexit.com', '647456234', 2, '2020-10-07 07:36:26', '2020-10-07 07:36:26'),
(3, 'Peex Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'peexequipe@peexit.com', '647456230', 3, '2020-10-07 07:37:59', '2020-10-07 07:37:59'),
(4, 'Connect Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'connectequipe@peexit.com', '647456238', 4, '2020-10-07 07:38:32', '2020-10-07 07:38:32'),
(5, 'BFF SCI Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'bffequipe@peexit.com', '647456208', 5, '2020-10-07 07:39:51', '2020-10-07 07:39:51'),
(6, 'Wecare SCI Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'wecaresciequipe@peexit.com', '647456808', 6, '2020-10-07 07:40:28', '2020-10-07 07:40:28'),
(7, 'Tropical Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'tropicalequipe@peexit.com', '647451808', 7, '2020-10-07 07:41:35', '2020-10-07 07:41:35'),
(8, 'Wecare Bois Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'wecareboisequipe@peexit.com', '647151808', 8, '2020-10-07 07:42:20', '2020-10-07 07:42:20'),
(9, 'Home Pro Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'homeproequipe@peexit.com', '697151808', 9, '2020-10-07 07:43:49', '2020-10-07 07:43:49'),
(10, 'Wecare Alu Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'wecarealuequipe@peexit.com', '697151708', 10, '2020-10-07 07:44:32', '2020-10-07 07:44:32'),
(11, 'Wecare Construct Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'wecareconstructequipe@peexit.com', '697151748', 11, '2020-10-07 07:46:35', '2020-10-07 07:46:35'),
(12, 'Agripeel Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'agripeelequipe@peexit.com', '697151778', 12, '2020-10-07 07:47:32', '2020-10-07 07:47:32'),
(13, 'Afrogaal Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'afrogaalequipe@peexit.com', '697151770', 13, '2020-10-07 07:48:38', '2020-10-07 07:48:38'),
(14, 'WecareFood Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'wecarefoodequipe@peexit.com', '697151670', 14, '2020-10-07 07:49:19', '2020-10-07 07:49:19'),
(15, 'Wecare Logistic Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'wecarelogisticequipe@peexit.com', '697151677', 15, '2020-10-07 07:50:34', '2020-10-07 07:50:34'),
(16, 'Peex Trade Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'peextradeequipe@peexit.com', '697151687', 16, '2020-10-07 07:53:12', '2020-10-07 07:53:12'),
(17, 'Wecare Tecgnology Equipe', 'Bienvenu Makang', 'Responsable de ventes', 'wecaretechequipe@peexit.com', '690151687', 17, '2020-10-07 07:55:13', '2020-10-07 07:55:13');

-- --------------------------------------------------------

--
-- Structure de la table `groupes`
--

DROP TABLE IF EXISTS `groupes`;
CREATE TABLE IF NOT EXISTS `groupes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom_responsable` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fonction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_groupe` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupes_nom_unique` (`nom`),
  UNIQUE KEY `groupes_email_unique` (`email`),
  UNIQUE KEY `groupes_contact_unique` (`contact`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `groupes`
--

INSERT INTO `groupes` (`id`, `nom`, `nom_responsable`, `fonction`, `email`, `contact`, `description_groupe`, `created_at`, `updated_at`) VALUES
(6, 'WecarePeexHolding', 'Yves Ouambo', 'PDG', 'youambo@peexit.com', '695296411', 'Il s\'agit d\'un groupe d\'entreprises: Peex, Wecare...qui offrent des services de TIC, immobilier, agriculture, microfinance...', '2020-09-25 11:12:17', '2020-09-25 11:12:17'),
(9, 'WecarePeexHolding1', 'Yves Ouambo', 'PDG', 'youambo1@peex.com', '695096411', 'Il s\'agit d\'un groupe d\'entreprises: Peex, Wecare...qui offrent des services de TIC, immobilier, agriculture, microfinance...', '2020-09-25 13:37:10', '2020-09-25 13:37:10'),
(13, 'Services Financiers', 'Yves Ouambo', 'PDG', 'ywafo@peexit.com', '674082937', 'Il s\'agit d\'un groupe d\'entreprises qui offre les services financiers.', '2020-10-06 12:07:28', '2020-10-06 12:07:28'),
(14, 'Immobilier et Construction', 'Yves Ouambo', 'PDG', 'ntsamajosy@gmail.com', '676378658', 'Il s\'agit d\'un groupe d\'entreprises qui offre les services immobiliers et de construction.', '2020-10-06 12:10:07', '2020-10-06 12:10:07'),
(15, 'Agro Alimentaire', 'Yves Ouambo', 'PDG', 'bmagang@peexit.com', '690521441', 'Il s\'agit d\'un groupe d\'entreprises qui offre les services agro alimentaires.', '2020-10-06 12:12:54', '2020-10-06 12:12:54'),
(16, 'Ingenieurie', 'Yves Ouambo', 'PDG', 'sabinejosy@yahoo.com', '6558511222', 'Il s\'agit d\'un groupe d\'entreprises qui offre les services agro alimentaires.', '2020-10-06 12:17:35', '2020-10-06 12:17:35');

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(2, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(3, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(4, '2016_06_01_000004_create_oauth_clients_table', 1),
(5, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(6, '2020_08_01_134107_create_groupes_table', 1),
(7, '2020_08_01_134208_create_entreprises_table', 1),
(8, '2020_08_01_201824_create_directions_table', 1),
(9, '2020_08_01_202012_create_divisions_table', 1),
(10, '2020_08_01_202058_create_departements_table', 1),
(11, '2020_08_01_202155_create_services_table', 1),
(12, '2020_08_01_202252_create_equipes_table', 1),
(13, '2020_08_01_234209_create_users_table', 1),
(14, '2020_08_01_514210_create_password_resets_table', 1),
(15, '2020_08_03_145137_create_produit_services_table', 1),
(16, '2020_08_03_145213_create_ventes_table', 1),
(17, '2020_08_03_170949_create_preuves_table', 1),
(18, '2020_08_03_171032_create_regle_commissions_table', 1),
(19, '2020_08_03_171112_create_modif_ventes_table', 1),
(20, '2020_08_03_171113_create_groupes_test', 2),
(21, '2020_08_03_171114_create_groupes_test1', 3),
(22, '2020_10_12_114433_clients_table', 4),
(23, '2020_10_12_162033_clientstest_table', 5),
(24, '2020_10_12_162033_clients_table', 6);

-- --------------------------------------------------------

--
-- Structure de la table `modif_ventes`
--

DROP TABLE IF EXISTS `modif_ventes`;
CREATE TABLE IF NOT EXISTS `modif_ventes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nvetat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nvprix` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nvquantite` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nvdate` date NOT NULL,
  `raison_modif` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `vente_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modif_ventes_user_id_foreign` (`user_id`),
  KEY `modif_ventes_vente_id_foreign` (`vente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `modif_ventes`
--

INSERT INTO `modif_ventes` (`id`, `nvetat`, `nvprix`, `nvquantite`, `nvdate`, `raison_modif`, `user_id`, `vente_id`, `created_at`, `updated_at`) VALUES
(1, 'valide', '6000', '18', '2020-09-24', 'Erreur', 3, 1, '2020-09-30 11:06:22', '2020-09-30 11:06:22'),
(2, 'valide', '8000', '8', '2020-09-24', 'ras', 3, 1, '2020-09-30 12:51:08', '2020-09-30 12:51:08'),
(3, 'valide', '7000', '7', '2020-09-26', 'test modification par reference', 3, 1, '2020-10-02 08:21:55', '2020-10-02 08:21:55'),
(4, 'en attente', '6000', '18', '2020-10-08', 'Erreur', 3, 3, '2020-10-08 15:56:07', '2020-10-08 15:56:07'),
(5, 'en attente', '6000', '18', '2020-10-08', 'Erreur', 3, 3, '2020-10-08 15:58:34', '2020-10-08 15:58:34'),
(6, 'en attente', '6000', '18', '2020-10-08', 'Erreur', 3, 3, '2020-10-08 16:00:08', '2020-10-08 16:00:08'),
(7, 'en attente', '6000', '18', '2020-10-08', 'Erreur', 3, 3, '2020-10-08 16:00:48', '2020-10-08 16:00:48'),
(8, 'en attente', '6000', '18', '2020-10-08', 'Erreur', 3, 3, '2020-10-08 16:02:08', '2020-10-08 16:02:08'),
(9, 'en attente', '180000', '2', '2020-10-08', 'RAS RAS RAS', 3, 9, '2020-10-08 16:23:11', '2020-10-08 16:23:11'),
(10, 'en attente', '123456', '12', '2020-10-09', 'Modif Mdoij', 3, 9, '2020-10-09 10:44:43', '2020-10-09 10:44:43'),
(11, 'en attente', '123456', '12', '2020-10-09', 'Modif Mdoij', 3, 9, '2020-10-09 10:44:51', '2020-10-09 10:44:51'),
(12, 'en attente', '12000', '7', '2020-10-07', 'asdfghjkl;;\'', 3, 1, '2020-10-09 11:10:36', '2020-10-09 11:10:36'),
(13, 'en attente', '140008', '9', '2020-10-13', 'test test tes test test test test test test test tset', 3, 9, '2020-10-13 12:35:50', '2020-10-13 12:35:50'),
(14, 'en attente', '157689', '4', '2020-10-12', 'qeertryuuipo', 3, 2, '2020-10-13 13:12:44', '2020-10-13 13:12:44'),
(15, 'en attente', '1200018', '18', '2020-10-13', 'aetstyfiuyi', 3, 3, '2020-10-13 15:31:10', '2020-10-13 15:31:10'),
(16, 'en attente', '123456', '5', '2020-10-06', 'radadada', 3, 1, '2020-10-15 09:21:14', '2020-10-15 09:21:14'),
(17, 'modifie', '10500', '5', '2020-10-07', 'correction', 3, 1, '2020-10-16 13:44:38', '2020-10-16 13:44:38'),
(18, 'en attente', '7000', '4', '2020-10-27', 'odif effective', 3, 9, '2020-10-27 16:07:58', '2020-10-27 16:07:58'),
(19, 'en attente', '9000', '5', '2020-10-27', 'RESTe RESTES', 3, 9, '2020-10-27 16:11:56', '2020-10-27 16:11:56'),
(20, 'en attente', '5000', '3', '2020-10-04', 'voir voir voir', 3, 9, '2020-10-27 16:18:03', '2020-10-27 16:18:03'),
(21, 'en attente', '7000', '3', '2020-10-27', 'rtyuiop', 3, 9, '2020-10-27 16:29:47', '2020-10-27 16:29:47'),
(22, 'en attente', '7000', '10', '2020-10-28', 'je teste pour voir si tous les groupes fonctionnent', 3, 9, '2020-10-28 07:33:17', '2020-10-28 07:33:17'),
(23, 'en attente', '7000', '10', '2020-10-28', 'je teste pour voir si tous les groupes fonctionnent', 3, 9, '2020-10-28 07:33:37', '2020-10-28 07:33:37'),
(24, 'en attente', '7000', '10', '2020-10-28', 'je teste pour voir si tous les groupes fonctionnent', 3, 9, '2020-10-28 07:33:37', '2020-10-28 07:33:37');

-- --------------------------------------------------------

--
-- Structure de la table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('001bf6aa2a7193f3049b8f6b2bf43571debd5e1d0bd79961212e919acfc05c089fd281acd30ad0eb', 1, 1, 'authToken', '[]', 0, '2020-10-27 09:58:24', '2020-10-27 09:58:24', '2021-10-27 10:58:24'),
('005c380d39eb9d8932952266752011c176d7b017de14db00d2cf41d91ae85940cd13cf5eb7ca1d4e', 1, 1, 'authToken', '[]', 0, '2020-09-30 08:32:41', '2020-09-30 08:32:41', '2021-09-30 09:32:41'),
('00bf262ab0b93ef432b632c645f8af9ad060c7c982bbddff1985fae05d22ba78d04e9edfe43a3e16', 1, 1, 'authToken', '[]', 0, '2020-10-21 15:05:44', '2020-10-21 15:05:44', '2021-10-21 16:05:44'),
('00e826738585db9b472a475d82ffb784f3f066cbb03e9e25371131ef314fe916b43d4812b6a94fda', 20, 1, 'authToken', '[]', 0, '2020-10-07 13:16:36', '2020-10-07 13:16:36', '2021-10-07 14:16:36'),
('00fed64dcdd7aec59b3ea43d504c6fcdeb8b62b28726b73e45d8dd6a57b17888d3747e0a1191c9f1', 3, 1, 'authToken', '[]', 0, '2020-10-12 16:58:13', '2020-10-12 16:58:13', '2021-10-12 17:58:13'),
('01eac0d3b04fce460ffd010840389d62cb814bff000315cb39cc69f481c944b3b6bbc9453c5c399d', 3, 1, 'authToken', '[]', 0, '2020-11-16 09:55:00', '2020-11-16 09:55:00', '2021-11-16 10:55:00'),
('01efcef6710e8318e7a2de01541806f280c178555df72402311844b762cfeffe5bda3430830889ca', 1, 1, 'authToken', '[]', 0, '2020-11-03 08:08:29', '2020-11-03 08:08:29', '2021-11-03 09:08:29'),
('025ca0fefc6dc30e698fe3bd57b14113612bb35f8a125febb5af0fd731699ed85ec3a9e17800f4e9', 1, 1, 'authToken', '[]', 0, '2020-10-22 14:52:38', '2020-10-22 14:52:38', '2021-10-22 15:52:38'),
('031121258ba69eb9e38c5ff2a2ab7a11490d04ed6e66987b1c536a2528c171d305c8f46fa7b13d46', 1, 1, 'authToken', '[]', 0, '2020-10-19 09:43:50', '2020-10-19 09:43:50', '2021-10-19 10:43:50'),
('0350e52b98d8d1849451613e0e1361a50919c4f28dfa7d274c07a5bc21bd5368cb7f02702875f4b5', 1, 1, 'authToken', '[]', 0, '2020-10-22 13:38:12', '2020-10-22 13:38:12', '2021-10-22 14:38:12'),
('07233322ed907dc5d4cb8e3345855a03abaf41c008da5fc7666dbc690fcb9be18f5f86c52441e060', 3, 1, 'authToken', '[]', 0, '2020-10-08 08:34:07', '2020-10-08 08:34:07', '2021-10-08 09:34:07'),
('0752350536b1f2ba3cb29c9923e7bd70324d84b030c091dc027f24ecc1a615458e7bd43207b5181a', 1, 1, 'authToken', '[]', 0, '2020-11-02 15:16:43', '2020-11-02 15:16:43', '2021-11-02 16:16:43'),
('098e134083c8d6fa9c020aba88f079ced81876d84ca4c4c8922fdacbd4b17592ac3d55c7da4cd0a1', 1, 1, 'authToken', '[]', 0, '2020-10-19 10:36:05', '2020-10-19 10:36:05', '2021-10-19 11:36:05'),
('09b8fb3781688b00b483e0ae245bca4188653cfc92c8d624a017c32cddd94a1d6f1cde0a9f886a0c', 1, 1, 'authToken', '[]', 0, '2020-11-20 09:25:52', '2020-11-20 09:25:52', '2021-11-20 10:25:52'),
('0a65ea044eacf01606792d344a1df4e592122d2f6ef7218f365e049580e4c30457378512266f74bf', 1, 1, 'authToken', '[]', 0, '2020-10-08 06:45:41', '2020-10-08 06:45:41', '2021-10-08 07:45:41'),
('0a9dcb1f2dddde253f2fd7d49c64221aeac76fdfbd836c6c77e7b134e66f16a13797d207335bd023', 3, 1, 'authToken', '[]', 0, '2020-11-20 06:01:37', '2020-11-20 06:01:37', '2021-11-20 07:01:37'),
('0c74a1c62dd2b61dbdf593d7f7e07a17f17716f9713c64eda2735defbd289225aebe9c01568a8fc1', 1, 1, 'authToken', '[]', 0, '2020-10-26 12:49:13', '2020-10-26 12:49:13', '2021-10-26 13:49:13'),
('0c860a52e147c6be2f2f7cf93e863d8df35cc00dfbee980bfd23cb196c78263ea755923e9271c128', 1, 1, 'authToken', '[]', 0, '2020-10-22 16:18:37', '2020-10-22 16:18:37', '2021-10-22 17:18:37'),
('0d63da7e47c2043a5cb490fafe3af67412ad6f5a9619fb034449414a6a02d59c321e3dd63d33c61f', 1, 1, 'authToken', '[]', 0, '2020-10-08 16:36:04', '2020-10-08 16:36:04', '2021-10-08 17:36:04'),
('0dd596b893f18413ac24b72338fe510ba679d23a9d296fb7a0b0e7f8f05cc4013378acc51cc0a819', 1, 1, 'authToken', '[]', 0, '2020-10-20 07:31:55', '2020-10-20 07:31:55', '2021-10-20 08:31:55'),
('0e14fc28910d115cd26c11a8cade1d4cc219da9efd12fbb98525f378d5c3d31c06d16256ff1fdd75', 3, 1, 'authToken', '[]', 0, '2020-10-27 09:11:12', '2020-10-27 09:11:12', '2021-10-27 10:11:12'),
('1096f8412c13e5b2d2a792ace0a41d533cf1cb8968ef567d97e2e81becf2e02187f0b96fc4a73d4a', 1, 1, 'authToken', '[]', 0, '2020-10-09 08:49:25', '2020-10-09 08:49:25', '2021-10-09 09:49:25'),
('11cd6f4815860c7204dffcaae3b6da791f082ca260857962fd59aed5c92d673c107cd16568384254', 1, 1, 'authToken', '[]', 0, '2020-10-28 07:03:30', '2020-10-28 07:03:30', '2021-10-28 08:03:30'),
('11e64bfead109a0e63367002a3f13d74e40e4e0627f5f3244a60a1a7b7d2e8cca76c311858c728db', 49, 1, 'authToken', '[]', 0, '2020-10-07 14:28:09', '2020-10-07 14:28:09', '2021-10-07 15:28:09'),
('139cf8fe83febe16c8f16f807d9357b42d1b5333ca274be51fe21c177f52872bfbe90184034111ac', 1, 1, 'authToken', '[]', 0, '2020-10-01 13:53:18', '2020-10-01 13:53:18', '2021-10-01 14:53:18'),
('13b3e1170e7fb7f2b724a62f38890eba14f80f5bd86bcfe0a399d5d787399df3cd1df4690fb6fb67', 1, 1, 'authToken', '[]', 0, '2020-10-05 07:25:01', '2020-10-05 07:25:01', '2021-10-05 08:25:01'),
('13bcf2c2db3edf7260dcce21f0be98b88d7254b83f9412af7abdcee6a004fe6b51545437c0d1840a', 6, 1, 'authToken', '[]', 0, '2020-10-07 12:48:05', '2020-10-07 12:48:05', '2021-10-07 13:48:05'),
('15a43b5a2ceedd09222bdfd194778748a9a7215533aa06c103feda799d407bfddc45b2a4fc0ab6ad', 1, 1, 'authToken', '[]', 0, '2020-10-26 07:01:25', '2020-10-26 07:01:25', '2021-10-26 08:01:25'),
('15ccade451c516673bd9a5f0e4cf3c0f7ed9a6b5cb92eab50f7dfe3b8066161c42c204f78c66b17f', 1, 1, 'authToken', '[]', 0, '2020-11-03 07:10:44', '2020-11-03 07:10:44', '2021-11-03 08:10:44'),
('161b6de658b2c0f580f1925bcd5478da723f2e1f161631f6db5250f75dc4c6614d42d46b16d118db', 1, 1, 'authToken', '[]', 0, '2020-10-08 09:17:11', '2020-10-08 09:17:11', '2021-10-08 10:17:11'),
('1680cfb96fa082721b59e189554d65f389cd1cd0f35d5aa555736205dbe8255d05b05ea9d756c6be', 1, 1, 'authToken', '[]', 0, '2020-10-20 18:19:47', '2020-10-20 18:19:47', '2021-10-20 19:19:47'),
('16895b212130572e81a411effd21b1cfa7e443c6c0beba726066d8f31f9dbe3c4f39c3a9d6331586', 3, 1, 'authToken', '[]', 0, '2020-09-25 15:31:07', '2020-09-25 15:31:07', '2021-09-25 16:31:07'),
('171996b8ec2c90edbc575cf18c92f978dfa1b79e92d5c3292dcb9d2862facefb66952981b40a182e', 13, 1, 'authToken', '[]', 0, '2020-10-07 13:04:48', '2020-10-07 13:04:48', '2021-10-07 14:04:48'),
('177a948d58248eb5779f5503bf2caf4bc98af8d351295acfea6da6f86aa37db4b250c95a274a6060', 1, 1, 'authToken', '[]', 0, '2020-10-26 12:53:05', '2020-10-26 12:53:05', '2021-10-26 13:53:05'),
('191b1b5bd3ba30d05caa403fa5382fe9557ecc4bb3e176c0acb3ecf58c7bbf1f053f6c96fe3c4911', 1, 1, 'authToken', '[]', 0, '2020-11-02 15:26:51', '2020-11-02 15:26:51', '2021-11-02 16:26:51'),
('197242d480364bc588169d0bc45bb8ebb0d9853f10557a55ba15a676f83ba67b27a27f50aa8f2637', 1, 1, 'authToken', '[]', 0, '2020-10-26 15:56:23', '2020-10-26 15:56:23', '2021-10-26 16:56:23'),
('1bae235579173f150d34b5c8f2f4742b763e692f08e641aabe8337cc6eca0221e9abca811535b3f4', 1, 1, 'authToken', '[]', 0, '2020-10-05 16:25:14', '2020-10-05 16:25:14', '2021-10-05 17:25:14'),
('1d258bfb174d4f8dbe7d7aa048266695415738b5a2fdf2865be36fbff01d324361c27c4f92ad130e', 3, 1, 'authToken', '[]', 0, '2020-11-20 05:59:12', '2020-11-20 05:59:12', '2021-11-20 06:59:12'),
('1d2e8ed4e2a9eaf9812fdb751ec81dffee4e84a80ce0a4ba6f26c83dc8b6b804383791cb8c2b5e5b', 1, 1, 'authToken', '[]', 0, '2020-09-26 10:31:52', '2020-09-26 10:31:52', '2021-09-26 11:31:52'),
('1e0927b2f01725c14052c9ede22a217877addc529e2e0456a2aca066a450735edc292ab55e54ec20', 1, 1, 'authToken', '[]', 0, '2020-10-13 14:41:56', '2020-10-13 14:41:56', '2021-10-13 15:41:56'),
('1ea2f5487bcef1cdc33d9a27b417089052f2647f064f51a11d6be8265b830a7da4a9cc2cd5335a81', 7, 1, 'authToken', '[]', 0, '2020-10-07 12:52:53', '2020-10-07 12:52:53', '2021-10-07 13:52:53'),
('1ed9af98cefa2878be5ba7630cb10f70f4926c44699decd0baa877e8b8e50af40f2c6c3c4d13a1d8', 3, 1, 'authToken', '[]', 0, '2020-11-20 10:02:18', '2020-11-20 10:02:18', '2021-11-20 11:02:18'),
('1f21adb947ec131186dc3d25514f4a77faa2e0097169612503952380117a50cf5925a7e60a2a640d', 1, 1, 'authToken', '[]', 0, '2020-11-04 09:27:23', '2020-11-04 09:27:23', '2021-11-04 10:27:23'),
('1fdcf6a17fa2413c3eb5907e89b4fba652569e16405e2c30b735b847105ac72598eab6951116a251', 3, 1, 'authToken', '[]', 0, '2020-10-08 14:31:40', '2020-10-08 14:31:40', '2021-10-08 15:31:40'),
('20d9cc8cd172b9373e0e7c56deecb383f8787858880fc71cacfb8187af7100302baba8bd4ff808fa', 1, 1, 'authToken', '[]', 0, '2020-11-03 08:37:04', '2020-11-03 08:37:04', '2021-11-03 09:37:04'),
('219b410050c54a57bbdafef820a82b9c25f5d9f0236742ca4273cc5516970802e0014fc2f0b342ed', 1, 1, 'authToken', '[]', 0, '2020-09-28 15:17:52', '2020-09-28 15:17:52', '2021-09-28 16:17:52'),
('21d4d30538ce690aa63c0f3155cd4a826ed3d2a52e835d1b78e15240776ab26e897a7f82523c7b12', 1, 1, 'authToken', '[]', 0, '2020-09-29 13:46:55', '2020-09-29 13:46:55', '2021-09-29 14:46:55'),
('21e4ebafe7ca42f70dd9a35d955134361a2b1f855a2499e619b2865271c266311930c3b020eb5f65', 1, 1, 'authToken', '[]', 0, '2020-10-05 06:41:36', '2020-10-05 06:41:36', '2021-10-05 07:41:36'),
('227efce446e5f2b01594875f143fcad175abe098010a7d45e59041a9eec1f8175252157084806a2d', 1, 1, 'authToken', '[]', 0, '2020-09-29 10:37:22', '2020-09-29 10:37:22', '2021-09-29 11:37:22'),
('22ad4e2b77cbd4aa80cff211a92ee19b78177c97b6dfc754c94718e8a8f0fdab67eb2eab5fcbd734', 1, 1, 'authToken', '[]', 0, '2020-11-02 15:12:24', '2020-11-02 15:12:24', '2021-11-02 16:12:24'),
('22e60447a34ae42906164b8cd41f7d898d318aa07044e169b74ddb0a612b3a4faba71a53bc339f03', 1, 1, 'authToken', '[]', 0, '2020-10-19 14:13:24', '2020-10-19 14:13:24', '2021-10-19 15:13:24'),
('2406b7b057d823005b293df7dfe3cc0b83641111330523297102ba0c4ecd5dbf7bf1ab6dc0489933', 3, 1, 'authToken', '[]', 0, '2020-11-20 10:02:14', '2020-11-20 10:02:14', '2021-11-20 11:02:14'),
('2550beddec729469303c848177d91898c82516d5480bc7616f8de602d800e8041acb5c676695e178', 3, 1, 'authToken', '[]', 0, '2020-10-09 06:56:17', '2020-10-09 06:56:17', '2021-10-09 07:56:17'),
('262c51dc78c29896497177f5eabcdcbfc29febd8a949d97612ef83cca47a45573f7e2f5ed75c7811', 3, 1, 'authToken', '[]', 0, '2020-11-20 08:37:23', '2020-11-20 08:37:23', '2021-11-20 09:37:23'),
('272de5f53cda4eb910c2f8ec6d7ba4b4293126cbbe3f243ab7e5be11e5b04cff0737cef2b702ad1b', 3, 1, 'authToken', '[]', 0, '2020-10-07 06:28:55', '2020-10-07 06:28:55', '2021-10-07 07:28:55'),
('291f17e723c675b0f16ba5f0e150b5ac57fc12215c0c103ad6ca73a1a46b55601488cc21a06554a8', 3, 1, 'authToken', '[]', 0, '2020-10-14 09:09:29', '2020-10-14 09:09:29', '2021-10-14 10:09:29'),
('2946fe4721f544a20a4b476218026e772439fa35172a123b6412f1a12e0869183c1669d63d311771', 1, 1, 'authToken', '[]', 0, '2020-10-12 07:33:10', '2020-10-12 07:33:10', '2021-10-12 08:33:10'),
('2a0ff02272545a4b1ddd02b30a42e1a1cfd1f168eb8d530c507c9b973f4e4423ddbb1d647f0a40c5', 33, 1, 'authToken', '[]', 0, '2020-10-07 13:43:26', '2020-10-07 13:43:26', '2021-10-07 14:43:26'),
('2a64383320a370092999b82138200434db591a609412d17af55c27280467de86537834fa18d05aa2', 3, 1, 'authToken', '[]', 0, '2020-11-16 07:20:34', '2020-11-16 07:20:34', '2021-11-16 08:20:34'),
('2b33fccad3a7f07e5bbdedc58e86d01dde1a14261f4fdee8968d99f9bf16ca07b1518852665b95ed', 9, 1, 'authToken', '[]', 0, '2020-10-07 12:56:46', '2020-10-07 12:56:46', '2021-10-07 13:56:46'),
('2c217f496eec9c69cf997cb32d47e6850ab04d0334c9d92d1b3ca0bafbfeb4f08dc6e556592b2931', 1, 1, 'authToken', '[]', 0, '2020-10-01 06:49:51', '2020-10-01 06:49:51', '2021-10-01 07:49:51'),
('2c4ff23bb576e71ff9c4901d889577bf1f73fbc923b4889e9b726b9750114435c3a86e3ad59f456c', 3, 1, 'authToken', '[]', 0, '2020-11-04 07:42:47', '2020-11-04 07:42:47', '2021-11-04 08:42:47'),
('2d8760a8a63f2c9675818d3e368d2a3bc30fef8f492c2354b2c07ddd9678186543b804bbe22c5558', 3, 1, 'authToken', '[]', 0, '2020-11-02 07:34:11', '2020-11-02 07:34:11', '2021-11-02 08:34:11'),
('2de4656ec4ed99087d82e5a0d2aeb747a74f8543d969f510d2a9f73ccb77fa0c3c8c2c4b4c0c3f8b', 3, 1, 'authToken', '[]', 0, '2020-11-16 09:45:40', '2020-11-16 09:45:40', '2021-11-16 10:45:40'),
('2f8896eea193d9405d3046823522d2023e283540d6f3c30d9c196567234d893ddcdca30001e14f52', 1, 1, 'authToken', '[]', 0, '2020-10-08 13:25:15', '2020-10-08 13:25:15', '2021-10-08 14:25:15'),
('3029c8d4523d2ea9345b594862db5c5f0f19468de6fee5c82a7fab84dd1b269adc831662fb16737c', 1, 1, 'authToken', '[]', 0, '2020-11-20 09:25:52', '2020-11-20 09:25:52', '2021-11-20 10:25:52'),
('304449dea9a6e84019e71e309025caf1df1e07628bd3eb200f9a5583e826b5f19b310555a4cda854', 1, 1, 'authToken', '[]', 0, '2020-11-20 08:00:06', '2020-11-20 08:00:06', '2021-11-20 09:00:06'),
('30cba41ca5dce956431ffacb79efa91809ba20454faaf5e9542480a6b9b4aba87bb2e35214095552', 3, 1, 'authToken', '[]', 0, '2020-11-19 10:09:03', '2020-11-19 10:09:03', '2021-11-19 11:09:03'),
('31a98c687ae30a5b79b7548aedbee1b24cf99c8b79c8fdaeda20093ec1dba9c707c45283a8d55532', 1, 1, 'authToken', '[]', 0, '2020-09-28 08:18:23', '2020-09-28 08:18:23', '2021-09-28 09:18:23'),
('3279abd57c2ba199c7595a667e8899172c3951ed23e11ff1ecd4b1b501a55cba9a04091082009280', 1, 1, 'authToken', '[]', 0, '2020-11-20 08:41:16', '2020-11-20 08:41:16', '2021-11-20 09:41:16'),
('327e0ff7d8bf1f586626f2ead3fb6811ed08ee8d9088e7b060184907347498818533355468e3b3d1', 1, 1, 'authToken', '[]', 0, '2020-10-22 12:45:10', '2020-10-22 12:45:10', '2021-10-22 13:45:10'),
('32aa2702dee274f499b41163f6cde5ef31bad19c302d37d06fe5749409d1e73ce7361290e186bc86', 3, 1, 'authToken', '[]', 0, '2020-10-07 15:11:52', '2020-10-07 15:11:52', '2021-10-07 16:11:52'),
('32ba1a8b4cae617e0933f4b5480bfb63ac8348f4b603de41b9ec8bcb4f1842e8431f38cf41ce2fad', 3, 1, 'authToken', '[]', 0, '2020-11-04 06:36:43', '2020-11-04 06:36:43', '2021-11-04 07:36:43'),
('32d7ecfbc3c08bd01b240f7c79c85a1e202eec2bca934ab0e55685a41566930e1d52ff4dda3a2e32', 1, 1, 'authToken', '[]', 0, '2020-11-03 06:54:05', '2020-11-03 06:54:05', '2021-11-03 07:54:05'),
('33727c9169aa427de64978fb3f908f4da206c685f14a88f4d43b6cb8f997528d8640701ca8358883', 1, 1, 'authToken', '[]', 0, '2020-10-21 09:25:02', '2020-10-21 09:25:02', '2021-10-21 10:25:02'),
('33b2fd05a62865300c02850cd202278fd5048eee7703d1fb2d9b488a35ad868787d194a4d1619147', 3, 1, 'authToken', '[]', 0, '2020-09-30 06:57:30', '2020-09-30 06:57:30', '2021-09-30 07:57:30'),
('342d663729273d2c5e198c7408fcb61fb88a7066af83fdf256a5b5296ab5d5a1b9aae98074232f96', 1, 1, 'authToken', '[]', 0, '2020-11-02 06:29:40', '2020-11-02 06:29:40', '2021-11-02 07:29:40'),
('364b59ba937a4373af427356a5935804f389b6c989d656789aee1ca38be5003944e7082c5fd85fb1', 1, 1, 'authToken', '[]', 0, '2020-11-03 06:54:05', '2020-11-03 06:54:05', '2021-11-03 07:54:05'),
('374ab0225bdbea49c468fad7444a0107125b0795747aa03431a9206ed5ca31623571f6c794740d89', 1, 1, 'authToken', '[]', 0, '2020-09-29 16:25:20', '2020-09-29 16:25:20', '2021-09-29 17:25:20'),
('379dbeb6aaf8e31406cd41668712c1ba14e97dc8c74a3f5b8d3df801d2ce9dc659ca804d1c5c0799', 3, 1, 'authToken', '[]', 0, '2020-11-16 08:10:15', '2020-11-16 08:10:15', '2021-11-16 09:10:15'),
('381beeef9580836654e0bf1702fa58bdba22008009c80a4ec689b7e2f8156d8c633e8ccbb5c2f404', 3, 1, 'authToken', '[]', 0, '2020-10-16 13:48:32', '2020-10-16 13:48:32', '2021-10-16 14:48:32'),
('386e55a8f4b2899b1c2b02e41dee6b47d36762b42b2c4bfff0e077026010058d0b5e5b4a2c3c10a7', 32, 1, 'authToken', '[]', 0, '2020-10-07 13:42:32', '2020-10-07 13:42:32', '2021-10-07 14:42:32'),
('388ea603e340598d3f793fd553f38caadea8dc8e73d4a2785f7294fc0e9ec4a3b521ba1e641aa1ca', 1, 1, 'authToken', '[]', 0, '2020-10-06 07:06:08', '2020-10-06 07:06:08', '2021-10-06 08:06:08'),
('39254852a8b009055b7e2df03b5c1ce6b9b51cd37f995e5b2d5b6803d63464dfcbbd59928043330e', 3, 1, 'authToken', '[]', 0, '2020-10-09 06:56:17', '2020-10-09 06:56:17', '2021-10-09 07:56:17'),
('3aac0bf97cb70a40f9e74dee1db484e985ee75f0544a3b2143e81e30de5c5bcad31d9326b2d9cf1b', 1, 1, 'authToken', '[]', 0, '2020-09-30 08:11:31', '2020-09-30 08:11:31', '2021-09-30 09:11:31'),
('3ae08dbbc40626292ddfeb0522e6978b783b6a4cc65c65bacbdb4dc56303a03e5fc93d66c16c2f2b', 1, 1, 'authToken', '[]', 0, '2020-10-22 13:06:21', '2020-10-22 13:06:21', '2021-10-22 14:06:21'),
('3b70e946255368908c6ab5db0b12b6919d4d4a5cd45cab03e260af11c52abb94f75cb3c2089e2af6', 1, 1, 'authToken', '[]', 0, '2020-10-19 10:46:42', '2020-10-19 10:46:42', '2021-10-19 11:46:42'),
('3bdf9ca2dc8669809f1de47c46591cde71a49aa467728b03de3b9078bfb6367f9a31fcadaa46bf43', 3, 1, 'authToken', '[]', 0, '2020-09-28 07:18:18', '2020-09-28 07:18:18', '2021-09-28 08:18:18'),
('3d3844dba53883643d5cca8bd4a53f218432f1fc214e33b7462c02e13e5c9515c81e9c9ac96ae067', 1, 1, 'authToken', '[]', 0, '2020-10-23 08:51:41', '2020-10-23 08:51:41', '2021-10-23 09:51:41'),
('3db583438db69b74b9a63a28c884af97df4322290053a5c741df1e9c269a687e084ad4f885775f6b', 1, 1, 'authToken', '[]', 0, '2020-10-05 14:11:14', '2020-10-05 14:11:14', '2021-10-05 15:11:14'),
('3e037ec7ebb2d48d92e656ea760086ebb1a2d2775bcc951febfad22b9983ef1b9b752e25921049c0', 1, 1, 'authToken', '[]', 0, '2020-10-05 08:18:49', '2020-10-05 08:18:49', '2021-10-05 09:18:49'),
('3e14028551cebd37c5c2ab1666d176dafab165e2c589605b98464960ebf90fa29ac065626d107ac9', 1, 1, 'authToken', '[]', 0, '2020-10-02 07:30:36', '2020-10-02 07:30:36', '2021-10-02 08:30:36'),
('3e6fb90c496465ec6205191b937946de2ca4bef5356eb5097ee9ea545b021b1bcd0c33a3ccfd5f3e', 1, 1, 'authToken', '[]', 0, '2020-10-09 10:13:10', '2020-10-09 10:13:10', '2021-10-09 11:13:10'),
('3ef6fa0add3e9681c2e3bcbfc8f08ef172ae7eeae8d8cb87be67d4ef7aecaabeadf3ca23107f5924', 1, 1, 'authToken', '[]', 0, '2020-09-29 07:39:04', '2020-09-29 07:39:04', '2021-09-29 08:39:04'),
('3fdfb3d9c192850d86f41b6337d557827e0ee21af1912a52f7d4fea86557e0701148fd6f3302b4a8', 1, 1, 'authToken', '[]', 0, '2020-10-08 16:31:11', '2020-10-08 16:31:11', '2021-10-08 17:31:11'),
('40c864979cca179a3dc735f5c5044bd68cfa3677d633355cab5a79980139099ac16a7cd6a62993e2', 1, 1, 'authToken', '[]', 0, '2020-10-22 12:28:31', '2020-10-22 12:28:31', '2021-10-22 13:28:31'),
('4127ad6cc966e024de6d94f6c4741a248c4e08e8a9660d664e41e6bf980231a4512620c350d6108a', 3, 1, 'authToken', '[]', 0, '2020-11-19 07:36:19', '2020-11-19 07:36:19', '2021-11-19 08:36:19'),
('41700d398e11b2e184ca4d0d49a2e9292e4df2bef877d7aa3bc2b1a20f2e96db6442fc89af639047', 1, 1, 'authToken', '[]', 0, '2020-11-02 13:07:17', '2020-11-02 13:07:17', '2021-11-02 14:07:17'),
('41ad731bb41667930a710d0c90cb8d38059c976147a5c57915950de1fea63d963884cd2bce43b843', 3, 1, 'authToken', '[]', 0, '2020-10-14 14:38:52', '2020-10-14 14:38:52', '2021-10-14 15:38:52'),
('41b4ca62d9f4ae7f1862080aa7a219200d97bced496c293b6fd00999a1cdc27e48400b26ddb3ae18', 3, 1, 'authToken', '[]', 0, '2020-10-26 13:48:07', '2020-10-26 13:48:07', '2021-10-26 14:48:07'),
('4296ae1ef46e36dd8add20d161e927b0fa2b38571cccac0ebcd64ee14c3747b7fbce1c91fd442251', 1, 1, 'authToken', '[]', 0, '2020-10-01 14:57:21', '2020-10-01 14:57:21', '2021-10-01 15:57:21'),
('42a9a61a3390000a9543023898b78a71dffb9959f98f4c6b05b8d63e3b330f2f09dcf2a39d1dcca6', 1, 1, 'authToken', '[]', 0, '2020-10-27 09:58:17', '2020-10-27 09:58:17', '2021-10-27 10:58:17'),
('42c0c54d46c2ca41ef42aaf17080a08a3e554fc26de6bffafa4bc1c11ebb0427fe1f040ba079a8e9', 2, 1, 'authToken', '[]', 0, '2020-10-08 10:58:04', '2020-10-08 10:58:04', '2021-10-08 11:58:04'),
('43929631cc1a638faf78381905525bf4f97ad306bde1dc5a5d072a8ac67e6176e9eb1c0d1cbdc257', 1, 1, 'authToken', '[]', 0, '2020-10-22 13:22:13', '2020-10-22 13:22:13', '2021-10-22 14:22:13'),
('44e2858a57d4e5fbe7519c84571afed4d0191686dba0d3cc7c5fbd74c85fb029918d7324355f5253', 3, 1, 'authToken', '[]', 0, '2020-11-19 09:49:43', '2020-11-19 09:49:43', '2021-11-19 10:49:43'),
('467335427c8d694d2eef39a6054ecbe60a298eec1a888f08789c75f28cf134b01905017ca0f701aa', 1, 1, 'authToken', '[]', 0, '2020-09-28 09:06:01', '2020-09-28 09:06:01', '2021-09-28 10:06:01'),
('469868e2bf4dc8d7a7a5985c69f17ee840184a8617bfd1dddafd7706414f35b60567917fcc27237a', 1, 1, 'authToken', '[]', 0, '2020-11-20 08:57:22', '2020-11-20 08:57:22', '2021-11-20 09:57:22'),
('4895623a9fc441413843b85be96cccd1f5db1a3f182fa210665f44aec24e1cf2dbec251e4a1a123f', 1, 1, 'authToken', '[]', 0, '2020-10-20 17:15:36', '2020-10-20 17:15:36', '2021-10-20 18:15:36'),
('489a455556e934232c1492920cbd6930eb99c35a7585e8e70a76c697a26b7f9f752a0f3bc7ea194a', 1, 1, 'authToken', '[]', 0, '2020-10-01 13:37:16', '2020-10-01 13:37:16', '2021-10-01 14:37:16'),
('49511bb1885961e7540f80ef7fa112b73cbdce860437c1a9e642d5fd331f94f7ded74ede3c35cb0a', 3, 1, 'authToken', '[]', 0, '2020-10-07 14:39:36', '2020-10-07 14:39:36', '2021-10-07 15:39:36'),
('49c60b2bbb78c50205f038fed060cf36ed5f534c2d59bc8dc8f73a61e8ea9a8c445454331f1bbe16', 3, 1, 'authToken', '[]', 0, '2020-11-18 10:46:57', '2020-11-18 10:46:57', '2021-11-18 11:46:57'),
('49d1515defc41670c33e1e7f3d4bebffb4489f43edb48458a85e87ee17eb14caa3556a068017b0d0', 3, 1, 'authToken', '[]', 0, '2020-11-04 07:07:08', '2020-11-04 07:07:08', '2021-11-04 08:07:08'),
('4a1994b834ee895d5939ed0c4f3f3adc1947527703aa3436ed9ae45a15b81edc8e95760394c18e03', 3, 1, 'authToken', '[]', 0, '2020-10-16 12:43:50', '2020-10-16 12:43:50', '2021-10-16 13:43:50'),
('4ab345023fb8bb9739297420318515c2336c727dda76f65553d958f851c1824a764cf03506320d2d', 1, 1, 'authToken', '[]', 0, '2020-10-22 07:42:39', '2020-10-22 07:42:39', '2021-10-22 08:42:39'),
('4b80a0f4add37207525a05ada5c9fbd7796ff98306649eac6b42e57de45582a690c5dfed18a73fe2', 1, 1, 'authToken', '[]', 0, '2020-10-05 10:15:13', '2020-10-05 10:15:13', '2021-10-05 11:15:13'),
('4c06e232d676865a4c8e002b7e51fc6608b0ecd167822a8602cee9b458fd97729a893e0dd0aa448c', 1, 1, 'authToken', '[]', 0, '2020-09-29 16:51:35', '2020-09-29 16:51:35', '2021-09-29 17:51:35'),
('4c1ca4202b7a79284a3d290b7609ba8cd45e8d3809e030f1b92d23823db460a70572b70a1949e09a', 3, 1, 'authToken', '[]', 0, '2020-10-09 09:38:12', '2020-10-09 09:38:12', '2021-10-09 10:38:12'),
('4c9e686030f2dcfb17dd8db7e0d071f9cd04a60778a39427b5a2da217b06600411f19efb316eeae2', 3, 1, 'authToken', '[]', 0, '2020-11-20 06:06:39', '2020-11-20 06:06:39', '2021-11-20 07:06:39'),
('4d3ebb7201e5aa38de98878c3c16c254cd9ea61edd5cd335ade6fb322f50ea44e43cdc95f39008c2', 3, 1, 'authToken', '[]', 0, '2020-11-20 09:17:10', '2020-11-20 09:17:10', '2021-11-20 10:17:10'),
('4e0c9e3d8a88d5d60492288f7e5c05428b44c4ce3badacade0635ee903a859698dfe1ae9d3915e7b', 1, 1, 'authToken', '[]', 0, '2020-10-09 11:09:15', '2020-10-09 11:09:15', '2021-10-09 12:09:15'),
('4f0ed0a3b90f073602290bbd7c49b352008a138a88ea75bffdc6d883f4ded08c7db377c7701c66b8', 1, 1, 'authToken', '[]', 0, '2020-10-13 15:51:35', '2020-10-13 15:51:35', '2021-10-13 16:51:35'),
('4f692aeefeb05c60061a17bb044dbb46b346f15a3fca9f0540ec2775a17ff1aa4210d3f79426606f', 2, 1, 'authToken', '[]', 0, '2020-10-27 15:05:13', '2020-10-27 15:05:13', '2021-10-27 16:05:13'),
('4fcd12ce04602091c565eb5c29f87330fd11aaa3065ebcdf318aefe7e610ca9f3e1a7ff96dc9b937', 1, 1, 'authToken', '[]', 0, '2020-11-04 07:30:49', '2020-11-04 07:30:49', '2021-11-04 08:30:49'),
('51291c27c20ff6593714d1963142b9500c707a9807c913368ed15e2fa395ef79001fa3d44b210209', 1, 1, 'authToken', '[]', 0, '2020-09-28 09:00:25', '2020-09-28 09:00:25', '2021-09-28 10:00:25'),
('51c32d3a0a45e7aa79871a2e6365fa4e390bd297e3a6f8dd18dec4fd35b9526bdef9fe568ee3c84a', 3, 1, 'authToken', '[]', 0, '2020-11-04 07:31:56', '2020-11-04 07:31:56', '2021-11-04 08:31:56'),
('51d31a349439ac479cccae3650eb63b387d96247936408332246d8ffe28c0fe1992b096a322b9207', 3, 1, 'authToken', '[]', 0, '2020-11-17 15:09:30', '2020-11-17 15:09:30', '2021-11-17 16:09:30'),
('520765097c59ef7aec225c5f9dd914ee8df5d5170eb297b8a89ff6943547877c8fe2c4720615ae48', 3, 1, 'authToken', '[]', 0, '2020-11-04 06:50:29', '2020-11-04 06:50:29', '2021-11-04 07:50:29'),
('5250f0ae5697ddf3833be515e87b7b2fdba1d40c98d2f16cfa997fadc996e015524bf31bdad7edc8', 1, 1, 'authToken', '[]', 0, '2020-11-03 12:45:21', '2020-11-03 12:45:21', '2021-11-03 13:45:21'),
('528f1b2739c30e134961552a1a3ed954ebd97167915aca09ee292f823bea5c84f1b86d5b481a6484', 1, 1, 'authToken', '[]', 0, '2020-10-08 09:12:54', '2020-10-08 09:12:54', '2021-10-08 10:12:54'),
('52d384a2eb920b0f79b5bc03760d2f801ca16cd68a5169aa9089581de1e52eec6bc9af65d803cf7e', 1, 1, 'authToken', '[]', 0, '2020-11-20 09:09:06', '2020-11-20 09:09:06', '2021-11-20 10:09:06'),
('53d3b76823ed60d1cc99bec888b2053805ed8e01c1f1740ee09be3c6b176e7fcf950b9b78dbd8536', 1, 1, 'authToken', '[]', 0, '2020-10-01 12:43:42', '2020-10-01 12:43:42', '2021-10-01 13:43:42'),
('542ae053541f07d8dbb24a13ee9162b45b1b1ec6ad4609dfb50100f6f89c87b07384983227f6713a', 1, 1, 'authToken', '[]', 0, '2020-10-15 12:43:27', '2020-10-15 12:43:27', '2021-10-15 13:43:27'),
('5474f8f425825fb64b9af65be9c7fb7500235802e914262b5bfeab1f2b50dd6967f33a2023d5440c', 3, 1, 'authToken', '[]', 0, '2020-10-13 07:10:54', '2020-10-13 07:10:54', '2021-10-13 08:10:54'),
('5537e330eab141ad8a1446e9e3b2b1e7e5a43251d81ce498b0e6029c32f2c9b9446bfecc5b55ac98', 1, 1, 'authToken', '[]', 0, '2020-10-20 07:31:55', '2020-10-20 07:31:55', '2021-10-20 08:31:55'),
('557895c1dffa69078fc73ddcf2224f462b84384406723dac6e16d0682301391507a4df0580cfeb41', 1, 1, 'authToken', '[]', 0, '2020-11-04 07:13:16', '2020-11-04 07:13:16', '2021-11-04 08:13:16'),
('55e4d3be83f5470c324e1ecf22ebfc1dd4f41f9cac94f005aa390454bd1f7ad9536fc8e36c624bb5', 1, 1, 'authToken', '[]', 0, '2020-10-09 11:08:24', '2020-10-09 11:08:24', '2021-10-09 12:08:24'),
('55e9c7bc9367c68ae52f16efa73511e4f10e4fca9fd977b0c8dec4a30cbbd28ab83b3eddbce2dfb9', 2, 1, 'authToken', '[]', 0, '2020-10-08 09:29:25', '2020-10-08 09:29:25', '2021-10-08 10:29:25'),
('569e29e09e778de3c568254e0a08570de22d78d8ddde0ebd21e3c66c814f6c4e1bd8e2fbcf530cad', 3, 1, 'authToken', '[]', 0, '2020-10-12 16:08:13', '2020-10-12 16:08:13', '2021-10-12 17:08:13'),
('5709b2ed68055e42e07e0d30a1e3d990254eb208c62bdda8674f24b426d8b613e2b4eb14e8b6506f', 1, 1, 'authToken', '[]', 0, '2020-10-05 08:18:43', '2020-10-05 08:18:43', '2021-10-05 09:18:43'),
('5772c3f97bdbc3d81f15d88506f0d825c408dc28952b128a2ad14a4cf1697e22b52758ce9400593e', 1, 1, 'authToken', '[]', 0, '2020-10-06 07:06:13', '2020-10-06 07:06:13', '2021-10-06 08:06:13'),
('57a493d84a0ad7e3a8c603bed059a8d650c69b36ea963ab2aafb16b692b3582b00ac2cd048e05f12', 3, 1, 'authToken', '[]', 0, '2020-10-16 11:39:53', '2020-10-16 11:39:53', '2021-10-16 12:39:53'),
('585815d81a3f35d29cfe143b562b3ae06dcff92c1b7a824d02465cde74500e5400cfb0481ae91660', 1, 1, 'authToken', '[]', 0, '2020-10-01 06:49:55', '2020-10-01 06:49:55', '2021-10-01 07:49:55'),
('59567e700fe63fc95c76419d59e46d1d99ead22906f693cf0bc5e2ab79c50735b69174f8fcc2c752', 1, 1, 'authToken', '[]', 0, '2020-10-21 06:39:16', '2020-10-21 06:39:16', '2021-10-21 07:39:16'),
('59b61cca2b8b12a20fe329aea3c5a170cfefcb06785ab7f0109d7a4621b6a9131a7dbf2c88abfefc', 3, 1, 'authToken', '[]', 0, '2020-10-15 13:05:36', '2020-10-15 13:05:36', '2021-10-15 14:05:36'),
('5afec0f0db9b0747039c496326493ad98a8acdc272bb08d607749fe54c4b537904716afe78073b51', 1, 1, 'authToken', '[]', 0, '2020-11-03 09:42:19', '2020-11-03 09:42:19', '2021-11-03 10:42:19'),
('5d239cdfa9bd05fe89953eca4da4a2b558a2fee9d4c5990bd244d42e1a5cb5a98b75e02085601428', 50, 1, 'authToken', '[]', 0, '2020-10-07 14:29:31', '2020-10-07 14:29:31', '2021-10-07 15:29:31'),
('5d76025837bddb3b69aeeebab60de39b62f4c8f6843d27e3064e40d8b3e7fcf14501ed19e1e69830', 1, 1, 'authToken', '[]', 0, '2020-09-28 07:27:50', '2020-09-28 07:27:50', '2021-09-28 08:27:50'),
('5d999a666e5863b265db03ff87bfdcf32ec585b706a30c863ef158a6475880b7d923f7d01dee4f70', 1, 1, 'authToken', '[]', 0, '2020-10-22 06:56:30', '2020-10-22 06:56:30', '2021-10-22 07:56:30'),
('5dc64bb7d0df98700b538d2b79a9920c24080fb275a45911b8301c08674bc3f101879b66ee7816e1', 1, 1, 'authToken', '[]', 0, '2020-09-29 16:25:07', '2020-09-29 16:25:07', '2021-09-29 17:25:07'),
('5e215741d782e286f841e0aca55649b9322f2a17dfa46d93b77007277c8fa914b863a33a052f355c', 1, 1, 'authToken', '[]', 0, '2020-10-05 07:15:37', '2020-10-05 07:15:37', '2021-10-05 08:15:37'),
('5e74c6f4b3e1e82bb3ee2a146e7be4f2dc1df148a4f4ece1ef525781acd8bc931e1f6e0e4c3f0eff', 1, 1, 'authToken', '[]', 0, '2020-10-01 13:30:28', '2020-10-01 13:30:28', '2021-10-01 14:30:28'),
('5f17a1b601cb5c1ab9dc3a6d8f466eac6a2d6aee20fb37ec44d1c61ca94e7c73ded3459a9c87e64b', 1, 1, 'authToken', '[]', 0, '2020-09-30 08:57:09', '2020-09-30 08:57:09', '2021-09-30 09:57:09'),
('5fdd499363160a21b43ffe6767d971f36380e324b56786af29ca0bcce0409b5968103debf1466c9c', 3, 1, 'authToken', '[]', 0, '2020-11-20 06:14:32', '2020-11-20 06:14:32', '2021-11-20 07:14:32'),
('5ff5b398fa9230789169d0ffddff920183d1009b87bf03fd4fb474f0b0e1c80cb70c5ba298f539a3', 44, 1, 'authToken', '[]', 0, '2020-10-07 14:19:18', '2020-10-07 14:19:18', '2021-10-07 15:19:18'),
('60a416d9c8e37b2d1e18ce9c48947151bbb569a925d70cb7e80ad3281d2c267208587d84bbcd7b2b', 1, 1, 'authToken', '[]', 0, '2020-11-04 10:11:34', '2020-11-04 10:11:34', '2021-11-04 11:11:34'),
('61392181d91d168520f319750443ab3f3095d204df668479fea276e984097740b0574210f724a59c', 1, 1, 'authToken', '[]', 0, '2020-11-04 07:25:18', '2020-11-04 07:25:18', '2021-11-04 08:25:18'),
('61bb4225af4f36b7d95445701f641ec91b9cd8278b697161902690924fbc8aa578dc2dbe4743d77f', 1, 1, 'authToken', '[]', 0, '2020-10-22 13:38:28', '2020-10-22 13:38:28', '2021-10-22 14:38:28'),
('6250217c52d1b88c0d39fe04ed7f624981123c16775d96dc078f9536064c5e6fb222b98aa66346e5', 3, 1, 'authToken', '[]', 0, '2020-10-05 06:57:05', '2020-10-05 06:57:05', '2021-10-05 07:57:05'),
('647042ff7eb5c2debad26df8ae29360c485a43b30f6477db452ac2bab626d7ee095791762b756ac3', 1, 1, 'authToken', '[]', 0, '2020-10-20 07:31:55', '2020-10-20 07:31:55', '2021-10-20 08:31:55'),
('648e0bde5bbe2125a999eedca47acc88f99ea35ae9bd6fc3b04bf08970b6ae7f7eca8870df79e7f7', 10, 1, 'authToken', '[]', 0, '2020-10-07 12:57:56', '2020-10-07 12:57:56', '2021-10-07 13:57:56'),
('668a5aa21729fc56c9b6d80119a2fb81b5ca87e0d707c9a955b83f86b5c8d7bc5c3de3370f91f4fe', 3, 1, 'authToken', '[]', 0, '2020-11-20 08:43:52', '2020-11-20 08:43:52', '2021-11-20 09:43:52'),
('66d9d3d24d4c407e29228847308ab2ce1a27cba055c5ac36017b0414d64ec82fc2c455f20264419f', 1, 1, 'authToken', '[]', 0, '2020-10-21 15:11:05', '2020-10-21 15:11:05', '2021-10-21 16:11:05'),
('66dd3e6f8c1f27389bc58dab6b033122a38933d07f577c20d03ad2dcb899869e7f5a5b8a52a165ca', 3, 1, 'authToken', '[]', 0, '2020-10-27 09:11:23', '2020-10-27 09:11:23', '2021-10-27 10:11:23'),
('670a517f9a92187032a973cc6159fecb94fa5404914c25e6be7f882e984603c1bad699ca176319f7', 3, 1, 'authToken', '[]', 0, '2020-11-13 10:24:36', '2020-11-13 10:24:36', '2021-11-13 11:24:36'),
('688ccf3ddf551804c752af0f87aea308842bdfa8947bf1e9ac4d65787783022c9e9c82b2995d4303', 3, 1, 'authToken', '[]', 0, '2020-10-16 12:18:17', '2020-10-16 12:18:17', '2021-10-16 13:18:17'),
('68a0b55e2eb41c3342dadaf2f15172b5c73e534b9965351aa7d9de9551838b8414dd5f8b8a060852', 1, 1, 'authToken', '[]', 0, '2020-11-03 08:10:25', '2020-11-03 08:10:25', '2021-11-03 09:10:25'),
('68d40fa986c352a3209ea141cfb1a8999fb1563b156ff886b0c87d2f7ccb9a319bad73d2cd6c1d1b', 3, 1, 'authToken', '[]', 0, '2020-11-04 06:52:28', '2020-11-04 06:52:28', '2021-11-04 07:52:28'),
('6a47150ee71e96db08211ce6aa6ab4428221524c7466d8694807bef1c0894397077de35b8e823845', 1, 1, 'authToken', '[]', 0, '2020-10-19 09:23:41', '2020-10-19 09:23:41', '2021-10-19 10:23:41'),
('6b04a702e3208ef1603f2f319998f1bff01ab0887ad30351c642637d6b5de4337f98390a83de9a12', 43, 1, 'authToken', '[]', 0, '2020-10-07 14:18:04', '2020-10-07 14:18:04', '2021-10-07 15:18:04'),
('6b0b72142c7c8b12b59e4855d05e6e6fae96baeebf70b7b58a7214661b079c7f3d9a026f5c75ecf4', 1, 1, 'authToken', '[]', 0, '2020-10-01 13:04:05', '2020-10-01 13:04:05', '2021-10-01 14:04:05'),
('6c3e8c132d306374e614024db40352ff4610c19056790dcbabfd4757db6d4788dc137576e855a922', 1, 1, 'authToken', '[]', 0, '2020-09-30 06:39:51', '2020-09-30 06:39:51', '2021-09-30 07:39:51'),
('6c97776d584ac555661698b2b81f14bc00b2ecdc813abaf3b9ad70d7d7fb7198cee56dde5c743379', 3, 1, 'authToken', '[]', 0, '2020-11-20 09:43:13', '2020-11-20 09:43:13', '2021-11-20 10:43:13'),
('6cf0514fe34a6a1edf7fc9cac79b3c1553586828ecfd8c1a24140f1e19f7287b67caf34e15ec0b10', 1, 1, 'authToken', '[]', 0, '2020-10-01 10:18:15', '2020-10-01 10:18:15', '2021-10-01 11:18:15'),
('6d212d7e0926499c9074b79c67eb109014732ed070f8cf1268382536c18dd72227faacd14982334d', 1, 1, 'authToken', '[]', 0, '2020-11-03 12:22:24', '2020-11-03 12:22:24', '2021-11-03 13:22:24'),
('6d6d148686197e624a37a2f842df7566741f0912acc6619cf8a5e5710e89cf7d1e62bbd3f7af25bb', 1, 1, 'authToken', '[]', 0, '2020-10-12 08:46:02', '2020-10-12 08:46:02', '2021-10-12 09:46:02'),
('6e171a50f641dd3cef918528970be1cd55b15496ccd76d429614dfd275dcd31d071700dc4374ca31', 1, 1, 'authToken', '[]', 0, '2020-11-03 08:09:22', '2020-11-03 08:09:22', '2021-11-03 09:09:22'),
('6e1b7f4b25a36acf9ce38d146ebb53a3f158650d0e9b06791f12e34efc4558511c9a0a0c5054dc94', 1, 1, 'authToken', '[]', 0, '2020-10-20 16:38:48', '2020-10-20 16:38:48', '2021-10-20 17:38:48'),
('6f10a37ffd017526e651029ed046bf16b9f2f9d2cc842c1dc31593ffb24f9891c9a1f9ed23d7f99f', 3, 1, 'authToken', '[]', 0, '2020-11-18 06:57:20', '2020-11-18 06:57:20', '2021-11-18 07:57:20'),
('6f3219bc8e52db0497d7f01fc972a0de4d0c057306e6a1398f3adb9579ac5c0b133403dd4e105f43', 3, 1, 'authToken', '[]', 0, '2020-11-04 07:45:09', '2020-11-04 07:45:09', '2021-11-04 08:45:09'),
('70a8d2baac4019181d1818504ebb8c6bf84d0dca7a7a04445bde1237630721f7fb6c1e80c86952e1', 3, 1, 'authToken', '[]', 0, '2020-11-04 07:36:29', '2020-11-04 07:36:29', '2021-11-04 08:36:29'),
('70fa0cb703da391645e4d3c0f0309e91c8f57d74442e1ff04fa3706e75781d41305543294348a8af', 1, 1, 'authToken', '[]', 0, '2020-10-20 17:32:52', '2020-10-20 17:32:52', '2021-10-20 18:32:52'),
('71467b8aec830f7cfa5a0d37e6f502dc9340ffe618e78a4e003186f7b4b4fabc1014b40ad1b463eb', 3, 1, 'authToken', '[]', 0, '2020-10-13 10:15:28', '2020-10-13 10:15:28', '2021-10-13 11:15:28'),
('71d4fec75511f9f869a105b0104cf03b1cec10c946188d47bd1071fb07864baff49ef489b6436e73', 1, 1, 'authToken', '[]', 0, '2020-09-29 13:19:17', '2020-09-29 13:19:17', '2021-09-29 14:19:17'),
('720c4815a491d05e86c46f5fb8732017666a6619fafdad2d1fb878069d23e2a78a2c39dc6f9d8133', 17, 1, 'authToken', '[]', 0, '2020-10-07 13:12:28', '2020-10-07 13:12:28', '2021-10-07 14:12:28'),
('727d695c553891d9da07b323707d9851e775ef589a24c4d9293639e148c16bd943499171b9903d35', 1, 1, 'authToken', '[]', 0, '2020-11-04 07:10:35', '2020-11-04 07:10:35', '2021-11-04 08:10:35'),
('729aecbd7b4184c70e5b82cdc36049cc4020334366d921aa9121281e8b0882c681f2382e597dcd59', 1, 1, 'authToken', '[]', 0, '2020-10-21 14:18:33', '2020-10-21 14:18:33', '2021-10-21 15:18:33'),
('72bc322f32f43f7d84e15e052c7a8e09affa8b5c6389037372d075e99290cf40ec66047dd9e80327', 1, 1, 'authToken', '[]', 0, '2020-09-30 07:54:08', '2020-09-30 07:54:08', '2021-09-30 08:54:08'),
('7465c7ffb0da443cbfc9b198950681058e77d272792505c0529adc9b86a342884545d6b0cab9447b', 3, 1, 'authToken', '[]', 0, '2020-11-20 08:56:08', '2020-11-20 08:56:08', '2021-11-20 09:56:08'),
('74b976ddc56157bf784dccb65fb49eab9f0270db6acb0b28db62ac978206490a81d9d1b08fa3d24e', 1, 1, 'authToken', '[]', 0, '2020-11-03 08:35:54', '2020-11-03 08:35:54', '2021-11-03 09:35:54'),
('74e6087de999fa92953d7c8961ab654f0a23da0675e859eb21a43141f10fab730a31df2bd3ec2c99', 3, 1, 'authToken', '[]', 0, '2020-09-28 07:18:23', '2020-09-28 07:18:23', '2021-09-28 08:18:23'),
('75bfc5edfe12ab51833a0d4030132c8d94d4ccfc7a65c7b10869040ac2d48643d9d156bf6e6ba170', 1, 1, 'authToken', '[]', 0, '2020-10-01 09:55:38', '2020-10-01 09:55:38', '2021-10-01 10:55:38'),
('763600c3f8a455cb2107c7c00bd2bcf5d9d20a59bbb139350434d8f7c602f489e17e18082c85fc7c', 2, 1, 'authToken', '[]', 0, '2020-09-25 15:24:40', '2020-09-25 15:24:40', '2021-09-25 16:24:40'),
('76a21f09a1b9669aff4e782c2b070e6d5072eaf476db47637e6cbfaa39ed7495cc6b0ff5f9fe3db8', 1, 1, 'authToken', '[]', 0, '2020-10-15 07:37:33', '2020-10-15 07:37:33', '2021-10-15 08:37:33'),
('772c60a9a94495097150664e539794d24935610de6456dab247ed48bb7cb66199bb41f9651c692d0', 1, 1, 'authToken', '[]', 0, '2020-11-03 08:11:41', '2020-11-03 08:11:41', '2021-11-03 09:11:41'),
('774c3f45ce1b6b9ad6d1b9a4ceb866378e0e820388492603e1e6d729d16bfdb2227e0b6c34268d13', 3, 1, 'authToken', '[]', 0, '2020-10-15 12:09:58', '2020-10-15 12:09:58', '2021-10-15 13:09:58'),
('77de2f87f5326bb041c289ffecfac0d76ba8cfa73404a8e0e47d0326d5a758b07eb090dbbc917d40', 15, 1, 'authToken', '[]', 0, '2020-10-07 13:08:09', '2020-10-07 13:08:09', '2021-10-07 14:08:09'),
('7806e4c1515442dc20d32c48f3f3a2a442f96674e60b757f4dff498c33aea9a7585d2a07c4e1317a', 1, 1, 'authToken', '[]', 0, '2020-09-29 10:59:34', '2020-09-29 10:59:34', '2021-09-29 11:59:34'),
('7860b424fa4d05d81bfce5c025a306750cb8cd094842e6ed36babbaa08a2f86ef10e776cb8157746', 1, 1, 'authToken', '[]', 0, '2020-11-02 13:22:10', '2020-11-02 13:22:10', '2021-11-02 14:22:10'),
('7865bc0acfa19e9ebc7ca16c3a1cb6408092d8e8a5fe0e9e2c56dc0bf4d1f66cf9d1f7e6edfce205', 1, 1, 'authToken', '[]', 0, '2020-11-02 10:17:33', '2020-11-02 10:17:33', '2021-11-02 11:17:33'),
('787e08543a7b6d6e0865da553ac51e8be24b47c747dfdf6c2fd4cb48e395493c53dab1bcf54e0368', 1, 1, 'authToken', '[]', 0, '2020-10-07 10:00:25', '2020-10-07 10:00:25', '2021-10-07 11:00:25'),
('78c58e4e1112d8a8c85e734a7603ada790f4842dbd614e8e5128023b3f850a1fdb2870fe07bcd96c', 1, 1, 'authToken', '[]', 0, '2020-11-02 15:35:59', '2020-11-02 15:35:59', '2021-11-02 16:35:59'),
('7905b63c39da3a1234fafed1ea1774e09da07a81e2a9e91469819e933f8ab622da7fca8c5c3c7046', 22, 1, 'authToken', '[]', 0, '2020-10-07 13:31:05', '2020-10-07 13:31:05', '2021-10-07 14:31:05'),
('7aa94fd5cde58aca3744d583948ecdbdaf48959e770933e9f6714f085acd55576d55aef768d61cc6', 3, 1, 'authToken', '[]', 0, '2020-10-07 06:28:50', '2020-10-07 06:28:50', '2021-10-07 07:28:50'),
('7b44efc912f48ec3417a3cd414726076e42281a4d28114ccab03b3414add819e78705d5d2e27ff39', 1, 1, 'authToken', '[]', 0, '2020-10-20 17:12:27', '2020-10-20 17:12:27', '2021-10-20 18:12:27'),
('7be693d14d4ca3c92aec5e922d1a800d0f80889a77a5b3ca9fe9e8080d0416f7f74fee96e22486f0', 36, 1, 'authToken', '[]', 0, '2020-10-07 14:03:58', '2020-10-07 14:03:58', '2021-10-07 15:03:58'),
('7be8b937ace8fa2a99094873c5d804bf2b69a3e814e20b0bed8e8276e71d47f04d4bbace4c07e46a', 1, 1, 'authToken', '[]', 0, '2020-11-04 15:09:54', '2020-11-04 15:09:54', '2021-11-04 16:09:54'),
('7c449f5d1664ed3d4b9395e9f4279cc2f1249719d0f571b444a19ebb7d8c2fd382ab64a73fac6940', 1, 1, 'authToken', '[]', 0, '2020-11-03 09:51:51', '2020-11-03 09:51:51', '2021-11-03 10:51:51'),
('7d709c0b3f9aafe43b6bbab3486a49025604085a03188419d64d9bc3942e0429ca92f9a23df3632b', 3, 1, 'authToken', '[]', 0, '2020-10-15 07:12:32', '2020-10-15 07:12:32', '2021-10-15 08:12:32'),
('7e7fa2ee6df8b21fbcabb6b8d506feb919a25cecdc0ff2dd3c47faf9ad1eb690059b97f1520b98fc', 3, 1, 'authToken', '[]', 0, '2020-10-23 14:39:59', '2020-10-23 14:39:59', '2021-10-23 15:39:59'),
('7e8c2eadd3b30ac6ef908ac7bb617b55ff377ebaa70676d34a15346d99bc8389530e61ea995e3419', 3, 1, 'authToken', '[]', 0, '2020-11-17 06:29:44', '2020-11-17 06:29:44', '2021-11-17 07:29:44'),
('7e95d4b0208bd823f390c4e73c79419dda17138e31cd7a8a425c56fe59a440540b81670dfeb0c1d4', 1, 1, 'authToken', '[]', 0, '2020-10-23 06:34:11', '2020-10-23 06:34:11', '2021-10-23 07:34:11'),
('7ef036a394f91c26f44948c0b4683aa48a26290bd3e43fc3aa9463d4f82d04a60e5ed1222a272969', 40, 1, 'authToken', '[]', 0, '2020-10-07 14:15:34', '2020-10-07 14:15:34', '2021-10-07 15:15:34'),
('7f95c135fa213b736b268699ba563496bba2680d59b11bafb4d4c3247b33d7742965e76342c43b4d', 18, 1, 'authToken', '[]', 0, '2020-10-07 13:13:46', '2020-10-07 13:13:46', '2021-10-07 14:13:46'),
('7fb4e9355f496349e75a002ad9c4aed03f1348b01459547bb59b7f591d699a86d11f794b465a88e5', 3, 1, 'authToken', '[]', 0, '2020-10-14 06:48:43', '2020-10-14 06:48:43', '2021-10-14 07:48:43'),
('8042656cfa2d3e647b3d2f9c3ca5bf142275853c0dc83fe2b9e565430fedcfad0ec45c5665ebce23', 3, 1, 'authToken', '[]', 0, '2020-10-09 08:50:03', '2020-10-09 08:50:03', '2021-10-09 09:50:03'),
('809188dc54b647915f95331ae21f2e04dafeba17fb4b5d620c547929b7c48485e401d42a89a6b81d', 1, 1, 'authToken', '[]', 0, '2020-10-23 16:37:06', '2020-10-23 16:37:06', '2021-10-23 17:37:06'),
('835fb4caa3fe4b9ca446440164dca454d2e6b74b70413f346bfff61beb6ea7f8a51ea1fed80f896d', 1, 1, 'authToken', '[]', 0, '2020-11-20 09:57:01', '2020-11-20 09:57:01', '2021-11-20 10:57:01'),
('84c398277b92ce65f9056af3c00eac00d29bb8dee6f2c2af85ff39dc3f0b980ca9ded8f190ae4587', 3, 1, 'authToken', '[]', 0, '2020-11-18 15:40:46', '2020-11-18 15:40:46', '2021-11-18 16:40:46'),
('84cfb732d76d8cec214fd199cecf2d5c3f93fdcbf19ad732b9b7b41c879df9d52a56b63793b2d2a5', 3, 1, 'authToken', '[]', 0, '2020-10-02 15:32:26', '2020-10-02 15:32:26', '2021-10-02 16:32:26'),
('8547cc9d506368e2b34f76da5eb06a709f6437d2a7a773bae2cd6041f976719ba2a1ced5f053ec91', 1, 1, 'authToken', '[]', 0, '2020-11-20 09:32:41', '2020-11-20 09:32:41', '2021-11-20 10:32:41'),
('8549197483fcee9c32c86edae6ff30427b17357533b1fdd7f12748e576266dfc435afbd2dd70c84c', 3, 1, 'authToken', '[]', 0, '2020-11-02 14:02:05', '2020-11-02 14:02:05', '2021-11-02 15:02:05'),
('858f763d9acfbce76467807e260ea0cd67871d9d81af0e48b4d65d99d27b9a783f403d76c5da5260', 3, 1, 'authToken', '[]', 0, '2020-11-20 09:22:03', '2020-11-20 09:22:03', '2021-11-20 10:22:03'),
('86040b12d7b196a771a7435018c203a75e8331e6c6ce1735bebe74b312882bd824af1a75b30b0545', 1, 1, 'authToken', '[]', 0, '2020-10-01 14:55:21', '2020-10-01 14:55:21', '2021-10-01 15:55:21'),
('86089e6a13d61eeffc7a14f39a5397fc716e7e9f732e73b6173de85e12c27437c3a7031dea7774b4', 3, 1, 'authToken', '[]', 0, '2020-10-13 09:22:42', '2020-10-13 09:22:42', '2021-10-13 10:22:42'),
('86d915666a683989dfdbbcb65e5ea24c0ad0c5f7f5278d33b13f59528ab0c38e7ee43ef0c76d9d5f', 3, 1, 'authToken', '[]', 0, '2020-10-26 15:13:41', '2020-10-26 15:13:41', '2021-10-26 16:13:41'),
('870b073b16c144876df6c30ff0398fe1a4293e8d09338709a13f7c7beda29e6a9d8c73f0585ac942', 1, 1, 'authToken', '[]', 0, '2020-10-01 13:40:19', '2020-10-01 13:40:19', '2021-10-01 14:40:19'),
('873c4efdac9008ced651a62269b33b6fdd81e9ec6ae809bff039bcdad2744bdf17347435c5190fae', 1, 1, 'authToken', '[]', 0, '2020-10-22 12:19:47', '2020-10-22 12:19:47', '2021-10-22 13:19:47'),
('87f92f1b9fbad08fe9311a6ef1c055b7c1c9ff6da8fa8724c56286a2a148b8b8c656051e230f731b', 3, 1, 'authToken', '[]', 0, '2020-10-13 09:22:48', '2020-10-13 09:22:48', '2021-10-13 10:22:48'),
('87fa68a5e6eeeaca8e9a1a7c6692a149da25012b5c2c1b298a5760bd3160cd992873aeb12b608042', 1, 1, 'authToken', '[]', 0, '2020-11-20 09:49:59', '2020-11-20 09:49:59', '2021-11-20 10:49:59'),
('88117ee6b41f5776dcbee42a8257ff519ff83809be53f54259662b30f89432340fd6aa2a88310b80', 2, 1, 'authToken', '[]', 0, '2020-10-27 12:20:44', '2020-10-27 12:20:44', '2021-10-27 13:20:44'),
('88358d98012f594b9cdd562f7c3fa80d3b006c465c3fa9bf0ed82393ece6e5dee96dde8b0334cfdf', 1, 1, 'authToken', '[]', 0, '2020-10-27 09:58:17', '2020-10-27 09:58:17', '2021-10-27 10:58:17'),
('883d8d5d398cc92d420bc60e6e7f33068b6cc95a9ed81fa056e780bf7203b780bebc6229f1e2a667', 1, 1, 'authToken', '[]', 0, '2020-10-16 09:06:36', '2020-10-16 09:06:36', '2021-10-16 10:06:36'),
('89208740b711027475419ab6ae942e7507bd0a4a79d55a332fb1992eb9f4740033c330d3a18303ed', 1, 1, 'authToken', '[]', 0, '2020-10-27 15:49:50', '2020-10-27 15:49:50', '2021-10-27 16:49:50'),
('8923a7d553953edfecc4516d65c57d42eaeebb6b173842fce2b4ae6fb2d1d1d79f5c9c5e6c20c13c', 1, 1, 'authToken', '[]', 0, '2020-09-30 15:57:03', '2020-09-30 15:57:03', '2021-09-30 16:57:03'),
('89452ceacab6d782a9e20225090f56f0d4fb3232aff18c634e436703578ba7df4168953c171290c0', 1, 1, 'authToken', '[]', 0, '2020-11-02 15:32:07', '2020-11-02 15:32:07', '2021-11-02 16:32:07'),
('89918ac4ce29cfa55b36ec85561c4cb4c13e75a7eff7f5607d5fffdd4d72579a4c5a76c0834383d7', 1, 1, 'authToken', '[]', 0, '2020-10-12 07:33:10', '2020-10-12 07:33:10', '2021-10-12 08:33:10'),
('89b814c96f2c682ffc84315b679213223e2a0a026e6e6d3812310ac7ef23f88ca3d2d82f22f414c8', 1, 1, 'authToken', '[]', 0, '2020-10-01 12:35:05', '2020-10-01 12:35:05', '2021-10-01 13:35:05'),
('8a56ee4cd41fc8168444350cd1a7f5a6bca7c1d98525d3095a97843d7f1dcbf87fede02e1dca8a25', 1, 1, 'authToken', '[]', 0, '2020-10-21 14:18:35', '2020-10-21 14:18:35', '2021-10-21 15:18:35'),
('8b5d668e01f8253ce8a6f4fccbd454a3de0e70001e4b0e8c120e578bc0c549df6641d5f98a83fb8a', 3, 1, 'authToken', '[]', 0, '2020-10-16 08:26:58', '2020-10-16 08:26:58', '2021-10-16 09:26:58'),
('8bb8b67b432c4e4c2a166611a0fc38aaea7ab6fc8062347ab9a974ca7c26a23001000b8b58314ce0', 1, 1, 'authToken', '[]', 0, '2020-09-29 07:07:02', '2020-09-29 07:07:02', '2021-09-29 08:07:02'),
('8be88b1f8c13d0374013081caafbcfba3703443847380cd4bda30be57885c641a1e8a2b0354d9274', 3, 1, 'authToken', '[]', 0, '2020-10-02 11:16:44', '2020-10-02 11:16:44', '2021-10-02 12:16:44'),
('8c6a6deb4aa076ec74776adb9a7d2f5aabd9c7743b3461908e439fdafa63949d79057ff566d0e289', 26, 1, 'authToken', '[]', 0, '2020-10-07 13:35:18', '2020-10-07 13:35:18', '2021-10-07 14:35:18'),
('8d7f074f5279cf785fa656d431c33e80f9986732278509b85c887a64c5f9c600d3d44c1ba1cf545e', 3, 1, 'authToken', '[]', 0, '2020-10-26 13:48:07', '2020-10-26 13:48:07', '2021-10-26 14:48:07'),
('8e037638899154524d5665f33fb727eeaf9598f977d087774f2cb240a939170fd76ec9f374b11883', 1, 1, 'authToken', '[]', 0, '2020-09-30 06:39:46', '2020-09-30 06:39:46', '2021-09-30 07:39:46'),
('8e1ddaaa81dad3fad878ea3bcc304887f2d36a0a10576afa781139668cbeda3449a3e07f1a4beafa', 1, 1, 'authToken', '[]', 0, '2020-09-30 08:32:45', '2020-09-30 08:32:45', '2021-09-30 09:32:45'),
('8e32fc92c624dd7768eca4bb092b12920a88b5524e17eacd8eba873faa7791adc19fc0bda4dc275c', 1, 1, 'authToken', '[]', 0, '2020-11-04 10:02:10', '2020-11-04 10:02:10', '2021-11-04 11:02:10'),
('8f122a71a382bc7239d34e67c418d2ce72b73266645a21f9d1993df332d5af56a85c46fa9e6e3b51', 3, 1, 'authToken', '[]', 0, '2020-10-15 14:03:35', '2020-10-15 14:03:35', '2021-10-15 15:03:35'),
('8f24fbdfe9f4b9f7f1e6ff4839e3cb915ab6f3b0d3e3d918f1527ea25d684a12684870c1ae9edcea', 3, 1, 'authToken', '[]', 0, '2020-10-30 16:29:29', '2020-10-30 16:29:29', '2021-10-30 17:29:29'),
('90ffa18b2939f8b68b875be9669ec9f8db916eb10a98b28afbdef630a9b88fb950ac730b6674cec9', 12, 1, 'authToken', '[]', 0, '2020-10-07 13:03:22', '2020-10-07 13:03:22', '2021-10-07 14:03:22'),
('91294edfab44f616c8f8d0b49d5fe3374d13ef4c20b7de0664cc2cedeadb9542ab03413d065ed4d0', 1, 1, 'authToken', '[]', 0, '2020-10-16 13:37:49', '2020-10-16 13:37:49', '2021-10-16 14:37:49'),
('917322511c79febcd1c73e5d2ca0645b384e18f4adca74a9fc37f783eaef1e08e922761da58c00dd', 14, 1, 'authToken', '[]', 0, '2020-10-07 13:06:53', '2020-10-07 13:06:53', '2021-10-07 14:06:53'),
('918eed30d563d5b823366cbf37e364c23d9d8cd5be736eb6f1b3c1798dff9f85bdfc2b6fb37337e4', 3, 1, 'authToken', '[]', 0, '2020-11-13 14:55:16', '2020-11-13 14:55:16', '2021-11-13 15:55:16'),
('93c0cd90655deac6366052d0175eff3fd7e8737499a98776a28ce9d6adc5317004b1234617fc3d77', 1, 1, 'authToken', '[]', 0, '2020-10-19 14:01:29', '2020-10-19 14:01:29', '2021-10-19 15:01:29'),
('94324d3cef706d732e3cbb6db29109ef2b824854695d01a81380c438275bba7c7a335d2a40eddff6', 1, 1, 'authToken', '[]', 0, '2020-11-20 07:53:48', '2020-11-20 07:53:48', '2021-11-20 08:53:48'),
('947d1a6bf40d85e65e0c28b1d3b8e4f595b255ee94dcd4eff5241a8bd800b14cdff4a72bf2abf377', 1, 1, 'authToken', '[]', 0, '2020-10-19 06:46:58', '2020-10-19 06:46:58', '2021-10-19 07:46:58'),
('95001245ab226f14c487625b5b7d15f88a4e40dd20c35f23195b7e5b4d0e5bcfe5c26bba35a48418', 3, 1, 'authToken', '[]', 0, '2020-11-18 05:51:53', '2020-11-18 05:51:53', '2021-11-18 06:51:53'),
('954c3cc562b4a6b1edf1578c5824be95f566f4979f8a1d0e1ef94d8aba4fbcd8d3e85f3763646b60', 3, 1, 'authToken', '[]', 0, '2020-10-27 14:09:27', '2020-10-27 14:09:27', '2021-10-27 15:09:27'),
('96cde2c42e4883b98368b362f8ac5227e2f0257dd1a72269f9ca2bd6ba7123a04031d740c750ed6b', 1, 1, 'authToken', '[]', 0, '2020-11-03 08:13:12', '2020-11-03 08:13:12', '2021-11-03 09:13:12'),
('98b0c054df18bc31b51d20de98c83c5c01ef5f5272762506f4f1869fefa7c9e492a46ba0c4a80d43', 1, 1, 'authToken', '[]', 0, '2020-11-20 07:43:27', '2020-11-20 07:43:27', '2021-11-20 08:43:27'),
('98d9609a7fb17ac2f956cf360cb70770c92ae8faf6d97ec10aa09abb82da93f0cea5d10a5096f9b5', 1, 1, 'authToken', '[]', 0, '2020-10-01 10:02:47', '2020-10-01 10:02:47', '2021-10-01 11:02:47'),
('98f832052f2124bf8c639c4a70a17d841f35f2f47604c3e948aaf9205bad60a938d5c38fb335b076', 1, 1, 'authToken', '[]', 0, '2020-10-02 12:23:00', '2020-10-02 12:23:00', '2021-10-02 13:23:00'),
('9907024a513ae04adfe173ddffcf87ef40a4c89afde7a82339a33fbc71258c961d670ea2b250d93a', 3, 1, 'authToken', '[]', 0, '2020-11-17 06:29:38', '2020-11-17 06:29:38', '2021-11-17 07:29:38'),
('9916687075180fef917934c89aa9f926db6f284a6abe58d31f75bb6e9551f4a12e51345f41cd504a', 3, 1, 'authToken', '[]', 0, '2020-11-13 09:45:32', '2020-11-13 09:45:32', '2021-11-13 10:45:32'),
('99415c613d927810dde0c7f230f67ba3cc1029c719dbe5347a30174082eacc9c13a390e4a438eec1', 1, 1, 'authToken', '[]', 0, '2020-11-02 14:11:37', '2020-11-02 14:11:37', '2021-11-02 15:11:37'),
('99c9cefdc6b793fa1f8041c930a3231f6aada2e59be961b1f4722eb3c076aec0f9d3b3964bd788f1', 1, 1, 'authToken', '[]', 0, '2020-10-12 07:33:10', '2020-10-12 07:33:10', '2021-10-12 08:33:10'),
('9a2b3215b639a85e03569121c56adef8b506e68bc0c93044929d6b10ee3fd85fca69141c846a4f2b', 1, 1, 'authToken', '[]', 0, '2020-09-29 13:55:34', '2020-09-29 13:55:34', '2021-09-29 14:55:34'),
('9a7797a6dc1ab0591f512daca4e7f21ae4e997a8e8b049b17b86708304d7126e97c2640be51cfe5e', 1, 1, 'authToken', '[]', 0, '2020-11-03 09:40:46', '2020-11-03 09:40:46', '2021-11-03 10:40:46'),
('9ab117b30ae3bd0c360b111243247881bb4194f40358380ea8a2c84c986796dc2c2e23b9a552e3a2', 1, 1, 'authToken', '[]', 0, '2020-09-30 07:37:33', '2020-09-30 07:37:33', '2021-09-30 08:37:33'),
('9b9c360cfa3062962bc5dc21dadf27ef1d86312c1f6101c98cf7f0ab9cad1f6205d28144ffa350f9', 24, 1, 'authToken', '[]', 0, '2020-10-07 13:33:15', '2020-10-07 13:33:15', '2021-10-07 14:33:15'),
('9bb6f57a2c623dc066da12dad2ad76f68ad2ba6fd40e4c9129e5df51bc2f47baf7a64244b6232ea9', 1, 1, 'authToken', '[]', 0, '2020-10-27 10:06:06', '2020-10-27 10:06:06', '2021-10-27 11:06:06'),
('9c681acbca8d9b0a3acdd8dc4dbb66852bcadfd9baff7a3c525aa8b5f30b3ec2e020fa20aee58c83', 3, 1, 'authToken', '[]', 0, '2020-10-14 10:05:41', '2020-10-14 10:05:41', '2021-10-14 11:05:41'),
('9df1bdcb2236e9bde5f4dbceb0c9f79b01eaa5057172d4f72013cbf443ab7da0441daf1a2df10081', 1, 1, 'authToken', '[]', 0, '2020-10-08 16:47:53', '2020-10-08 16:47:53', '2021-10-08 17:47:53'),
('9e0618e993a2b46227e8106655623e299a3c7a58fa2a04e262e2862d19c326ca63cd979d7e2d9250', 3, 1, 'authToken', '[]', 0, '2020-10-05 08:14:49', '2020-10-05 08:14:49', '2021-10-05 09:14:49'),
('9e213d5667a5a6f32af455f4da68805f2ac4cd7fa3d873d219b254f00d6f6ddd863b23f5bcd5925a', 3, 1, 'authToken', '[]', 0, '2020-10-02 12:27:07', '2020-10-02 12:27:07', '2021-10-02 13:27:07'),
('9eaaeaf8642f9aff536b0fd3c063db5d7e51a6967d3f4cd3b60efeedd138a5a5e3b68d791121be63', 1, 1, 'authToken', '[]', 0, '2020-10-20 17:20:36', '2020-10-20 17:20:36', '2021-10-20 18:20:36');
INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('9efc96c54fccd0642b56cb681a19a01f93389bcc29e56f6b8f53fb973c6cb2aa259d55a5c5777f9d', 3, 1, 'authToken', '[]', 0, '2020-10-27 10:39:11', '2020-10-27 10:39:11', '2021-10-27 11:39:11'),
('9f6ef31c13e3786865f65da6e4139c7321babbf3f27105f16a8477659487d41fe579fb582fda217c', 3, 1, 'authToken', '[]', 0, '2020-11-13 09:58:14', '2020-11-13 09:58:14', '2021-11-13 10:58:14'),
('9fa79a5041f34fbcb917d9e2cbaaa010aee7793d010a48990f0fa54118601c60151ae9a679b4fef8', 1, 1, 'authToken', '[]', 0, '2020-10-01 10:12:30', '2020-10-01 10:12:30', '2021-10-01 11:12:30'),
('a14422a60168ca5559b42f01562e68ad7dee05f27824e67917988bed25068a4b8dfcf06f5e2ff862', 1, 1, 'authToken', '[]', 0, '2020-10-21 15:08:44', '2020-10-21 15:08:44', '2021-10-21 16:08:44'),
('a176852b720d1c8c739a432596d511b8429139c9e9bf603b6d5d2ab740590b6c3912dbf5b335fc5b', 1, 1, 'authToken', '[]', 0, '2020-09-29 07:06:57', '2020-09-29 07:06:57', '2021-09-29 08:06:57'),
('a1bc8d71be4766eb3e352dfe64426577e75a190530c5e6b4879e76bb0576b5c9f1b916414d3d6509', 3, 1, 'authToken', '[]', 0, '2020-10-26 14:32:40', '2020-10-26 14:32:40', '2021-10-26 15:32:40'),
('a22211056fdd949125c3c818b422fcc36204439993b02d65b2837d14e329ac6041a2075d38265f33', 1, 1, 'authToken', '[]', 0, '2020-09-29 15:17:15', '2020-09-29 15:17:15', '2021-09-29 16:17:15'),
('a2984d84f84ae5683a57b1b83452e1f4184a893914129c60bbfc748b4f6ee5164067d9f235924fd3', 34, 1, 'authToken', '[]', 0, '2020-10-07 13:44:41', '2020-10-07 13:44:41', '2021-10-07 14:44:41'),
('a36826cb230e9d5bf97d135dd516ce389454a020702d376c4f1486d4e1d3b0fed4b1a6af9f028378', 1, 1, 'authToken', '[]', 0, '2020-09-28 08:03:43', '2020-09-28 08:03:43', '2021-09-28 09:03:43'),
('a4839c052d26719171f259e9b2a09b7e9d59301cfd5ceb93ca3ea110c635f2c582696a34950fee32', 1, 1, 'authToken', '[]', 0, '2020-10-21 14:18:35', '2020-10-21 14:18:35', '2021-10-21 15:18:35'),
('a49edc91e34888c7a000b18691516ee12c92c0e6c3372fcef3e86505ba4796c16f5b320a5c8a5cb9', 3, 1, 'authToken', '[]', 0, '2020-10-27 15:56:17', '2020-10-27 15:56:17', '2021-10-27 16:56:17'),
('a522eb0fbe0e1107cbc45ff4a5ccbc2ced2d5f409996a8eddad88919320747b796d8e6a9774322c4', 38, 1, 'authToken', '[]', 0, '2020-10-16 09:36:17', '2020-10-16 09:36:17', '2021-10-16 10:36:17'),
('a556f891d2512aea8a4e0c46cb9d992aba9c6227aa3c30faef4ed582a71f279dd7f71762e58cf42c', 1, 1, 'authToken', '[]', 0, '2020-11-04 09:16:46', '2020-11-04 09:16:46', '2021-11-04 10:16:46'),
('a5bf6aef4fe9cf27af3750992adaf704836acbd793065447f2f5fe8513bc8f9ff2b8f5eb139e0ee3', 1, 1, 'authToken', '[]', 0, '2020-11-02 14:06:43', '2020-11-02 14:06:43', '2021-11-02 15:06:43'),
('a6fb26b230e20679479909c3898d4e6f6cb1e0c0b2d671cdb14738ef42a484b93295bcfac94e5ec7', 1, 1, 'authToken', '[]', 0, '2020-10-20 18:04:20', '2020-10-20 18:04:20', '2021-10-20 19:04:20'),
('a75ab9eafeff153248aaac124a9ecfce8ba4254f69f3bea8910eca297c0831f257a364e58c6fb9f9', 23, 1, 'authToken', '[]', 0, '2020-10-07 13:31:50', '2020-10-07 13:31:50', '2021-10-07 14:31:50'),
('a921a552e569b4ed42b26e0fcdde0cfcf67d835037033045dc5a2ea5178fda45f0e6757c77f0039b', 1, 1, 'authToken', '[]', 0, '2020-10-20 17:24:04', '2020-10-20 17:24:04', '2021-10-20 18:24:04'),
('aa076a6199dd0092629d82d7708ef2166a753adcb3c4829e873f77032def20103c2a3760efa26975', 1, 1, 'authToken', '[]', 0, '2020-10-01 12:33:08', '2020-10-01 12:33:08', '2021-10-01 13:33:08'),
('aa24c665be12022dfebd32f6819db9f2cd64c243690a13aa81795ae7ed4cbd5e5da3bef079b62d77', 1, 1, 'authToken', '[]', 0, '2020-10-23 14:51:06', '2020-10-23 14:51:06', '2021-10-23 15:51:06'),
('aa9790d1c91ab71f944b7e5186961ac54b2e3ad8826470e92e4e583eb4b5d7a21aab0647ea15cab5', 1, 1, 'authToken', '[]', 0, '2020-11-02 14:44:18', '2020-11-02 14:44:18', '2021-11-02 15:44:18'),
('aafebbb03c1345549669cdb9923befc6fb27fc2ccc8b393902c819f9452904c653508d11318db65c', 1, 1, 'authToken', '[]', 0, '2020-11-20 09:25:42', '2020-11-20 09:25:42', '2021-11-20 10:25:42'),
('ac2cb06623470ac92509430e6964777d0f26b1272a291c32f38dce2e29c90b5d30d39a278fb96bd2', 3, 1, 'authToken', '[]', 0, '2020-11-17 06:29:45', '2020-11-17 06:29:45', '2021-11-17 07:29:45'),
('ac8043ae4f10cae901e4d5523bc8134822eeb6b4586ba191b420a5c3d052f0f53dfd00b750628820', 3, 1, 'authToken', '[]', 0, '2020-10-08 09:03:52', '2020-10-08 09:03:52', '2021-10-08 10:03:52'),
('ae3b1d33163ebfb0c83031309d26bd74d9f023b4fbdd04bddd1fe81848226b7d5a26f4faccaef60f', 29, 1, 'authToken', '[]', 0, '2020-10-07 13:39:02', '2020-10-07 13:39:02', '2021-10-07 14:39:02'),
('ae6180f289613ae3fbb17e222d54d265213fcf9578fbe3f4a3c02dc9240ab449358e5c4240121ea1', 3, 1, 'authToken', '[]', 0, '2020-10-08 16:14:14', '2020-10-08 16:14:14', '2021-10-08 17:14:14'),
('af703c96c1495211f5908a56f8ba013e841b31e8b58de9780f6535a5b8507e96bb485c640e8af388', 3, 1, 'authToken', '[]', 0, '2020-10-12 16:29:04', '2020-10-12 16:29:04', '2021-10-12 17:29:04'),
('aff7647c967a02c58950e509355cc25da9c2505f3996e9c42e03159c811e30d0f88a0c7d37af4600', 45, 1, 'authToken', '[]', 0, '2020-10-07 14:20:17', '2020-10-07 14:20:17', '2021-10-07 15:20:17'),
('b05e1379d0a93c80f8b2cf9899687c2e5dced59ee2c55c37a1583e2b31e158e8483724d4292f6aa7', 3, 1, 'authToken', '[]', 0, '2020-11-20 09:24:04', '2020-11-20 09:24:04', '2021-11-20 10:24:04'),
('b12ee6fb4d1e48de89889e94d4ec869c4cb7298d73c8f91f498523b7106695789b3f62dc6c8de3f5', 38, 1, 'authToken', '[]', 0, '2020-10-07 14:12:41', '2020-10-07 14:12:41', '2021-10-07 15:12:41'),
('b14b81aa136f35a69388c745b2f1a295bda73021bdaf541ac5e2cff4e7d31182cf1dfe58cc952980', 41, 1, 'authToken', '[]', 0, '2020-10-07 14:16:05', '2020-10-07 14:16:05', '2021-10-07 15:16:05'),
('b2281308223eb93c126569e3bda53626d81ad7f97369dad441a42972261e4502c93ce74e3feddfff', 37, 1, 'authToken', '[]', 0, '2020-10-07 14:11:11', '2020-10-07 14:11:11', '2021-10-07 15:11:11'),
('b27ef6a15bea198ffa3d9735ed4ac6ac61372be16fa56f6fdff720cfe66b70352b8c8087e71bba31', 19, 1, 'authToken', '[]', 0, '2020-10-07 13:15:56', '2020-10-07 13:15:56', '2021-10-07 14:15:56'),
('b2dc5694dafbec1425a042f63b4e3d85998579ca994c9f933bddfd6ac696d60e58df89ba7b24d462', 16, 1, 'authToken', '[]', 0, '2020-10-07 13:10:59', '2020-10-07 13:10:59', '2021-10-07 14:10:59'),
('b41eb2d8a7774161e5026471eef314555f0efebdf0f4b17df3d7a9e8b3583345fbaa717a1906a792', 8, 1, 'authToken', '[]', 0, '2020-10-07 12:54:18', '2020-10-07 12:54:18', '2021-10-07 13:54:18'),
('b4b22eeab52383cec35345bc213601b959d195be09f56a83f781396a443f2562ff9a5350d47ab9c4', 3, 1, 'authToken', '[]', 0, '2020-11-17 14:23:54', '2020-11-17 14:23:54', '2021-11-17 15:23:54'),
('b4c3d20b348272d8a6018213c31c2e56c0333b88d3ad30235eaf1feadfee880de2d7717d1009ff45', 3, 1, 'authToken', '[]', 0, '2020-10-08 08:47:54', '2020-10-08 08:47:54', '2021-10-08 09:47:54'),
('b56d470026bbfa7141a92aced08082a01e1d49123a6ef0bf7849dcc287621ec4134c8a0eb1bb07eb', 1, 1, 'authToken', '[]', 0, '2020-10-09 10:53:46', '2020-10-09 10:53:46', '2021-10-09 11:53:46'),
('b5c0751e9c68097852662ba5bdf261b1656a2007d9260ee97efeb3f649cd2125bd5d316fdd11e7f0', 1, 1, 'authToken', '[]', 0, '2020-10-26 08:36:58', '2020-10-26 08:36:58', '2021-10-26 09:36:58'),
('b64f4ed3d47ba31871cd5a871a80b9a6f0fcbfa55afc77f1a7175728be6cfcb78c9a6d042014bc9d', 1, 1, 'authToken', '[]', 0, '2020-11-02 14:48:37', '2020-11-02 14:48:37', '2021-11-02 15:48:37'),
('b70950d7a65f4164aec347de90b8bf76892cfa0527ed692781531f4d8f3a0bbccf59322daa2cfc72', 3, 1, 'authToken', '[]', 0, '2020-11-20 06:04:02', '2020-11-20 06:04:02', '2021-11-20 07:04:02'),
('b71a727d52e09ba77150ef67897fef578288f9df65041d03286bb7826428ac2a21eb67d3864c7e21', 35, 1, 'authToken', '[]', 0, '2020-10-07 13:45:22', '2020-10-07 13:45:22', '2021-10-07 14:45:22'),
('b73065b63284dffb97785f93a7bdf4c0cd1e7b68fbed6f4e6aa25a2538975091b94571fde0fea8fb', 3, 1, 'authToken', '[]', 0, '2020-11-13 11:00:09', '2020-11-13 11:00:09', '2021-11-13 12:00:09'),
('b9c28abe98dce7888594deab39595b54b884d248f686a21e42f737ce092e49ada386478cd6792c82', 1, 1, 'authToken', '[]', 0, '2020-11-03 12:43:20', '2020-11-03 12:43:20', '2021-11-03 13:43:20'),
('ba15c607575cde596fb789263972e605ca4de0cf0be6da65c6002866112c59b63580a562dbb3dd86', 3, 1, 'authToken', '[]', 0, '2020-10-28 07:05:07', '2020-10-28 07:05:07', '2021-10-28 08:05:07'),
('bad532a515e09b21912dceba5211891c9ef5bcd0dc8f95a7ff5e2d6cc85ee02c4f3b3210ab87de9a', 1, 1, 'authToken', '[]', 0, '2020-10-15 07:58:42', '2020-10-15 07:58:42', '2021-10-15 08:58:42'),
('bba1cc224c004e9bd1f9a91c5d8a57c3534443fde08de57312ac7ba4f5fc326728d41dc9dccc50a4', 1, 1, 'authToken', '[]', 0, '2020-10-13 14:29:22', '2020-10-13 14:29:22', '2021-10-13 15:29:22'),
('bbc053d46cd97abcf0d7e0f5b577f4acdb00de4a7b51952b3777ab23e533139f6d0813c5e17cc22a', 48, 1, 'authToken', '[]', 0, '2020-10-07 14:27:11', '2020-10-07 14:27:11', '2021-10-07 15:27:11'),
('bc9763cc8cb5309f144c54c6773fea05e36deafa220877d3a9c19d3412a034224870caebb015f80a', 3, 1, 'authToken', '[]', 0, '2020-11-17 13:57:24', '2020-11-17 13:57:24', '2021-11-17 14:57:24'),
('bce5a75c1abd9df9a5cfb45c28e11c139dbbc1fbd4ec3b55f2d8260a1eebb606885f5c0fd2b4330f', 3, 1, 'authToken', '[]', 0, '2020-11-17 14:21:12', '2020-11-17 14:21:12', '2021-11-17 15:21:12'),
('bd218ec35d451500903ae0d472c104584a57cff13254d79efb94777f2d7466861b358fcb99aecd23', 3, 1, 'authToken', '[]', 0, '2020-11-19 14:25:19', '2020-11-19 14:25:19', '2021-11-19 15:25:19'),
('bd3d81409d15d17bb4174f2e3bd2d5906faefb90559a1bd6cc585c4ed73e6425cfe68698cfced45e', 2, 1, 'authToken', '[]', 0, '2020-10-26 16:42:23', '2020-10-26 16:42:23', '2021-10-26 17:42:23'),
('bded838ff6025d6bea850a07e15f75bdf0c136979b614382e14cbe5b1265d17f0125ae3d76fbf50d', 3, 1, 'authToken', '[]', 0, '2020-11-20 09:49:18', '2020-11-20 09:49:18', '2021-11-20 10:49:18'),
('be3ce092eb4305ab4816c192dab066e96370bacd40e09a208ee49bdfab07f392cf4d62f46643891b', 3, 1, 'authToken', '[]', 0, '2020-11-13 09:37:33', '2020-11-13 09:37:33', '2021-11-13 10:37:33'),
('beb053b81094cee906e4e675e6dd2c43702ec69f0d868c5c426cbec4cbbd71c27b2effe21190c5e3', 1, 1, 'authToken', '[]', 0, '2020-11-03 10:22:56', '2020-11-03 10:22:56', '2021-11-03 11:22:56'),
('bf0fb64c1d949a437febe212a268f2a0e03a758e0ebe6b1558fe5213bd92bac628d78aa98b6f67b8', 1, 1, 'authToken', '[]', 0, '2020-10-13 13:05:53', '2020-10-13 13:05:53', '2021-10-13 14:05:53'),
('c173451346ae0004cb3631d855e5b31d5cd1029e36d0745a9e9b9738337cf878c589424977abde93', 1, 1, 'authToken', '[]', 0, '2020-11-04 10:40:49', '2020-11-04 10:40:49', '2021-11-04 11:40:49'),
('c1e425f205b2f01a7179452f0f659412d069cebbbc049931ae9426fb6a6af1379fe1076408e815d8', 3, 1, 'authToken', '[]', 0, '2020-09-28 09:31:21', '2020-09-28 09:31:21', '2021-09-28 10:31:21'),
('c24dc5e331056ef5dbd2cb1075f957ee12b0bcdc9f25948498a13e6d4396e1c4476a6a8b1c2b2b45', 1, 1, 'authToken', '[]', 0, '2020-11-02 15:43:30', '2020-11-02 15:43:30', '2021-11-02 16:43:30'),
('c35e2b42cb0ebce2386a86f56a67afa15c860c6c8a8c1fa62a0223ea75511042451ac65e0e152a59', 3, 1, 'authToken', '[]', 0, '2020-10-14 15:04:42', '2020-10-14 15:04:42', '2021-10-14 16:04:42'),
('c375c91379e5af0d85b17c62464c83df2218b828868193ca15f2b3e4e44b94fd3780256cce00bfd7', 3, 1, 'authToken', '[]', 0, '2020-10-12 16:45:00', '2020-10-12 16:45:00', '2021-10-12 17:45:00'),
('c43f4977c9b91870009bfec870e7e9c4e2932d02a6ccca77491073e766d81b1f1af1a6bff74ccdd1', 3, 1, 'authToken', '[]', 0, '2020-10-16 12:43:45', '2020-10-16 12:43:45', '2021-10-16 13:43:45'),
('c48e18e033fb00b0475e34eb22f3587a22f956c66341633da8d56e47e7b0deca8fbf15009a61b36f', 1, 1, 'authToken', '[]', 0, '2020-10-16 13:18:40', '2020-10-16 13:18:40', '2021-10-16 14:18:40'),
('c522f24a7571916c481831bc8ea816e55be33c73f4beba349acb27a9a867010eb011e7feeff69c4c', 3, 1, 'authToken', '[]', 0, '2020-10-14 15:06:20', '2020-10-14 15:06:20', '2021-10-14 16:06:20'),
('c56401026af04e409cdcbdf4ad82cdab0593f0b664b77ed99dc4fe715d4f25b4eff8f557b41d843c', 25, 1, 'authToken', '[]', 0, '2020-10-07 13:34:03', '2020-10-07 13:34:03', '2021-10-07 14:34:03'),
('c5ef17c84f75e25d8768136f3b71f9e917fc88e98b00974167a6f4fba22031f602399abbd7931821', 42, 1, 'authToken', '[]', 0, '2020-10-07 14:17:25', '2020-10-07 14:17:25', '2021-10-07 15:17:25'),
('c8addd3234be1083ece6fecce4b2e51f3a1e0833c6150bd1b1f1b5475b4be0d72b76944bfdb64464', 1, 1, 'authToken', '[]', 0, '2020-10-21 14:18:33', '2020-10-21 14:18:33', '2021-10-21 15:18:33'),
('c8d215a9f94b4ebf603341f889939bee8cd5b55909c567dab4de2311a60df76e3f92798f2db0e739', 3, 1, 'authToken', '[]', 0, '2020-10-16 12:22:27', '2020-10-16 12:22:27', '2021-10-16 13:22:27'),
('c9169452a61519dd092c1707818c7b3eae5e3d359eb488fc4da1c641c0ccd8003f53103abddb9ed4', 3, 1, 'authToken', '[]', 0, '2020-10-26 15:36:49', '2020-10-26 15:36:49', '2021-10-26 16:36:49'),
('c98351bae4e550dc2d293515c42833f6a694df6e1347eed45c5494f0e4f06878581a35aef2d94847', 3, 1, 'authToken', '[]', 0, '2020-11-04 07:26:17', '2020-11-04 07:26:17', '2021-11-04 08:26:17'),
('cafe29413c6b8a27a6ce935ab16a39ac68cb96c41a73b25c24f7857bb58965d4fa8beb70a202f2b5', 46, 1, 'authToken', '[]', 0, '2020-10-07 14:22:07', '2020-10-07 14:22:07', '2021-10-07 15:22:07'),
('cb8f9c07cd83d7d53320d1bc94ccae414c6d0b06cbb46e1427eb0cdb70b182f205d45d1f154ab812', 1, 1, 'authToken', '[]', 0, '2020-10-21 09:27:56', '2020-10-21 09:27:56', '2021-10-21 10:27:56'),
('cc5e8cd4403a4d31b200c7d1013f294fa17455ea2a406d8131dabe73d9af46d3e420a417a22b75cc', 1, 1, 'authToken', '[]', 0, '2020-09-28 14:47:28', '2020-09-28 14:47:28', '2021-09-28 15:47:28'),
('cc7c89127e4821f49e6d146919e0e395f0ba506366a9e9bb2aec33daf0cbb2993b29041e389bc2d6', 1, 1, 'authToken', '[]', 0, '2020-11-02 14:31:54', '2020-11-02 14:31:54', '2021-11-02 15:31:54'),
('cd92e3968d32c5183573a3788ec5591ae5aecbbc8d188e0ce2ccfb69cf91f4939a26a58d1f936e20', 1, 1, 'authToken', '[]', 0, '2020-11-20 08:39:06', '2020-11-20 08:39:06', '2021-11-20 09:39:06'),
('ceb85a86fd3fcf1c899afe992af0fc97f733de94702eb233338599829a67eac9ab7defe9eb22db79', 1, 1, 'authToken', '[]', 0, '2020-11-20 08:45:44', '2020-11-20 08:45:44', '2021-11-20 09:45:44'),
('cfcae2d0d462e7375a46166b851a71c4989da34fff60a4a0109959ac319321416c244eb3635056c6', 3, 1, 'authToken', '[]', 0, '2020-10-07 15:14:29', '2020-10-07 15:14:29', '2021-10-07 16:14:29'),
('d0e24d9f8a7db0b3add974d2046f09f28adc5ed25e947af31524d6fceffcac3f5c8dc02a17933ba0', 1, 1, 'authToken', '[]', 0, '2020-10-01 10:07:57', '2020-10-01 10:07:57', '2021-10-01 11:07:57'),
('d1060338b5a55ed755ff31e1c53b3bde6fb42027c6f5762364d82b7635e5755dae54a310911f087d', 3, 1, 'authToken', '[]', 0, '2020-11-20 09:17:18', '2020-11-20 09:17:18', '2021-11-20 10:17:18'),
('d1482b117e3691f056c564a61b8c056f90c483662abdb7ae4ee411f602b75ece125bbaf56b8d673f', 1, 1, 'authToken', '[]', 0, '2020-10-12 07:33:10', '2020-10-12 07:33:10', '2021-10-12 08:33:10'),
('d15f4d61955389a2a3f428534ec701b8c8b4beb911cd72668ce85451868d2af820656d87d937c679', 3, 1, 'authToken', '[]', 0, '2020-10-08 09:58:57', '2020-10-08 09:58:57', '2021-10-08 10:58:57'),
('d22cb908b82f9a225df9fbf6394b5a6f35ee52fdc9a63f8b25835b2f050d67acf1b29db00db62944', 39, 1, 'authToken', '[]', 0, '2020-10-07 14:14:22', '2020-10-07 14:14:22', '2021-10-07 15:14:22'),
('d31a61f51f7dd8c2886bdf9d205e2fcc0ca8c48ec21c4487b559f359bda144d2071b087287eccac7', 3, 1, 'authToken', '[]', 0, '2020-11-18 13:15:13', '2020-11-18 13:15:13', '2021-11-18 14:15:13'),
('d3262721091fba3233bd599464f221c47db9805ee1fddcc76d74858d3c22d93bfeae4957a2f0f601', 1, 1, 'authToken', '[]', 0, '2020-11-03 07:16:45', '2020-11-03 07:16:45', '2021-11-03 08:16:45'),
('d4d5e39d79cdf41cf5ffba2abc5fe71af5a05271c1b3e3e9523af111d2d360dbdb01237b256357ab', 51, 1, 'authToken', '[]', 0, '2020-10-07 14:30:03', '2020-10-07 14:30:03', '2021-10-07 15:30:03'),
('d5911d5fffc93df27a62b50b2c8e1b7b0fd2cd7e9bace58261a0ac7b37957d71f400b23f15db5f25', 1, 1, 'authToken', '[]', 0, '2020-11-03 12:47:42', '2020-11-03 12:47:42', '2021-11-03 13:47:42'),
('d5b6945ed85f169806ac95eff9116cb649d5b1095d57ef24f55eb50906ab0345000f551dc048c623', 27, 1, 'authToken', '[]', 0, '2020-10-07 13:36:55', '2020-10-07 13:36:55', '2021-10-07 14:36:55'),
('d5eeb9967fde4ee508c01e3d28f70b3acfdd3d50253ac0d831a2e644f3f897e625da007c3312354e', 3, 1, 'authToken', '[]', 0, '2020-10-05 15:56:31', '2020-10-05 15:56:31', '2021-10-05 16:56:31'),
('d62fd82776840d2dcc2ec5c9f362422e03772f23b278bca31fddd30ad0810946529060c57604bbd4', 3, 1, 'authToken', '[]', 0, '2020-11-16 13:33:00', '2020-11-16 13:33:00', '2021-11-16 14:33:00'),
('d65c3b8c008bc4084193eb8e9d6569eeed8c32c70fd8260e90a6db145c6ad4ba8032c58c7d5d485f', 1, 1, 'authToken', '[]', 0, '2020-10-22 06:56:30', '2020-10-22 06:56:30', '2021-10-22 07:56:30'),
('d861fe75eb7a9a8b3ff324f7dc94930109ce2b51e41719e41abf00593413202db56dc965b929aabb', 3, 1, 'authToken', '[]', 0, '2020-11-20 09:48:50', '2020-11-20 09:48:50', '2021-11-20 10:48:50'),
('d8b6f379499a672e79cc027b38b3bdb8cbec57b2a345b6c1f903e5ac36a887df1924ca163f72bd70', 3, 1, 'authToken', '[]', 0, '2020-11-20 06:44:00', '2020-11-20 06:44:00', '2021-11-20 07:44:00'),
('d8f36a4ac2046f173ccfccf6038db910f05726569e0e5714a55cb6b4a9fabb6284429167f15af1e8', 1, 1, 'authToken', '[]', 0, '2020-10-05 07:15:43', '2020-10-05 07:15:43', '2021-10-05 08:15:43'),
('d9082bb8c916daa00fd3596af5a994ca01d8dc76b1691633346ef61a86709c441b01a631a2881bc4', 3, 1, 'authToken', '[]', 0, '2020-11-18 07:15:06', '2020-11-18 07:15:06', '2021-11-18 08:15:06'),
('d9d494c2e875570188623ead5f7a63a96cc64d0668ceae9d5c89d5eceddbb1153fc2f35e1cd14a04', 1, 1, 'authToken', '[]', 0, '2020-09-28 09:40:25', '2020-09-28 09:40:25', '2021-09-28 10:40:25'),
('da3bf100dc43dfa31400e3fabb064c3129ffe3b6f4b8cda1887d7867d0c932988f37b136d8117892', 21, 1, 'authToken', '[]', 0, '2020-10-07 13:29:22', '2020-10-07 13:29:22', '2021-10-07 14:29:22'),
('da6c5a455fba322736a92483d5c242edeffe2851340c31f030eace9fd792133175d5a98a77210fc0', 3, 1, 'authToken', '[]', 0, '2020-11-18 13:29:33', '2020-11-18 13:29:33', '2021-11-18 14:29:33'),
('db7a502d03761bb237ad8ca4cf4f747dfff9f5918b1f8159514d0b6b0c7062b6b3f31da3dc4297e6', 1, 1, 'authToken', '[]', 0, '2020-11-03 07:39:57', '2020-11-03 07:39:57', '2021-11-03 08:39:57'),
('dd577b28bc7f211833a05ac340da7243e71cb9ca2f92d283d7b88b3de21973ea0d37daafe0475d6f', 1, 1, 'authToken', '[]', 0, '2020-09-30 07:22:01', '2020-09-30 07:22:01', '2021-09-30 08:22:01'),
('de7f0272059242f03539ae1cd9089d5623b57d956be6412e8e871689bb5973b56984e8a1be7f892f', 1, 1, 'authToken', '[]', 0, '2020-11-04 07:19:44', '2020-11-04 07:19:44', '2021-11-04 08:19:44'),
('dfa6fc9cb4516f2c570ae065929db423c5536020f7fbfab543c93ccf42fd4f8775cb9a65c5ee56fc', 3, 1, 'authToken', '[]', 0, '2020-10-26 15:17:21', '2020-10-26 15:17:21', '2021-10-26 16:17:21'),
('dff9f939c1a9142fa6757d02b1186d0a4cfd89dcdb8fa189833857fe3371044b14c01fcb2ed735e7', 1, 1, 'authToken', '[]', 0, '2020-10-20 16:43:54', '2020-10-20 16:43:54', '2021-10-20 17:43:54'),
('e1962d155963649cb5ab2b839868178ec88f3639b667d4299f946577ffd1c76d3d19d698de499507', 52, 1, 'authToken', '[]', 0, '2020-10-07 14:32:05', '2020-10-07 14:32:05', '2021-10-07 15:32:05'),
('e1abc8e2073d9e0e7416a9b9dddc2c76248207bb069141d6d8bc3240adcd564e593ff6eda9852ac1', 1, 1, 'authToken', '[]', 0, '2020-09-30 14:21:42', '2020-09-30 14:21:42', '2021-09-30 15:21:42'),
('e1fa64f154a315249361835fd43f61b5749c219bb519e9f17b22045740ae80dfea6e062ba125ee05', 3, 1, 'authToken', '[]', 0, '2020-11-13 13:18:18', '2020-11-13 13:18:18', '2021-11-13 14:18:18'),
('e2c8e7ff7b979735eb51cce2ee5f1ef99f74d8aa133c2594194cf00bbe6c081c4b5e0a9917a7ba80', 3, 1, 'authToken', '[]', 0, '2020-10-16 12:09:23', '2020-10-16 12:09:23', '2021-10-16 13:09:23'),
('e306105d783fa52ac0db958c5d8e9cd77de28b5bbcc985ba4a41d58caee7ad0a38d92980567da87c', 3, 1, 'authToken', '[]', 0, '2020-10-08 16:20:21', '2020-10-08 16:20:21', '2021-10-08 17:20:21'),
('e31090dbb0f1097c2d6ea720f7ce92728c458fede6749c3a40eb8b994a9abffde9e056930fed9558', 1, 1, 'authToken', '[]', 0, '2020-10-23 16:41:54', '2020-10-23 16:41:54', '2021-10-23 17:41:54'),
('e49f70d3e7754a70b16f1905b48f6dcf06f14b3c132054ba35343ba78509d8a337e12b92ad611406', 1, 1, 'authToken', '[]', 0, '2020-11-20 09:44:09', '2020-11-20 09:44:09', '2021-11-20 10:44:09'),
('e4ee827163d4de9ad3ae4039757c347c98dd2f321d51fd52818cf3c34a2773d4a6955ca3110d3cac', 1, 1, 'authToken', '[]', 0, '2020-09-29 13:09:00', '2020-09-29 13:09:00', '2021-09-29 14:09:00'),
('e4f57a9a15af40ace3631abf641e46030b90e23e8cf7224e0dc357486423cdf3948edb7d98c98030', 1, 1, 'authToken', '[]', 0, '2020-10-12 15:33:17', '2020-10-12 15:33:17', '2021-10-12 16:33:17'),
('e504be0eaa0f25bf1855e73c9811e8b5ee50aee21b022fecc438431b90cea082a80833eb85169954', 1, 1, 'authToken', '[]', 0, '2020-10-21 06:39:16', '2020-10-21 06:39:16', '2021-10-21 07:39:16'),
('e5a10417d3327f16256ea4b0a728d138a091a8d33d4ef1acdc762b22fcfaed6b7e662d73175cefea', 1, 1, 'authToken', '[]', 0, '2020-10-19 10:07:27', '2020-10-19 10:07:27', '2021-10-19 11:07:27'),
('e5f84d31959a9aeb5898fb898cbbad74fa1b1e8c2ab21780eef4e3651e9237d6d0bdf7603e2b3f54', 3, 1, 'authToken', '[]', 0, '2020-10-16 06:40:04', '2020-10-16 06:40:04', '2021-10-16 07:40:04'),
('e61d8c11b1dfcfaa999c8a0bfeadd993de42679f1913df3e05edd5d7365bab1e0d34f6efa8c16269', 1, 1, 'authToken', '[]', 0, '2020-09-29 10:48:11', '2020-09-29 10:48:11', '2021-09-29 11:48:11'),
('e63564f78f26030fcfa780b74882135ef86681843e312e96016fed1f290b1dde338260be5662f819', 3, 1, 'authToken', '[]', 0, '2020-10-05 16:06:10', '2020-10-05 16:06:10', '2021-10-05 17:06:10'),
('e637c16948b4d4bc4087cf2a09b7647d0002117afdd650a8b8766045ebbbbc27e3fc3ff107509c63', 30, 1, 'authToken', '[]', 0, '2020-10-07 13:40:23', '2020-10-07 13:40:23', '2021-10-07 14:40:23'),
('e6af7795757be48827ee2f9a5e1eab920000f2fa932d005f31f27a85ead16cfc3371d2e925cf05fd', 3, 1, 'authToken', '[]', 0, '2020-11-20 09:17:19', '2020-11-20 09:17:19', '2021-11-20 10:17:19'),
('e6b3242d338f7ac753eb527dcc41f5d748f489cdca942f861bb064aab0d0a97f0f5dedadb959b43e', 1, 1, 'authToken', '[]', 0, '2020-10-21 16:51:39', '2020-10-21 16:51:39', '2021-10-21 17:51:39'),
('e6f59aae995fb284f4ef8947b4cb70c7262654951ed5593e8fa29343d8d361eed02690da0b355811', 1, 1, 'authToken', '[]', 0, '2020-10-23 16:48:59', '2020-10-23 16:48:59', '2021-10-23 17:48:59'),
('e7184bd36dee29bf506df13b6c8148b5feab599ad61ea088851f51972f7a7751eb7683c838f2edd4', 3, 1, 'authToken', '[]', 0, '2020-10-28 14:14:20', '2020-10-28 14:14:20', '2021-10-28 15:14:20'),
('e8035ff959977d0391155dd3763c8dd05b31d6f3c9af1f967e305d556f9af0ce1a64f596f7ac3665', 3, 1, 'authToken', '[]', 0, '2020-10-28 09:57:44', '2020-10-28 09:57:44', '2021-10-28 10:57:44'),
('e8bcabba0bde206d44e01112577c97c2471ad51315bbe5fde137a73c740009750d3505ab5c9638b6', 1, 1, 'authToken', '[]', 0, '2020-11-03 12:40:05', '2020-11-03 12:40:05', '2021-11-03 13:40:05'),
('e995e10bcf2e7b6ecc14adbc5af545217ee8666c6ab8d2ea97c6235fd0b81a75b6d872692f6971a4', 3, 1, 'authToken', '[]', 0, '2020-11-04 07:48:02', '2020-11-04 07:48:02', '2021-11-04 08:48:02'),
('ea3734a2740515fe2f8517f1b3aa1b8e4cfd0ab0924e0b19dac32172c946d1995f1a75b101efdf21', 3, 1, 'authToken', '[]', 0, '2020-11-20 06:18:39', '2020-11-20 06:18:39', '2021-11-20 07:18:39'),
('ea94feab0aa33ba674b558aaa70b8ecc01cf7c6a2292d43e2ea258df5afe2d78425fcb38008464b3', 3, 1, 'authToken', '[]', 0, '2020-11-16 13:34:25', '2020-11-16 13:34:25', '2021-11-16 14:34:25'),
('eb14cd2c4407fe4276c8b5808798cac90ce7311b2eb028815c02e61b2b7791b01aaf504d5e12d68a', 1, 1, 'authToken', '[]', 0, '2020-09-29 13:38:36', '2020-09-29 13:38:36', '2021-09-29 14:38:36'),
('ebbbc9f9d093ad58a36caed357d84635670c1a6956512713b00cba23fef65b7e0535a516030e6c24', 1, 1, 'authToken', '[]', 0, '2020-09-30 08:49:30', '2020-09-30 08:49:30', '2021-09-30 09:49:30'),
('ec862220e769218457106c919f9a674976aa6abe0b3a20f5568d3084eac0643ee7d3808de5b4020e', 1, 1, 'authToken', '[]', 0, '2020-11-03 12:41:54', '2020-11-03 12:41:54', '2021-11-03 13:41:54'),
('ec962f300cda0521c4b74c009a1c419fed81e2303b865a47a761be85929c59622c5983795489f95f', 3, 1, 'authToken', '[]', 0, '2020-11-04 06:36:49', '2020-11-04 06:36:49', '2021-11-04 07:36:49'),
('ece421e1a22fd9a86187bfcff245d300930039c66800e3be4e76b774b8803c72a9e07c865e8ddb9c', 3, 1, 'authToken', '[]', 0, '2020-10-29 06:48:45', '2020-10-29 06:48:45', '2021-10-29 07:48:45'),
('edb6e6b18b41c8da84feba9ea131058aa2b4d60f7b3c6ab93f8710b97eb415f8466b9fbf5a23b7a8', 1, 1, 'authToken', '[]', 0, '2020-09-30 14:27:28', '2020-09-30 14:27:28', '2021-09-30 15:27:28'),
('edff5481f87ebc28046765ccba5469f7169827af4fb4a9bbf2c925d0449134da129efce50a9ee294', 1, 1, 'authToken', '[]', 0, '2020-10-23 07:59:20', '2020-10-23 07:59:20', '2021-10-23 08:59:20'),
('ee7007d9157ef172c1af10f64c3a814d5f3ed6d4431ee59a86b34171164eb81fc6a5bd3764226985', 3, 1, 'authToken', '[]', 0, '2020-10-02 16:14:20', '2020-10-02 16:14:20', '2021-10-02 17:14:20'),
('eea21696f373dfd3add6db7dcf62ffc92de83ba44f2339b926c3aa77c28273108bac498f658eef30', 1, 1, 'authToken', '[]', 0, '2020-11-03 07:02:34', '2020-11-03 07:02:34', '2021-11-03 08:02:34'),
('eeb02a44386a46d79ce4bab07b14abf126886a32fa892fc0e0ad5eb39ff2ee3d087261bad1b85308', 1, 1, 'authToken', '[]', 0, '2020-10-22 13:29:23', '2020-10-22 13:29:23', '2021-10-22 14:29:23'),
('eec0e8253324c8301a8d66bb7135a9c7d2c0322d67e3c0684fba7662db56c3fc30b7e64a29abde78', 3, 1, 'authToken', '[]', 0, '2020-10-08 13:00:36', '2020-10-08 13:00:36', '2021-10-08 14:00:36'),
('eeec792e1d0add2935b26a829185c8c9f999fee995635a88c15a9a28b5f1f6579c66e9bad2158ffc', 47, 1, 'authToken', '[]', 0, '2020-10-07 14:22:52', '2020-10-07 14:22:52', '2021-10-07 15:22:52'),
('ef613c5312151f63229e5352ef0ef49133694163e75f8d37a9a7810f7e19693cc6d15e0d7ad5a935', 3, 1, 'authToken', '[]', 0, '2020-11-13 09:32:35', '2020-11-13 09:32:35', '2021-11-13 10:32:35'),
('ef62171fdbb5a9b6dbbef75f28947a2b42becd2bc6e14ac9e84df622ecba5bf2f264f55032b7d3a9', 3, 1, 'authToken', '[]', 0, '2020-11-19 09:20:01', '2020-11-19 09:20:01', '2021-11-19 10:20:01'),
('efbe5814544c0dfff09aaae79e327472662fdc903dfca3fc6fef95d6d4cf372deed98f5d719bae01', 1, 1, 'authToken', '[]', 0, '2020-09-28 09:16:26', '2020-09-28 09:16:26', '2021-09-28 10:16:26'),
('f0f830431585e0ee2af11911b273732e21e02fafda29f0ecbd402656ffbc06244f5190a37e6dc261', 1, 1, 'authToken', '[]', 0, '2020-10-01 12:35:09', '2020-10-01 12:35:09', '2021-10-01 13:35:09'),
('f1fec156ace7936542985a7ee1f806e0aeeb64940e048bd1cbf568ac0b3d782a1eda76a38d346263', 31, 1, 'authToken', '[]', 0, '2020-10-07 13:41:12', '2020-10-07 13:41:12', '2021-10-07 14:41:12'),
('f24bc4b29172c0b4353afa6f93d432397daeac513b44d2db0f3788bf1f98c096d27d2cfc5ca9711f', 11, 1, 'authToken', '[]', 0, '2020-10-07 13:02:26', '2020-10-07 13:02:26', '2021-10-07 14:02:26'),
('f3597baee4d474b6f3291ac1a51301cd9f0b256d600f72a063f05a76d322699847f04f0a713da3aa', 1, 1, 'authToken', '[]', 0, '2020-10-20 10:37:58', '2020-10-20 10:37:58', '2021-10-20 11:37:58'),
('f4019e9c385c8015e9cc9e46735a769e142b75fdc45e2cea64f59b57cdbb8ee68576f3758d41c26b', 1, 1, 'authToken', '[]', 0, '2020-09-28 15:55:05', '2020-09-28 15:55:05', '2021-09-28 16:55:05'),
('f4d33b7a63c9942977c936684f2fb1099cf78af2ffb7ed85027adb7ccc0a9470895292c317381af9', 2, 1, 'authToken', '[]', 0, '2020-10-27 07:44:01', '2020-10-27 07:44:01', '2021-10-27 08:44:01'),
('f5f5643e8522a7a042fb987b2f8354f9a2630ae086980a3352dee437b26e3c371806ff3acf25ac37', 1, 1, 'authToken', '[]', 0, '2020-10-02 06:38:31', '2020-10-02 06:38:31', '2021-10-02 07:38:31'),
('f601b4345df745ce849afef283b782323d7a15353e84ac335ab7bfb0a2b8e45a54f2b4aec8f093cf', 3, 1, 'authToken', '[]', 0, '2020-10-16 12:10:56', '2020-10-16 12:10:56', '2021-10-16 13:10:56'),
('f63439e4f4de5616e95b31feca2265611ad9d2ded539e41238dcade504546822aa8713ce63cfe926', 1, 1, 'authToken', '[]', 0, '2020-10-19 08:15:23', '2020-10-19 08:15:23', '2021-10-19 09:15:23'),
('f68936e00e8f354cc1b3853704be23bd95c79264b866d75655d1aa819767400d72914e153eb42b41', 1, 1, 'authToken', '[]', 0, '2020-10-02 06:38:31', '2020-10-02 06:38:31', '2021-10-02 07:38:31'),
('f6a2ea51b1daadc7f2782c04e5ba3bfd4ce7f700edfb717990b4e3656288ec3561b299c13df49a9a', 3, 1, 'authToken', '[]', 0, '2020-10-13 10:02:24', '2020-10-13 10:02:24', '2021-10-13 11:02:24'),
('f6dcb4395d5d280ae9c389403ff615955d0c8c434c6a7a2cdb37d67f002eaf7c62a7152f47dac9db', 2, 1, 'authToken', '[]', 0, '2020-10-27 06:53:19', '2020-10-27 06:53:19', '2021-10-27 07:53:19'),
('f75b1acd0bfd7bbe31b6dddcdd47f5c0b0b6e4b961cfad9bb221831c3c27faf1ce1a756d43d69ac9', 4, 1, 'authToken', '[]', 0, '2020-10-05 16:09:06', '2020-10-05 16:09:06', '2021-10-05 17:09:06'),
('f86766552ce197be7aa28ccbf56f728eaf7a73cd47b6be329b6ae031dfbec898c6161ce2e6bdaed9', 1, 1, 'authToken', '[]', 0, '2020-09-30 07:02:25', '2020-09-30 07:02:25', '2021-09-30 08:02:25'),
('f9e11fb92cfd4dc172fbdef14efcc77fa7dedffebe4a477086fb99c977a4b46d0ece5d1ea860f8f3', 3, 1, 'authToken', '[]', 0, '2020-10-09 10:27:58', '2020-10-09 10:27:58', '2021-10-09 11:27:58'),
('f9e8990f4767567afb17038d070598c555f35b94c227fcf3f6c180934cbead9602716ae4486238de', 2, 1, 'authToken', '[]', 0, '2020-10-02 12:02:48', '2020-10-02 12:02:48', '2021-10-02 13:02:48'),
('f9fb9b733894a5a70ee7e8ca19aaf7cc805e3cb14230296b1e0c34ee70e816a41bbbd7214ac17fca', 28, 1, 'authToken', '[]', 0, '2020-10-07 13:38:12', '2020-10-07 13:38:12', '2021-10-07 14:38:12'),
('fa63be157d8816a4a5618dc220965c4366db37c7c09b57cbfdd64198b34e744fb09d53124e429333', 1, 1, 'authToken', '[]', 0, '2020-11-20 10:06:07', '2020-11-20 10:06:07', '2021-11-20 11:06:07'),
('faabe4b55b6cd6458a3793f82aab8b5bac1aa6617225e5afdf3cc6d6dd12cb9da6251259e3eff180', 1, 1, 'authToken', '[]', 0, '2020-10-19 14:10:20', '2020-10-19 14:10:20', '2021-10-19 15:10:20'),
('fc8147504a38e8f70b1b2bb41a6386e67f979494d9faef6f844a66a62c89cf4223e52a6a83bfff53', 1, 1, 'authToken', '[]', 0, '2020-09-29 13:28:42', '2020-09-29 13:28:42', '2021-09-29 14:28:42'),
('fc91157c35f7258b22962a802d5f1be114209865418ed515f2d98449e102dadfaacf3f175f32eeeb', 3, 1, 'authToken', '[]', 0, '2020-11-17 15:01:19', '2020-11-17 15:01:19', '2021-11-17 16:01:19'),
('fd056c5d21169fcc7f8f90e95c464fcc64f461917d153dd01b13a6b1d7c8c702d9fde25261fcff21', 1, 1, 'authToken', '[]', 0, '2020-11-20 09:13:15', '2020-11-20 09:13:15', '2021-11-20 10:13:15'),
('fd7fa0740458353b191fef02ab487a754ae6fac856fd7a1120009bb1f6d6e4b702e8ebf8e434df2f', 1, 1, 'authToken', '[]', 0, '2020-10-27 15:20:35', '2020-10-27 15:20:35', '2021-10-27 16:20:35'),
('fdd81553c604ae3a61fce4a34bbf77a2b4d610eefeeed7464087bb2161b8509862dc7127369c4a45', 3, 1, 'authToken', '[]', 0, '2020-11-13 09:30:55', '2020-11-13 09:30:55', '2021-11-13 10:30:55'),
('fe3e5485e432ad9e06053d735216b67f1acdbe3e128388e8662da10812ced09b0f44635a19dc1773', 3, 1, 'authToken', '[]', 0, '2020-11-20 09:55:43', '2020-11-20 09:55:43', '2021-11-20 10:55:43'),
('fe431e5c8e7686dc1299eca85f90765cb98d95ba7e2d04135b8aafd53e9d913bd7fece9e88956331', 3, 1, 'authToken', '[]', 0, '2020-10-08 13:05:41', '2020-10-08 13:05:41', '2021-10-08 14:05:41'),
('fec9dd3f5be532d8fdc98533c588636a552e356729249d616139e4832f92cbb5af7c2334cc4c8004', 3, 1, 'authToken', '[]', 0, '2020-11-16 13:26:44', '2020-11-16 13:26:44', '2021-11-16 14:26:44'),
('ff38e602c5513e240ac187e2058d8f1c6b2152745741070812bc604173855fcd38c7da1c73938ed3', 3, 1, 'authToken', '[]', 0, '2020-11-17 14:15:50', '2020-11-17 14:15:50', '2021-11-17 15:15:50');

-- --------------------------------------------------------

--
-- Structure de la table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE IF NOT EXISTS `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'yvesco', 'xX3VMHSm0Zd7DYiIcKTKnT1OxsHzZUFVvta0xjfj', 'http://localhost', 1, 0, 0, '2020-09-25 15:19:06', '2020-09-25 15:19:06');

-- --------------------------------------------------------

--
-- Structure de la table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE IF NOT EXISTS `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2020-09-25 15:19:06', '2020-09-25 15:19:06');

-- --------------------------------------------------------

--
-- Structure de la table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `preuves`
--

DROP TABLE IF EXISTS `preuves`;
CREATE TABLE IF NOT EXISTS `preuves` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `preuve` blob NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `vente_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `preuves_user_id_foreign` (`user_id`),
  KEY `preuves_vente_id_foreign` (`vente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `produit_services`
--

DROP TABLE IF EXISTS `produit_services`;
CREATE TABLE IF NOT EXISTS `produit_services` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prix_de_reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unite` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `equipe_id` int(10) UNSIGNED NOT NULL,
  `entreprise_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `produit_services_equipe_id_foreign` (`equipe_id`),
  KEY `produit_services_entreprise_id_foreign` (`entreprise_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `produit_services`
--

INSERT INTO `produit_services` (`id`, `nom`, `prix_de_reference`, `unite`, `equipe_id`, `entreprise_id`, `created_at`, `updated_at`) VALUES
(1, 'Poulets', '5000 FCFA', 'Poulet(s)', 1, 4, '2020-09-25 15:53:08', '2020-09-25 15:53:08'),
(2, 'Plantain', '2000 FCFA', 'Regime(s)', 1, 4, '2020-09-25 15:56:36', '2020-09-25 15:56:36'),
(3, 'Fruits', '500 FCFA', 'Fruit(s)', 1, 4, '2020-09-25 15:58:03', '2020-09-25 15:58:03'),
(4, 'P2P', '500 FCFA', 'P2P', 3, 8, '2020-10-07 08:53:39', '2020-10-07 08:53:39'),
(6, 'PRP', '500 FCFA', 'PRP', 3, 8, '2020-10-07 08:54:50', '2020-10-07 08:54:50'),
(7, 'PAS', '500 FCFA', 'PAS', 3, 8, '2020-10-07 08:55:37', '2020-10-07 08:55:37'),
(8, 'PR2', '500 FCFA', 'PR2', 3, 8, '2020-10-07 08:55:55', '2020-10-07 08:55:55'),
(9, 'Bdc', '500 FCFA', 'Bdc', 3, 8, '2020-10-07 08:57:59', '2020-10-07 08:57:59'),
(10, 'Granulats', '500 FCFA', 'camion(s) ou brouette(s)', 7, 14, '2020-10-07 09:04:21', '2020-10-07 09:04:21'),
(11, 'Materiel de Construction', '500 FCFA', 'Mat de construction', 7, 14, '2020-10-07 09:08:40', '2020-10-07 09:08:40'),
(12, 'Ciment', '500 FCFA', 'Sac(s)', 7, 14, '2020-10-07 09:10:41', '2020-10-07 09:10:41'),
(13, 'Fer', '500 FCFA', 'fer', 7, 14, '2020-10-07 09:11:28', '2020-10-07 09:11:28'),
(14, 'CHA', '500 FCFA', 'CHA', 12, 19, '2020-10-07 09:14:54', '2020-10-07 09:14:54'),
(15, 'PRO', '500 FCFA', 'PRO', 6, 12, '2020-10-07 09:19:06', '2020-10-07 09:19:06'),
(16, 'MOV', '500 FCFA', 'MOV', 6, 12, '2020-10-07 09:21:16', '2020-10-07 09:21:16'),
(17, 'LOY', '500 FCFA', 'LOY', 6, 12, '2020-10-07 09:21:44', '2020-10-07 09:21:44'),
(18, 'Poulets', '5000 FCFA', 'Poulet(s)', 14, 22, '2020-10-07 09:45:00', '2020-10-07 09:45:00'),
(19, 'Plantain', '2000 FCFA', 'regime(s)', 14, 22, '2020-10-07 09:45:29', '2020-10-07 09:45:29'),
(20, 'Fruits', '500 FCFA', 'Fruit(s)', 14, 22, '2020-10-07 09:46:00', '2020-10-07 09:46:00');

-- --------------------------------------------------------

--
-- Structure de la table `regle_commissions`
--

DROP TABLE IF EXISTS `regle_commissions`;
CREATE TABLE IF NOT EXISTS `regle_commissions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `regle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `produit_service_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `regle_commissions_produit_service_id_foreign` (`produit_service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `service` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom_responsable` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fonction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departement_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `services_email_unique` (`email`),
  UNIQUE KEY `services_contact_unique` (`contact`),
  KEY `services_departement_id_foreign` (`departement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `services`
--

INSERT INTO `services` (`id`, `service`, `nom_responsable`, `fonction`, `email`, `contact`, `departement_id`, `created_at`, `updated_at`) VALUES
(1, 'KmerFood Service', 'Yves Ouambo', 'DG', 'kamerfoodser@peexit.com', '695296411', 1, '2020-09-25 15:01:14', '2020-09-25 15:01:14'),
(2, 'Socec Service', 'Yves Ouambo', 'DG', 'socecser@peexit.com', '695296401', 2, '2020-10-07 06:47:40', '2020-10-07 06:47:40'),
(3, 'Peex Service', 'Yves Ouambo', 'DG', 'peexser@peexit.com', '695696401', 3, '2020-10-07 06:49:30', '2020-10-07 06:49:30'),
(4, 'Connect Service', 'Yves Ouambo', 'DG', 'connectser@peexit.com', '695646401', 4, '2020-10-07 06:50:14', '2020-10-07 06:50:14'),
(5, 'BFF SCI Service', 'Yves Ouambo', 'DG', 'bffser@peexit.com', '695646901', 5, '2020-10-07 06:54:18', '2020-10-07 06:54:18'),
(6, 'Wecare SCI Service', 'Yves Ouambo', 'DG', 'wecaresciser@peexit.com', '695546901', 6, '2020-10-07 06:57:15', '2020-10-07 06:57:15'),
(7, 'Tropical Service', 'Yves Ouambo', 'DG', 'tropicalser@peexit.com', '695546911', 7, '2020-10-07 06:58:34', '2020-10-07 06:58:34'),
(8, 'Wecare Bois Service', 'Yves Ouambo', 'DG', 'wecareboisser@peexit.com', '695546910', 8, '2020-10-07 06:59:21', '2020-10-07 06:59:21'),
(9, 'Home Pro Service', 'Yves Ouambo', 'DG', 'homeproser@peexit.com', '693546910', 9, '2020-10-07 07:00:42', '2020-10-07 07:00:42'),
(10, 'Wecare Alu Service', 'Yves Ouambo', 'DG', 'wecarealuser@peexit.com', '693546900', 10, '2020-10-07 07:01:33', '2020-10-07 07:01:33'),
(11, 'Wecare Construction Service', 'Yves Ouambo', 'DG', 'wecareconstructser@peexit.com', '693546908', 11, '2020-10-07 07:05:08', '2020-10-07 07:05:08'),
(12, 'Agripeel Service', 'Yves Ouambo', 'DG', 'agripeelser@peexit.com', '693246908', 12, '2020-10-07 07:05:43', '2020-10-07 07:05:43'),
(13, 'Afrogaal Service', 'Yves Ouambo', 'DG', 'afrogaalser@peexit.com', '693346908', 13, '2020-10-07 07:06:57', '2020-10-07 07:06:57'),
(14, 'WecareFood Service', 'Yves Ouambo', 'DG', 'wecarefoodser@peexit.com', '693346901', 14, '2020-10-07 07:08:10', '2020-10-07 07:08:10'),
(15, 'Wecare Logistic Service', 'Yves Ouambo', 'DG', 'wecarelogisticser@peexit.com', '693746901', 16, '2020-10-07 07:11:34', '2020-10-07 07:11:34'),
(16, 'Peex Trade Service', 'Yves Ouambo', 'DG', 'peextradeser@peexit.com', '693746951', 15, '2020-10-07 07:12:15', '2020-10-07 07:12:15'),
(17, 'Wecare Tech Service', 'Yves Ouambo', 'DG', 'wecaretechser@peexit.com', '693746051', 17, '2020-10-07 07:15:17', '2020-10-07 07:15:17');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `entreprise_id` int(10) UNSIGNED NOT NULL,
  `equipe_id` int(10) UNSIGNED DEFAULT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `poste` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(10) UNSIGNED NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` blob NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_entreprise_id_foreign` (`entreprise_id`),
  KEY `users_equipe_id_foreign` (`equipe_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `entreprise_id`, `equipe_id`, `nom`, `username`, `poste`, `contact`, `email`, `type`, `password`, `remember_token`, `photo`, `created_at`, `updated_at`) VALUES
(1, 4, NULL, 'Yves Ouambo', 'yvesco', 'DG', '695296411', 'youambo@peexit.com', 2, '$2y$10$ojEcZauXl2OUN9PEVibG1OFKA8e3gOhCBStzqRtbqq4cN0bzFqVve', NULL, 0x433a5c77616d7036345c746d705c706870464146442e746d70, '2020-09-25 15:17:28', '2020-11-20 08:00:07'),
(2, 4, 1, 'Bienvenu Makang', 'bonito', 'Responsable de ventes', '644456234', 'bmakang@peexit.com', 7, '$2y$10$kXYv7Y1g8m.BHNnc4ibhDeP8zU4/ViaH29skwB7i2gX9VYGBh.aqq', NULL, 0x433a5c77616d7036345c746d705c706870393436342e746d70, '2020-09-25 15:24:40', '2020-09-25 15:24:40'),
(3, 4, 1, 'Yannick Wafo', 'yan', 'commercial', '697665136', 'sabinejosy@yahoo.fr', 8, '$2y$10$vvsr6Udlcoe0xkqeoHAnc.neme8JmGo7kYS9BZhd42Y3SJXl7hWD2', NULL, 0x70686f746f202e706e67, NULL, '2020-11-20 13:30:53'),
(4, 4, NULL, 'Josiane', 'josy', 'administrateur', '655851222', 'ntsamajosy@gmail.com', 1, '$2y$10$3g/v7xYXX/ahjVI5RS5Kee0uDaBu1nB8nNRswQuHc03t4njqHv3o.', NULL, 0x433a5c77616d7036345c746d705c706870464235312e746d70, '2020-10-05 16:09:06', '2020-10-05 16:09:06'),
(6, 7, NULL, 'Yves Ouambo', 'yvescosocec', 'DG', '695296411', 'socecinfo@peexit.com', 2, '$2y$10$POU.Z5Cg0stG3yQdRfZqhu8HaTbcmJ8JAPPfctqKf6TAY76KLzx9W', NULL, 0x433a5c77616d7036345c746d705c706870463041352e746d70, '2020-10-07 12:48:05', '2020-10-07 12:48:05'),
(7, 8, NULL, 'Yves Ouambo', 'yvescopeex', 'DG', '695296411', 'peexinfo@peexit.com', 2, '$2y$10$eFr5mmgC7C0hp.hkj6JZ9OvxoZxr6CTwWdP.NAvk6HkYajqhrlsrC', NULL, 0x433a5c77616d7036345c746d705c706870353846322e746d70, '2020-10-07 12:52:53', '2020-10-07 12:52:53'),
(8, 10, NULL, 'Yves Ouambo', 'yvescocon', 'DG', '695296411', 'connectinfo@peexit.com', 2, '$2y$10$b49SMkGEMNEBKWfG02upBuimiJN3icsqb27Iyoy/CsBWPXr5jI97m', NULL, 0x433a5c77616d7036345c746d705c706870413345342e746d70, '2020-10-07 12:54:18', '2020-10-07 12:54:18'),
(9, 11, NULL, 'Yves Ouambo', 'yvescobff', 'DG', '695296411', 'bffinfo@peexit.com', 2, '$2y$10$5X31YvtJM31e6Xrd6/t6ueUDlVCNO6RVGDphnBn.SZTv4XWjAJKqm', NULL, 0x433a5c77616d7036345c746d705c706870453343332e746d70, '2020-10-07 12:56:45', '2020-10-07 12:56:45'),
(10, 12, NULL, 'Yves Ouambo', 'yvescowsci', 'DG', '695296411', 'wcresciinfo@peexit.com', 2, '$2y$10$06jRx3RkVnROpm6SlJqKZO3mla1VP4rZ2qDNwTj1YO3lbjLGpi7Oq', NULL, 0x433a5c77616d7036345c746d705c706870463633302e746d70, '2020-10-07 12:57:56', '2020-10-07 12:57:56'),
(11, 14, NULL, 'Yves Ouambo', 'yvescotro', 'DG', '695296411', 'tropiinfo@peexit.com', 2, '$2y$10$eb.mVR.eO2Wjf9xYXMLl9eXmYW7hwJwNWlEKuW8zV/WWCWNwH06x.', NULL, 0x433a5c77616d7036345c746d705c706870313444312e746d70, '2020-10-07 13:02:26', '2020-10-07 13:02:26'),
(12, 15, NULL, 'Yves Ouambo', 'yvescowb', 'DG', '695296411', 'wecareboisinfo@peexit.com', 2, '$2y$10$Wi.Zlwt3588Bu/yOzmltWeMdH2WfgCuRuxNpGnhaOHPhCiJpLSDjG', NULL, 0x433a5c77616d7036345c746d705c706870454543392e746d70, '2020-10-07 13:03:22', '2020-10-07 13:03:22'),
(13, 16, NULL, 'Yves Ouambo', 'yvescohpro', 'DG', '695296411', 'homeproinfo@peexit.com', 2, '$2y$10$YBpq77gW7pH3LjTnKXzHxeIdyGieOhGzf57JJv.wDyg3vJ8UAXSXa', NULL, 0x433a5c77616d7036345c746d705c706870334632372e746d70, '2020-10-07 13:04:48', '2020-10-07 13:04:48'),
(14, 17, NULL, 'Yves Ouambo', 'yvescowalu', 'DG', '695296411', 'wecarealuinfo@peexit.com', 2, '$2y$10$rE4o8uDdbbOIBa3egbUxiOXN2mAP/6gjxifGE0vOWMuKbOnCTuKBi', NULL, 0x433a5c77616d7036345c746d705c706870323930362e746d70, '2020-10-07 13:06:53', '2020-10-07 13:06:53'),
(15, 18, NULL, 'Yves Ouambo', 'yvescowcon', 'DG', '695296411', 'wecareconinfo@peexit.com', 2, '$2y$10$xFMQUq/yu8Od3jDQfUEzf.JJ/UTjhBc8vbbcgAFuIyzoy0j14usjO', NULL, 0x433a5c77616d7036345c746d705c706870353334302e746d70, '2020-10-07 13:08:09', '2020-10-07 13:08:09'),
(16, 19, NULL, 'Yves Ouambo', 'yvescoagri', 'DG', '695296411', 'agripeelinfo@peexit.com', 2, '$2y$10$jM25eyJ0CoMpCQMeC1Im0uLqJsA1BKDe1G2uYgR2SyKQEBOVTUIkS', NULL, 0x433a5c77616d7036345c746d705c706870453942432e746d70, '2020-10-07 13:10:59', '2020-10-07 13:10:59'),
(17, 21, NULL, 'Yves Ouambo', 'yvescoafro', 'DG', '695296411', 'afrogaalinfo@peexit.com', 2, '$2y$10$j57Y/YY6DoWgHfHmvH0VFOCctGmWgTqHsGG3xa1Oe9vhHVpUC5dX6', NULL, 0x433a5c77616d7036345c746d705c706870343539342e746d70, '2020-10-07 13:12:28', '2020-10-07 13:12:28'),
(18, 22, NULL, 'Yves Ouambo', 'yvescowfo', 'DG', '695296411', 'wecarefoodinfo@peexit.com', 2, '$2y$10$q6m63fLspI8b3VxTIqL9C.t78qHmNxGuHg0NBSMBH6A9joQuo7G2m', NULL, 0x433a5c77616d7036345c746d705c706870373731302e746d70, '2020-10-07 13:13:46', '2020-10-07 13:13:46'),
(19, 24, NULL, 'Yves Ouambo', 'yvescowlo', 'DG', '695296411', 'wecareloinfo@peexit.com', 2, '$2y$10$7pu1NhAEF6b2W1928rKPsuQlHA2G.vIhaIlHrdxxqYFRBfshfV91q', NULL, 0x433a5c77616d7036345c746d705c706870373138392e746d70, '2020-10-07 13:15:56', '2020-10-07 13:15:56'),
(20, 26, NULL, 'Yves Ouambo', 'yvescowtec', 'DG', '695296411', 'wecaretechinfo@peexit.com', 2, '$2y$10$/nZ8zqnrp62jicjzEgPmxO0wb8/y23Jh4ZGy2d1fo3LeBBS2nCHqa', NULL, 0x433a5c77616d7036345c746d705c7068704530412e746d70, '2020-10-07 13:16:36', '2020-10-07 13:16:36'),
(21, 7, 2, 'Bienvenu Makang', 'bonitoso', 'Responsable de ventes', '644456234', 'repoventesocec@peexit.com', 7, '$2y$10$EAfugA6Xc.3RnNiG0rDNKOb8WhYa92in0Z9tDOk5K475EUjy/reKG', NULL, 0x433a5c77616d7036345c746d705c706870424544372e746d70, '2020-10-07 13:29:22', '2020-10-07 13:29:22'),
(22, 8, 3, 'Bienvenu Makang', 'bonitope', 'Responsable de ventes', '644456234', 'repoventepeex@peexit.com', 7, '$2y$10$b6cC90874HBXmXUOOONMmelm26uvnHCjKQnPa6DfKDyttbfCnJ3j2', NULL, 0x433a5c77616d7036345c746d705c706870353031372e746d70, '2020-10-07 13:31:05', '2020-10-07 13:31:05'),
(23, 10, 4, 'Bienvenu Makang', 'bonitoco', 'Responsable de ventes', '644456234', 'repoventeconnect@peexit.com', 7, '$2y$10$GIZSdEuIogCEpBq0uS71KupPjXqwkwlTJ9wSINotPfGjWeHTMwL7G', NULL, 0x433a5c77616d7036345c746d705c706870464645302e746d70, '2020-10-07 13:31:50', '2020-10-07 13:31:50'),
(24, 11, 5, 'Bienvenu Makang', 'bonitobf', 'Responsable de ventes', '644456234', 'repoventebff@peexit.com', 7, '$2y$10$BPPQ6SChaBjjZv.CFKbjRubdNCVQZCjnX.dQCKH92IhhgNFQwXmV2', NULL, 0x433a5c77616d7036345c746d705c706870344246382e746d70, '2020-10-07 13:33:15', '2020-10-07 13:33:15'),
(25, 12, 6, 'Bienvenu Makang', 'bonitows', 'Responsable de ventes', '644456234', 'repoventewecaresci@peexit.com', 7, '$2y$10$Caz3yzLgpxcntWRH9FPozujf3xXv.gcepYuWD7kjiGvJUYGR.MaCG', NULL, 0x433a5c77616d7036345c746d705c7068703638462e746d70, '2020-10-07 13:34:03', '2020-10-07 13:34:03'),
(26, 14, 7, 'Bienvenu Makang', 'bonitotr', 'Responsable de ventes', '644456234', 'repoventetropical@peexit.com', 7, '$2y$10$08SgO43yUbmutHjHrau1iuzSy5R.ADtsH6zzE68JsMK6zF.0oozSe', NULL, 0x433a5c77616d7036345c746d705c706870324343302e746d70, '2020-10-07 13:35:18', '2020-10-07 13:35:18'),
(27, 15, 8, 'Bienvenu Makang', 'bonitowb', 'Responsable de ventes', '644456234', 'repoventewecarebois@peexit.com', 7, '$2y$10$C0waE4YQ9ItHBhpntmsO1OGzqMj3aZGcric91bNtI7Bb0FCpvRvGa', NULL, 0x433a5c77616d7036345c746d705c706870413834362e746d70, '2020-10-07 13:36:55', '2020-10-07 13:36:55'),
(28, 16, 9, 'Bienvenu Makang', 'bonitohp', 'Responsable de ventes', '644456234', 'repoventehomepro@peexit.com', 7, '$2y$10$RF0nLAYq2qIWqetkcTb2.uO6uOml2yrurRgbz2X520rFoKS/LPvqK', NULL, 0x433a5c77616d7036345c746d705c706870443635372e746d70, '2020-10-07 13:38:12', '2020-10-07 13:38:12'),
(29, 17, 10, 'Bienvenu Makang', 'bonitowa', 'Responsable de ventes', '644456234', 'repoventewcarealu@peexit.com', 7, '$2y$10$1pnV8LeSYqkhu.WtjOPNVuiNDl1GpK5uQo8VdsBr8xbDbSOvPEm3.', NULL, 0x433a5c77616d7036345c746d705c706870393738352e746d70, '2020-10-07 13:39:02', '2020-10-07 13:39:02'),
(30, 18, 11, 'Bienvenu Makang', 'bonitowc', 'Responsable de ventes', '644456234', 'repoventewcarecon@peexit.com', 7, '$2y$10$kuVxMN8IaQDePtn.AbRP7e4adJiDjYf65LJZcNAgrTU35F7qdhHXi', NULL, 0x433a5c77616d7036345c746d705c706870443330342e746d70, '2020-10-07 13:40:23', '2020-10-07 13:40:23'),
(31, 19, 12, 'Bienvenu Makang', 'bonitoag', 'Responsable de ventes', '644456234', 'repoventeagripeel@peexit.com', 7, '$2y$10$tV2A3DdkmSUCB8WgehXK1u6iXwsQ4.67MDMaoQmScbRhMVP5xR3CK', NULL, 0x433a5c77616d7036345c746d705c706870393231452e746d70, '2020-10-07 13:41:12', '2020-10-07 13:41:12'),
(32, 21, 13, 'Bienvenu Makang', 'bonitoaf', 'Responsable de ventes', '644456234', 'repoventeafrogaal@peexit.com', 7, '$2y$10$pUIkO6KvYQi966Gn1cScB.94ZoTC57caGZeozuXwU64LqUpKp.GQK', NULL, 0x433a5c77616d7036345c746d705c706870434442432e746d70, '2020-10-07 13:42:32', '2020-10-07 13:42:32'),
(33, 22, 14, 'Bienvenu Makang', 'bonitowf', 'Responsable de ventes', '644456234', 'repoventewecarefood@peexit.com', 7, '$2y$10$uO0w5kxFE84r8iRycYOyceSavxAM7UEIZjF8QZt1j.9jJ3ranNC6e', NULL, 0x433a5c77616d7036345c746d705c706870394235452e746d70, '2020-10-07 13:43:25', '2020-10-07 13:43:25'),
(34, 24, 15, 'Bienvenu Makang', 'bonitowl', 'Responsable de ventes', '644456234', 'repoventewecarelogistic@peexit.com', 7, '$2y$10$PSfs/OdwnklRuvS4.gSORubZ.yBe1qjRmwzlA8Q0nklvIGBVoOmoC', NULL, 0x433a5c77616d7036345c746d705c706870433341332e746d70, '2020-10-07 13:44:41', '2020-10-07 13:44:41'),
(35, 25, 16, 'Bienvenu Makang', 'bonitopt', 'Responsable de ventes', '644456234', 'repoventepeextrade@peexit.com', 7, '$2y$10$hOv30Mq9/NagUX5WLHA79evqxkksaaKn22HEeJGOfGOHqi.iGqZwm', NULL, 0x433a5c77616d7036345c746d705c706870363331302e746d70, '2020-10-07 13:45:22', '2020-10-07 13:45:22'),
(36, 26, 17, 'Bienvenu Makang', 'bonitowt', 'Responsable de ventes', '644456234', 'repoventewecaretech@peexit.com', 7, '$2y$10$WCJy15Ha9AnlMrhFEBWTbO9XCdFQKEXKTitT5PHhU5eYKofk/13AG', NULL, 0x433a5c77616d7036345c746d705c706870364346322e746d70, '2020-10-07 14:03:58', '2020-10-07 14:03:58'),
(37, 7, 2, 'Yannick Wafo', 'yansocec', 'commercial', '697665136', 'commercialsocec@peexit.com', 8, '$2y$10$iHGvhNeJYhNRVhaYVYJDUOfPQxRZjzsGx94fzN97PMUi0LB1DjI2G', NULL, 0x433a5c77616d7036345c746d705c7068703541422e746d70, '2020-10-07 14:11:11', '2020-10-07 14:11:11'),
(38, 8, 3, 'Yannick Wafo', 'yanpeex', 'commercial', '697665136', 'commercialpeex@peexit.com', 8, '$2y$10$iy1f70gdqGWcFIZ8o3JSgOx7M11iI1aOndl99ilnX5EgVNzrFF1PW', NULL, 0x433a5c77616d7036345c746d705c706870363833412e746d70, '2020-10-07 14:12:41', '2020-10-07 14:12:41'),
(39, 10, 4, 'Yannick Wafo', 'yancon', 'commercial', '697665136', 'commercialconnect@peexit.com', 8, '$2y$10$u92afHRorZG.gKAWX9PIoOVsofHaX3HXquokOnN3NjZy2PNb4WqTq', NULL, 0x433a5c77616d7036345c746d705c706870454637372e746d70, '2020-10-07 14:14:22', '2020-10-07 14:14:22'),
(40, 11, 5, 'Yannick Wafo', 'yanbff', 'commercial', '697665136', 'commercialbff@peexit.com', 8, '$2y$10$ITIOlIYkcHMTPgfMb53h4.DLLIjyxleiYZKdkKZ1TIrxVToCBoN82', NULL, 0x433a5c77616d7036345c746d705c7068703931362e746d70, '2020-10-07 14:15:34', '2020-10-07 14:15:34'),
(41, 12, 6, 'Yannick Wafo', 'yanwsci', 'commercial', '697665136', 'commercialwecaresci@peexit.com', 8, '$2y$10$R85UwKNGC1cNG55dGCxC7uzsh9Xurmwb.XRRnSnXA.wXxUOieIqxe', NULL, 0x433a5c77616d7036345c746d705c706870383531442e746d70, '2020-10-07 14:16:05', '2020-10-07 14:16:05'),
(42, 14, 7, 'Yannick Wafo', 'yantro', 'commercial', '697665136', 'commercialtropical@peexit.com', 8, '$2y$10$W2Y86Do9baeWUycJKTonq.ikQvRoh1cloN/nzon4GFTXON0J/Dd8y', NULL, 0x433a5c77616d7036345c746d705c706870424242422e746d70, '2020-10-07 14:17:25', '2020-10-07 14:17:25'),
(43, 15, 8, 'Yannick Wafo', 'yanwbois', 'commercial', '697665136', 'commercialwecarebois@peexit.com', 8, '$2y$10$lJawPsabfJfjf0HdZ68ZYu.HbgvHUbuMrmp2gHSn64au.ZgKU19V.', NULL, 0x433a5c77616d7036345c746d705c706870353546382e746d70, '2020-10-07 14:18:04', '2020-10-07 14:18:04'),
(44, 16, 9, 'Yannick Wafo', 'yanhpro', 'commercial', '697665136', 'commercialhomepro@peexit.com', 8, '$2y$10$hK3QrPCkXVOVPksXifzq.uoJa1HpYtpmvEDmyVIkPsw4MosUi2kQ2', NULL, 0x433a5c77616d7036345c746d705c706870373532352e746d70, '2020-10-07 14:19:18', '2020-10-07 14:19:18'),
(45, 17, 10, 'Yannick Wafo', 'yanwalu', 'commercial', '697665136', 'commercialwecarealu@peexit.com', 8, '$2y$10$eJAm5R7A9xaP435wd8zWYueM8HRGKoGfmzx9WU7PF/xXtEkwsM7aO', NULL, 0x433a5c77616d7036345c746d705c706870354145322e746d70, '2020-10-07 14:20:17', '2020-10-07 14:20:17'),
(46, 18, 11, 'Yannick Wafo', 'yanwcon', 'commercial', '697665136', 'commercialwecareconstrut@peexit.com', 8, '$2y$10$r8RrPP/0Pd0/l1TpfO5zE.S32tyL25LPBsgtAnp2ovcP9qySCVjxe', NULL, 0x433a5c77616d7036345c746d705c7068703932302e746d70, '2020-10-07 14:22:07', '2020-10-07 14:22:07'),
(47, 19, 12, 'Yannick Wafo', 'yanagri', 'commercial', '697665136', 'commercialagripeel@peexit.com', 8, '$2y$10$/KD2uhr1hAvr/lpl7MAy/eTbc8Rup2cxGXHB83VdST.nFc9PXk5zS', NULL, 0x433a5c77616d7036345c746d705c706870423930382e746d70, '2020-10-07 14:22:52', '2020-10-07 14:22:52'),
(48, 21, 13, 'Yannick Wafo', 'yanafro', 'commercial', '697665136', 'commercialafrogaal@peexit.com', 8, '$2y$10$XDcXql5USgsZzXU4NCqnlOOeOZnoQkFnGgnX7Tw6cJu5VP9h9uoMq', NULL, 0x433a5c77616d7036345c746d705c706870414235412e746d70, '2020-10-07 14:27:11', '2020-10-07 14:27:11'),
(49, 22, 14, 'Yannick Wafo', 'yanwfo', 'commercial', '697665136', 'commercialwecarefood@peexit.com', 8, '$2y$10$pMbAdjVXz0lTpu.UaMGDT.Lh.2ZB8IjmfWkEwpzztIegS14s1Jl0e', NULL, 0x433a5c77616d7036345c746d705c706870384644462e746d70, '2020-10-07 14:28:09', '2020-10-07 14:28:09'),
(50, 24, 15, 'Yannick Wafo', 'yanwlo', 'commercial', '697665136', 'commercialwecarelogistic@peexit.com', 8, '$2y$10$gQFoZPDkI/fBcEC3Dz2k2uN9TTygNpBCe1N5hiE7b1EiSVMnzX5fS', NULL, 0x433a5c77616d7036345c746d705c706870443042432e746d70, '2020-10-07 14:29:31', '2020-10-07 14:29:31'),
(51, 25, 16, 'Yannick Wafo', 'yanpt', 'commercial', '697665136', 'commercialpeextrade@peexit.com', 8, '$2y$10$c8oCChFe7b4uDZVoquV3W.CQ7APUFl6wI5ls4/nwGFQeRI6jcgf1q', NULL, 0x433a5c77616d7036345c746d705c706870344437462e746d70, '2020-10-07 14:30:03', '2020-10-07 14:30:03'),
(52, 26, 17, 'Yannick Wafo', 'yanwtech', 'commercial', '697665136', 'commercialwecaretech@peexit.com', 8, '$2y$10$BH/bawJFzrJxxWd3C2DJvOMe7nQ7KBEZFP9Zmj7ubgO8x4Dutgf3K', NULL, 0x433a5c77616d7036345c746d705c706870324232392e746d70, '2020-10-07 14:32:05', '2020-10-07 14:32:05');

-- --------------------------------------------------------

--
-- Structure de la table `ventes`
--

DROP TABLE IF EXISTS `ventes`;
CREATE TABLE IF NOT EXISTS `ventes` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantite` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preuve` blob NOT NULL,
  `etat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prix_de_vente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `commentaire_commercial` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `raison_responsable` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `produit_service_id` int(10) UNSIGNED NOT NULL,
  `date_vente` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ventes_user_id_foreign` (`user_id`),
  KEY `ventes_produit_service_id_foreign` (`produit_service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `ventes`
--

INSERT INTO `ventes` (`id`, `reference`, `quantite`, `preuve`, `etat`, `prix_de_vente`, `commentaire_commercial`, `raison_responsable`, `user_id`, `produit_service_id`, `date_vente`, `created_at`, `updated_at`) VALUES
(1, '1PouKme200921', '5', 0x433a5c77616d7036345c746d705c706870383533372e746d70, 'en attente', '11000', 'RAS', 'RAS', 3, 1, '2020-09-21', '2020-09-26 12:30:08', '2020-09-26 12:30:08'),
(2, '27PouKme201016', '10', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f36326131383935632d346166372d343162372d623230652d3131646264616461313534392e706e67, 'rejete', '1500020', 'je teste voir', 'tous les groupes', 3, 1, '2020-10-16', '2020-09-26 14:10:05', '2020-10-27 15:54:45'),
(3, '3PouKme201001', '15', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f61306438653839342d653837622d346565312d393134342d3733613931666439363930332e706e67, 'en attente', '8000', 'test tracking des revenus', 'RAS', 3, 1, '2020-10-01', '2020-10-02 11:43:00', '2020-10-02 11:43:00'),
(4, '4PouKme201002', '4', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f65353738623264312d626633662d343365342d393261362d6431353339613035623739362e706e67, 'en attente', '6150', 'vendu a Wielfried qui a apprecie la qualite', 'RAS', 3, 1, '2020-10-02', '2020-10-02 11:53:12', '2020-10-02 11:53:12'),
(5, '5PouKme201001', '5', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f65373639386330612d303738612d346465372d613865392d6131313230633830313666622e706e67, 'en attente', '8000', 'vendu a Yves', 'RAS', 3, 1, '2020-10-01', '2020-10-02 11:58:08', '2020-10-02 11:58:08'),
(6, '6PouKme201005', '4', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f66393635326565332d393764382d346435382d393535312d6263363232626333316562392e706e67, 'en attente', '18000', 'test RAS', 'RAS', 3, 1, '2020-10-05', '2020-10-05 15:58:51', '2020-10-05 15:58:51'),
(7, '7PouKme200921', '6', 0x433a5c77616d7036345c746d705c706870453642312e746d70, 'en attente', '3000', 'RAS', 'RAS', 3, 2, '2020-09-21', '2020-10-08 09:57:39', '2020-10-08 09:57:39'),
(8, '8PouKme201008', '6', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f33653132376430612d366537642d346331342d386538392d3531373732386536366639392e706e67, 'en attente', '8000', 'test sur renseigner', 'RAS', 3, 1, '2020-10-08', '2020-10-08 10:03:46', '2020-10-08 10:03:46'),
(9, '9PouKme201008', '6', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f33653132376430612d366537642d346331342d386538392d3531373732386536366639392e706e67, 'a modifier', '8000', 'test sur renseigner', 'RAS', 3, 1, '2020-10-08', '2020-10-08 10:03:57', '2020-10-08 10:03:57'),
(10, '10PouKme201008', '88', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f33336538346134652d386465302d346338612d383263372d6331366138376663326461312e706e67, 'en attente', '150008', '09/10/2020', 'RAS', 3, 1, '2020-10-08', '2020-10-09 06:59:53', '2020-10-09 06:59:53'),
(11, '11PouKme201008', '88', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f33336538346134652d386465302d346338612d383263372d6331366138376663326461312e706e67, 'en attente', '150008', '09/10/2020', 'RAS', 3, 1, '2020-10-08', '2020-10-09 07:00:00', '2020-10-09 07:00:00'),
(12, '12PouKme201008', '88', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f33336538346134652d386465302d346338612d383263372d6331366138376663326461312e706e67, 'en attente', '150008', '09/10/2020', 'RAS', 3, 1, '2020-10-08', '2020-10-09 07:00:06', '2020-10-09 07:00:06'),
(13, '13PouKme201012', '213', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f31323765626630642d643933362d346261652d616230632d6437376664363663636262332e706e67, 'en attente', '123456671', 'qersttyuojppp[', 'RAS', 3, 1, '2020-10-12', '2020-10-12 17:14:45', '2020-10-12 17:14:45'),
(14, '14PouKme201012', '213', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f31323765626630642d643933362d346261652d616230632d6437376664363663636262332e706e67, 'en attente', '123456671', 'qersttyuojppp[', 'RAS', 3, 1, '2020-10-12', '2020-10-12 17:14:52', '2020-10-12 17:14:52'),
(15, '15PouKme201013', '45', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f33366438643164382d373461622d346130652d396635312d6162316366393234363231382e706e67, 'en attente', '14000', 'sfdhjdfhuoirejjjjjjjjjjjjjjjjjjjjjjjjjjjklnikmikklmopijjiopj', 'RAS', 3, 1, '2020-10-13', '2020-10-13 07:18:46', '2020-10-13 07:18:46'),
(16, '16PouKme201013', '45', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f33366438643164382d373461622d346130652d396635312d6162316366393234363231382e706e67, 'en attente', '14000', 'sfdhjdfhuoirejjjjjjjjjjjjjjjjjjjjjjjjjjjklnikmikklmopijjiopj', 'RAS', 3, 1, '2020-10-13', '2020-10-13 07:18:57', '2020-10-13 07:18:57'),
(17, '17FruKme201013', '1', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f61656138303561622d366637352d346563382d393061322d6637656538336439396130392e706e67, 'en attente', '1234556', 'ettrrytyyuuiioiopopoop[p[pmm,l.//', 'RAS', 3, 3, '2020-10-13', '2020-10-13 10:25:27', '2020-10-13 10:25:27'),
(18, '18FruKme201013', '1', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f61656138303561622d366637352d346563382d393061322d6637656538336439396130392e706e67, 'en attente', '1234556', 'ettrrytyyuuiioiopopoop[p[pmm,l.//', 'RAS', 3, 3, '2020-10-13', '2020-10-13 10:25:34', '2020-10-13 10:25:34'),
(19, '19PouKme201013', '8', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430616e6f6e796d6f757325323532466172676f6e2d667265652d72656163742d6e61746976652d35656162373230362d323137632d343733392d386638382d6139343932323839313735322f496d6167655069636b65722f39323038356466612d343364322d343030332d383437642d3761333837663661343564342e706e67, 'en attente', '12345467', 'test test', 'RAS', 3, 1, '2020-10-13', '2020-10-14 09:52:04', '2020-10-14 09:52:04'),
(20, '20PouKme201014', '1', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f34383332663866622d303933632d343563352d623334362d3639373832393061363331662e706e67, 'en attente', '5500', 'RAS', 'RAS', 3, 1, '2020-10-14', '2020-10-15 12:22:21', '2020-10-15 12:22:21'),
(21, '21PouKme201014', '1', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f34383332663866622d303933632d343563352d623334362d3639373832393061363331662e706e67, 'en attente', '5500', 'RAS', 'RAS', 3, 1, '2020-10-14', '2020-10-15 12:22:39', '2020-10-15 12:22:39'),
(22, '22PlaKme201014', '5', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f35623632333466612d383431662d343535652d393532342d3632323162313537633836332e706e67, 'en attente', '4000', 'BONJOUR', 'RAS', 3, 2, '2020-10-14', '2020-10-15 12:30:17', '2020-10-15 12:30:17'),
(23, '23PlaKme201014', '5', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f35623632333466612d383431662d343535652d393532342d3632323162313537633836332e706e67, 'en attente', '4000', 'BONJOUR', 'RAS', 3, 2, '2020-10-14', '2020-10-15 12:30:26', '2020-10-15 12:30:26'),
(24, '24PlaKme201014', '5', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f35623632333466612d383431662d343535652d393532342d3632323162313537633836332e706e67, 'en attente', '4000', 'BONJOUR', 'RAS', 3, 2, '2020-10-14', '2020-10-15 12:30:39', '2020-10-15 12:30:39'),
(25, '25PlaKme201014', '5', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f35623632333466612d383431662d343535652d393532342d3632323162313537633836332e706e67, 'en attente', '4000', 'BONJOUR', 'RAS', 3, 2, '2020-10-14', '2020-10-15 12:33:23', '2020-10-15 12:33:23'),
(26, '26PlaKme201014', '5', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f35623632333466612d383431662d343535652d393532342d3632323162313537633836332e706e67, 'en attente', '4000', 'BONJOUR', 'RAS', 3, 2, '2020-10-14', '2020-10-15 12:33:26', '2020-10-15 12:33:26'),
(27, '27PouKme201016', '10', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f36326131383935632d346166372d343162372d623230652d3131646264616461313534392e706e67, 'en attente', '1500020', 'je teste voir', 'RAS', 3, 1, '2020-10-16', '2020-10-16 08:43:53', '2020-10-16 08:43:53'),
(28, '28PouKme201016', '10', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f36326131383935632d346166372d343162372d623230652d3131646264616461313534392e706e67, 'en attente', '1500020', 'je teste voir', 'RAS', 3, 1, '2020-10-16', '2020-10-16 08:44:03', '2020-10-16 08:44:03'),
(29, '29PR2PEE201016', '9', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f35623938643033622d396538332d343266612d396538302d6435393136663434366533662e706e67, 'en attente', '123456789', 'quoi quoi', 'RAS', 3, 8, '2020-10-16', '2020-10-16 08:54:42', '2020-10-16 08:54:42'),
(30, '30FruKme201016', '8', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f31656139326434372d396132382d343337372d626663302d3365636163623064373063362e706e67, 'en attente', '9000', 'fdfgff', 'RAS', 3, 3, '2020-10-16', '2020-10-16 13:54:01', '2020-10-16 13:54:01'),
(31, '31CHAAgr201023', '1', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f34303134313337652d373432372d343935352d393964642d3735303533326664316364622e706e67, 'en attente', '100000', 'Test CHA', 'RAS', 3, 14, '2020-10-23', '2020-10-23 14:42:45', '2020-10-23 14:42:45'),
(32, '32CHAAgr201023', '1', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f34303134313337652d373432372d343935352d393964642d3735303533326664316364622e706e67, 'en attente', '100000', 'Test CHA', 'RAS', 3, 14, '2020-10-23', '2020-10-23 14:42:52', '2020-10-23 14:42:52'),
(33, '33PASPEE201028', '4', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f32393931323461332d616665622d343862642d383635362d3566623463326630623532662e706e67, 'en attente', '7000', 'RAS RAS', 'RAS', 3, 7, '2020-10-28', '2020-10-28 09:47:33', '2020-10-28 09:47:33'),
(34, '34PASPEE201028', '4', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f32393931323461332d616665622d343862642d383635362d3566623463326630623532662e706e67, 'en attente', '7000', 'RAS RAS', 'RAS', 3, 7, '2020-10-28', '2020-10-28 09:47:55', '2020-10-28 09:47:55'),
(35, '35PASPEE201028', '10', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f37343366366432622d346235652d343031372d386130342d6333626532656639633539322e706e67, 'en attente', '1400', 'Nanananana', 'RAS', 3, 7, '2020-10-28', '2020-10-28 10:08:58', '2020-10-28 10:08:58'),
(36, '36PASPEE201028', '10', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f37343366366432622d346235652d343031372d386130342d6333626532656639633539322e706e67, 'en attente', '1400', 'encore encore encore', 'RAS', 3, 7, '2020-10-28', '2020-10-28 10:36:53', '2020-10-28 10:36:53'),
(37, '37PASPEE201028', '10', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f737925323532466172676f6e2d667265652d72656163742d6e61746976652f496d6167655069636b65722f37343366366432622d346235652d343031372d386130342d6333626532656639633539322e706e67, 'en attente', '1400', 'teste test', 'RAS', 3, 7, '2020-10-28', '2020-10-28 14:15:37', '2020-10-28 14:15:37'),
(41, '38PouKme201127', '10', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f34386230306263632d323333622d346531322d393065382d6136663934383434653630612e706e67, 'en attente', '6000', 'test', 'RAS', 3, 1, '2020-11-27', '2020-11-27 09:36:55', '2020-11-27 09:36:55'),
(42, '39PouKme201127', '10', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f34386230306263632d323333622d346531322d393065382d6136663934383434653630612e706e67, 'en attente', '6000', 'test', 'RAS', 3, 1, '2020-11-27', '2020-11-27 09:37:03', '2020-11-27 09:37:03'),
(43, '40PlaKme201127', '20', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f34613337343938302d303862312d343361312d626637652d6138633565396339626462652e706e67, 'en attente', '3000', 'test', 'RAS', 3, 2, '2020-11-27', '2020-11-27 09:40:36', '2020-11-27 09:40:36'),
(44, '41PlaKme201127', '20', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f34613337343938302d303862312d343361312d626637652d6138633565396339626462652e706e67, 'en attente', '3000', 'test', 'RAS', 3, 2, '2020-11-27', '2020-11-27 09:40:45', '2020-11-27 09:40:45'),
(45, '42PouKme200101', '10', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f35663238336430352d643736652d346339392d626466662d3839643066366163386432652e706e67, 'en attente', '8000', 'test', 'RAS', 3, 1, '2020-01-01', '2020-11-27 09:43:24', '2020-11-27 09:43:24'),
(46, '43PouKme200101', '10', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f35663238336430352d643736652d346339392d626466662d3839643066366163386432652e706e67, 'en attente', '8000', 'test', 'RAS', 3, 1, '2020-01-01', '2020-11-27 09:43:32', '2020-11-27 09:43:32'),
(47, '44PouKme200101', '8', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f33376635336634362d353465352d346230362d393732322d3164336238313066303036632e706e67, 'en attente', '7000', 'test', 'RAS', 3, 1, '2019-01-01', '2020-11-27 09:46:13', '2020-11-27 09:46:13'),
(48, '45PouKme201127', '9', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f31343535616366312d623262302d343936642d386339612d3036663362356362396634312e706e67, 'en attente', '6000', 'test', 'RAS', 3, 1, '2019-11-27', '2020-11-27 10:17:41', '2020-11-27 10:17:41'),
(49, '46PouKme201127', '9', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f31343535616366312d623262302d343936642d386339612d3036663362356362396634312e706e67, 'en attente', '6000', 'test', 'RAS', 3, 1, '2019-11-27', '2020-11-27 10:17:49', '2020-11-27 10:17:49'),
(50, '47PouKme201027', '120', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f64623666653963352d383763362d343463382d393039352d3439373864613164366230332e706e67, 'en attente', '8000', 'test', 'RAS', 3, 1, '2020-10-27', '2020-11-27 10:20:45', '2020-11-27 10:20:45'),
(51, '48PouKme200101', '30', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f63343235663334622d313764362d343565622d626436322d3835346664316463303564622e706e67, 'en attente', '7000', 'test', 'RAS', 3, 1, '2018-01-01', '2020-11-28 11:21:20', '2020-11-28 11:21:20'),
(52, '49PouKme200101', '30', 0x66696c653a2f2f2f646174612f757365722f302f686f73742e6578702e6578706f6e656e742f63616368652f457870657269656e6365446174612f2532353430736162696e656a6f73792532353246747261636b696e672d6465732d726576656e75732d5765636172652d486f6c64696e672f496d6167655069636b65722f63343235663334622d313764362d343565622d626436322d3835346664316463303564622e706e67, 'en attente', '7000', 'test', 'RAS', 3, 1, '2018-01-01', '2020-11-28 11:21:29', '2020-11-28 11:21:29');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`);

--
-- Contraintes pour la table `departements`
--
ALTER TABLE `departements`
  ADD CONSTRAINT `departements_division_id_foreign` FOREIGN KEY (`division_id`) REFERENCES `divisions` (`id`);

--
-- Contraintes pour la table `directions`
--
ALTER TABLE `directions`
  ADD CONSTRAINT `directions_entreprise_id_foreign` FOREIGN KEY (`entreprise_id`) REFERENCES `entreprises` (`id`);

--
-- Contraintes pour la table `divisions`
--
ALTER TABLE `divisions`
  ADD CONSTRAINT `divisions_direction_id_foreign` FOREIGN KEY (`direction_id`) REFERENCES `directions` (`id`);

--
-- Contraintes pour la table `entreprises`
--
ALTER TABLE `entreprises`
  ADD CONSTRAINT `entreprises_groupe_id_foreign` FOREIGN KEY (`groupe_id`) REFERENCES `groupes` (`id`);

--
-- Contraintes pour la table `equipes`
--
ALTER TABLE `equipes`
  ADD CONSTRAINT `equipes_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`);

--
-- Contraintes pour la table `modif_ventes`
--
ALTER TABLE `modif_ventes`
  ADD CONSTRAINT `modif_ventes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `modif_ventes_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`);

--
-- Contraintes pour la table `preuves`
--
ALTER TABLE `preuves`
  ADD CONSTRAINT `preuves_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `preuves_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`);

--
-- Contraintes pour la table `produit_services`
--
ALTER TABLE `produit_services`
  ADD CONSTRAINT `produit_services_entreprise_id_foreign` FOREIGN KEY (`entreprise_id`) REFERENCES `entreprises` (`id`),
  ADD CONSTRAINT `produit_services_equipe_id_foreign` FOREIGN KEY (`equipe_id`) REFERENCES `equipes` (`id`);

--
-- Contraintes pour la table `regle_commissions`
--
ALTER TABLE `regle_commissions`
  ADD CONSTRAINT `regle_commissions_produit_service_id_foreign` FOREIGN KEY (`produit_service_id`) REFERENCES `produit_services` (`id`);

--
-- Contraintes pour la table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_departement_id_foreign` FOREIGN KEY (`departement_id`) REFERENCES `departements` (`id`);

--
-- Contraintes pour la table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_entreprise_id_foreign` FOREIGN KEY (`entreprise_id`) REFERENCES `entreprises` (`id`),
  ADD CONSTRAINT `users_equipe_id_foreign` FOREIGN KEY (`equipe_id`) REFERENCES `equipes` (`id`);

--
-- Contraintes pour la table `ventes`
--
ALTER TABLE `ventes`
  ADD CONSTRAINT `ventes_produit_service_id_foreign` FOREIGN KEY (`produit_service_id`) REFERENCES `produit_services` (`id`),
  ADD CONSTRAINT `ventes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
